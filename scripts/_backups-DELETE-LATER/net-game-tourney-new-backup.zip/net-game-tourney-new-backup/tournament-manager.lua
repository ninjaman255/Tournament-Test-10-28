-- tournament-manager.lua
local TournamentManager = {}

-- Async/await helpers
local async = function(p) local co = coroutine.create(p) return Async.promisify(co) end
local await = function(v) return Async.await(v) end

local games = require("scripts/net-games/framework")
local TournamentCore = require("scripts/net-game-tourney/tournament-core")
local TournamentFlow = require("scripts/net-game-tourney/tournament-flow")
local tournament_npcs = require("scripts/net-game-tourney/tournament-npcs")
local tournament_ui = require("scripts/net-game-tourney/tournament-ui")
local constants = require("scripts/net-game-tourney/tournament-constants")

local waiting_queues = {} -- board_id -> {players = {}, host_id, area_id}
local active_interactions = {} -- Prevent duplicate interactions

-- Initialize the tournament system
function TournamentManager.init()
    print("[Tournament Manager] Initializing tournament system...")
    -- Framework is already started by main.lua
end

-- Create a single-player tournament
function TournamentManager.create_single_player_tournament(player_id, board_id, area_id, theme)
    return async(function()
        -- Get player info
        local player_name = Net.get_player_name(player_id) or "Player"
        local player_mugshot = Net.get_player_mugshot(player_id)
        
        -- Create tournament config
        local config = {
            host_id = player_id,
            theme = theme or "red_orange_bn4",
            type = "single_player",
            board_id = board_id,
            area_id = area_id
        }
        
        -- Create tournament
        local tournament_id = TournamentCore.create_tournament(config)
        if not tournament_id then 
            Net.message_player(player_id, "Failed to create tournament.")
            return nil 
        end
        
        print(string.format("[Manager] Created tournament %d for player %s", tournament_id, player_id))
        
        -- Add player as participant
        local player_added = TournamentCore.add_participant(tournament_id, {
            id = player_id,
            type = "player",
            name = player_name,
            mugshot = player_mugshot.texture_path,
            weight = 50
        })
        
        if not player_added then
            Net.message_player(player_id, "Could not add player to tournament.")
            TournamentCore.cleanup_tournament(tournament_id)
            return nil
        end
        
        -- Add 7 random NPCs
        local npcs = tournament_npcs.get_random_npcs(7)
        local npc_count = 0
        for _, npc in ipairs(npcs) do
            if TournamentCore.add_participant(tournament_id, npc) then
                npc_count = npc_count + 1
            end
        end
        
        print(string.format("[Manager] Added %d NPCs to tournament %d", npc_count, tournament_id))
        
        -- Initialize tournament
        if TournamentCore.initialize_tournament(tournament_id) then
            print(string.format("[Manager] Tournament %d initialized successfully", tournament_id))
            return tournament_id
        else
            print("[Manager] Failed to initialize tournament")
            TournamentCore.cleanup_tournament(tournament_id)
            return nil
        end
    end)
end

-- Start a tournament
function TournamentManager.start_tournament(tournament_id)
    return async(function()
        print(string.format("[Manager] Starting tournament %d", tournament_id))
        await(TournamentFlow.run_tournament(tournament_id))
        print(string.format("[Manager] Tournament %d completed", tournament_id))
    end)
end

-- Handle board interaction
function TournamentManager.handle_board_interaction(player_id, board_object, area_id)
    return async(function()
        -- Prevent duplicate interactions
        if active_interactions[player_id] then
            print("[Manager] Player already in interaction: " .. player_id)
            return
        end
        active_interactions[player_id] = true
        
        -- Check if player is already in a tournament
        if TournamentCore.is_player_in_tournament(player_id) then
            Net.message_player(player_id, "You are already in a tournament!")
            active_interactions[player_id] = nil
            return
        end
        
        -- Get board theme
        local theme = "red_orange_bn4"
        if board_object.custom_properties then
            theme = board_object.custom_properties["Board Background"] or 
                   board_object.custom_properties["board_theme"] or 
                   "red_orange_bn4"
        end
        
        -- Check if there's a waiting queue for this board
        local board_id = tostring(board_object.id)
        if not waiting_queues[board_id] then
            waiting_queues[board_id] = {
                players = {},
                host_id = player_id,
                area_id = area_id,
                theme = theme
            }
        end
        
        local queue = waiting_queues[board_id]
        
        -- Check if player is already in queue
        for _, p in ipairs(queue.players) do
            if p == player_id then
                Net.message_player(player_id, "You are already in the waiting queue!")
                active_interactions[player_id] = nil
                return
            end
        end
        
        -- Add player to queue
        table.insert(queue.players, player_id)
        
        -- Ask what type of tournament
        Net.message_player(player_id, string.format("Tournament queue: %d/8 players", #queue.players))
        
        if #queue.players == 1 then
            -- First player - ask for tournament type
            await(Async.sleep(0.5))
            Net.message_player(player_id, "Start tournament as:")
            local choice = await(Async.quiz_player(player_id, "Multi-player", "Single Player", "Cancel"))
            
            if choice == 0 then -- Multi-player, wait for more
                Net.message_player(player_id, "Waiting for more players... (10 seconds)")
                
                -- Start countdown
                games.activate_framework(player_id)
                games.spawn_countdown(100, player_id, 20, 10, 10, false)
                
                -- Store waiting state
                queue.waiting = true
                queue.countdown_player = player_id
                
            elseif choice == 1 then -- Single player
                -- Create single player tournament
                local tournament_id = await(TournamentManager.create_single_player_tournament(
                    player_id, board_id, area_id, theme
                ))
                
                if tournament_id then
                    -- Clean up queue
                    waiting_queues[board_id] = nil
                    
                    -- Start tournament
                    await(TournamentManager.start_tournament(tournament_id))
                end
                
            else -- Cancel
                waiting_queues[board_id] = nil
                Net.message_player(player_id, "Cancelled.")
            end
            
        elseif #queue.players >= 2 and #queue.players < 8 then
            -- Additional players joining
            Net.message_player(player_id, "Joined tournament queue.")
            
            -- Notify host
            if queue.host_id and queue.host_id ~= player_id then
                Net.message_player(queue.host_id, 
                    string.format("%s joined the queue. Total: %d/8", 
                    Net.get_player_name(player_id) or "Player", #queue.players))
            end
            
        elseif #queue.players >= 8 then
            -- Start multi-player tournament with 8 players
            Net.message_player(player_id, "Queue full! Starting tournament...")
            
            -- Create tournament
            local tournament_id = TournamentCore.create_tournament({
                host_id = queue.host_id,
                theme = queue.theme,
                type = "multi_player",
                board_id = board_id,
                area_id = area_id
            })
            
            if tournament_id then
                -- Add all players
                for _, pid in ipairs(queue.players) do
                    local player_name = Net.get_player_name(pid) or "Player"
                    local player_mugshot = Net.get_player_mugshot(pid)
                    
                    TournamentCore.add_participant(tournament_id, {
                        id = pid,
                        type = "player",
                        name = player_name,
                        mugshot = player_mugshot.texture_path,
                        weight = 50
                    })
                end
                
                -- Initialize and start
                if TournamentCore.initialize_tournament(tournament_id) then
                    -- Clean up queue
                    waiting_queues[board_id] = nil
                    
                    -- Start tournament
                    await(TournamentManager.start_tournament(tournament_id))
                end
            end
        end
        
        active_interactions[player_id] = nil
    end)
end

-- Handle countdown ended
Net:on("countdown_ended", function(event)
    return async(function()
        local player_id = event.player_id
        
        -- Find which queue this player was waiting in
        for board_id, queue in pairs(waiting_queues) do
            if queue.countdown_player == player_id then
                print(string.format("[Manager] Countdown ended for player %s on board %s", player_id, board_id))
                
                -- Ask what to do
                Net.message_player(player_id, 
                    string.format("Queue has %d/8 players. What would you like to do?", #queue.players))
                
                local choice = await(Async.quiz_player(player_id, "Start with NPCs", "Wait longer", "Cancel"))
                
                if choice == 0 then -- Start with NPCs
                    -- Create tournament with current players + NPCs
                    local tournament_id = await(TournamentManager.create_single_player_tournament(
                        player_id, board_id, queue.area_id, queue.theme
                    ))
                    
                    if tournament_id then
                        waiting_queues[board_id] = nil
                        await(TournamentManager.start_tournament(tournament_id))
                    end
                    
                elseif choice == 1 then -- Wait longer
                    games.spawn_countdown(100, player_id, 20, 10, 10, false)
                    
                else -- Cancel
                    waiting_queues[board_id] = nil
                    Net.message_player(player_id, "Cancelled.")
                end
                
                break
            end
        end
    end)
end)

-- Handle battle results
function TournamentManager.handle_battle_result(player_id, battle_data)
    print(string.format("[Manager] Processing battle result for %s", player_id))
    -- TournamentFlow handles battle results internally
end

-- Handle player disconnect
function TournamentManager.handle_player_disconnect(player_id)
    print(string.format("[Manager] Player disconnected: %s", player_id))
    
    -- Remove from any waiting queues
    for board_id, queue in pairs(waiting_queues) do
        local new_players = {}
        for _, pid in ipairs(queue.players) do
            if pid ~= player_id then
                table.insert(new_players, pid)
            end
        end
        
        if #new_players == 0 then
            waiting_queues[board_id] = nil
        else
            queue.players = new_players
            -- Update host if needed
            if queue.host_id == player_id and #new_players > 0 then
                queue.host_id = new_players[1]
            end
        end
    end
    
    -- Handle tournament cleanup (TournamentCore handles this)
    TournamentCore.handle_player_disconnect(player_id)
end

-- Cleanup orphaned tournaments
function TournamentManager.cleanup_orphaned_tournaments()
    TournamentCore.cleanup_orphaned_tournaments()
end

return TournamentManager