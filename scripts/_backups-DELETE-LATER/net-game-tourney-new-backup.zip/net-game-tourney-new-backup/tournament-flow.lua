-- tournament-flow.lua
local TournamentFlow = {}
local constants = require("scripts/net-game-tourney/tournament-constants")

-- Async/await helpers
local async = function(p) local co = coroutine.create(p) return Async.promisify(co) end
local await = function(v) return Async.await(v) end

-- Run a tournament
function TournamentFlow.run_tournament(tournament_id)
    return async(function()
        local TournamentCore = require("scripts/net-game-tourney/tournament-core")
        local TournamentUI = require("scripts/net-game-tourney/tournament-ui")
        
        local tournament = TournamentCore.get_tournament(tournament_id)
        if not tournament then
            print("[Flow] Tournament not found: " .. tournament_id)
            return
        end
        
        print(string.format("[Flow] Starting tournament %d with %d participants", 
              tournament_id, #tournament.participants))
        
        -- Show initial board
        await(TournamentFlow.show_board_to_all(tournament_id, "initial"))
        await(Async.sleep(2.0))
        
        -- Run 3 rounds
        for round = 1, 3 do
            print("[Flow] Starting round " .. round)
            tournament.current_round = round
            
            -- Show current state
            await(TournamentFlow.show_board_to_all(tournament_id, "current"))
            await(Async.sleep(1.5))
            
            -- Run battles
            await(TournamentFlow.run_round_battles(tournament_id, round))
            
            -- Update positions
            TournamentCore.update_positions(tournament_id, round)
            
            -- Show results
            await(TournamentFlow.show_board_to_all(tournament_id, "results"))
            await(Async.sleep(2.0))
            
            -- Check if tournament should continue
            if round < 3 then
                local continue = await(TournamentFlow.ask_host_continue(tournament_id))
                if not continue then
                    print("[Flow] Host chose to end tournament")
                    TournamentFlow.cleanup_tournament(tournament_id)
                    return
                end
                
                -- Advance to next round
                TournamentCore.complete_round(tournament_id)
                TournamentCore.advance_round(tournament_id)
            end
        end
        
        -- Tournament complete
        await(TournamentFlow.announce_winner(tournament_id))
        TournamentFlow.cleanup_tournament(tournament_id)
    end)
end

-- Run battles for a round
function TournamentFlow.run_round_battles(tournament_id, round)
    return async(function()
        local TournamentCore = require("scripts/net-game-tourney/tournament-core")
        
        local tournament = TournamentCore.get_tournament(tournament_id)
        if not tournament then return end
        
        local round_key = round == 1 and "round1" or (round == 2 and "round2" or "round3")
        local matches = tournament.matches[round_key]
        
        if not matches then
            print("[Flow] No matches for round " .. round)
            return
        end
        
        print("[Flow] Running " .. #matches .. " battles")
        
        for i, match in ipairs(matches) do
            print(string.format("[Flow] Match %d: %s vs %s", i, match.player1.name, match.player2.name))
            
            -- Check if player is involved
            local is_player_battle = match.player1.type == "player" or match.player2.type == "player"
            
            if is_player_battle then
                -- Player battle
                print("[Flow] Starting player battle...")
                await(TournamentFlow.start_player_battle(tournament_id, round, i, match))
            else
                -- NPC battle
                print("[Flow] Starting NPC battle...")
                await(TournamentFlow.resolve_npc_battle(tournament_id, round, i, match))
            end
            
            await(Async.sleep(0.5))
        end
    end)
end

-- Start player battle
function TournamentFlow.start_player_battle(tournament_id, round, match_index, match)
    return async(function()
        local TournamentCore = require("scripts/net-game-tourney/tournament-core")
        
        local p1_id, p2_id = match.player1.id, match.player2.id
        local p1_type, p2_type = match.player1.type, match.player2.type
        
        print(string.format("[Flow] Player battle: %s (%s) vs %s (%s)", 
              p1_id, p1_type, p2_id, p2_type))
        
        -- Determine which is player and which is opponent
        local player_id, opponent_id, opponent_is_npc
        if p1_type == "player" and p2_type == "npc" then
            player_id = p1_id
            opponent_id = p2_id
            opponent_is_npc = true
        elseif p2_type == "player" and p1_type == "npc" then
            player_id = p2_id
            opponent_id = p1_id
            opponent_is_npc = true
        elseif p1_type == "player" and p2_type == "player" then
            player_id = p1_id
            opponent_id = p2_id
            opponent_is_npc = false
        else
            print("[Flow] No player in this match, should be NPC battle")
            await(TournamentFlow.resolve_npc_battle(tournament_id, round, match_index, match))
            return
        end
        
        -- Check if player is connected
        if not Net.is_player(player_id) then
            print("[Flow] Player disconnected: " .. player_id)
            -- Player disconnected, opponent wins by default
            TournamentCore.record_battle_result(tournament_id, round, match_index, opponent_id, player_id)
            return
        end
        
        -- Start the battle
        Net.lock_player_input(player_id)
        
        local battle_result
        if opponent_is_npc then
            print(string.format("[Flow] Starting PvE battle: %s vs NPC %s", player_id, opponent_id))
            battle_result = await(Async.initiate_encounter(player_id, opponent_id))
        else
            -- Check if opponent is connected
            if not Net.is_player(opponent_id) then
                print("[Flow] Opponent disconnected: " .. opponent_id)
                -- Opponent disconnected, player wins by default
                TournamentCore.record_battle_result(tournament_id, round, match_index, player_id, opponent_id)
                Net.unlock_player_input(player_id)
                return
            end
            
            Net.lock_player_input(opponent_id)
            print(string.format("[Flow] Starting PvP battle: %s vs %s", player_id, opponent_id))
            battle_result = await(Async.initiate_pvp(player_id, opponent_id))
            Net.unlock_player_input(opponent_id)
        end
        
        Net.unlock_player_input(player_id)
        
        -- Process battle result
        if battle_result then
            print("[Flow] Battle completed, processing result...")
            print(string.format("[Flow] Battle data: player_id=%s, health=%d, reason=%d", 
                  battle_result.player_id, battle_result.health or 0, battle_result.reason or 0))
            
            if battle_result.enemies then
                print(string.format("[Flow] Enemies count: %d", #battle_result.enemies))
                for i, enemy in ipairs(battle_result.enemies) do
                    print(string.format("[Flow] Enemy %d: id=%s, health=%d", i, enemy.id, enemy.health))
                end
            end
            
            -- Determine winner based on battle result
            local winner_id, loser_id
            
            -- Check battle reason
            -- Reason 1: Player ran away
            -- Reason 2, 3, 4: Player lost (different defeat conditions)
            -- Reason 0 or other: Check health/enemies
            if battle_result.reason and (battle_result.reason == 1 or 
                                         battle_result.reason == 2 or 
                                         battle_result.reason == 3 or 
                                         battle_result.reason == 4) then
                -- Player ran away or lost - opponent wins
                winner_id = opponent_id
                loser_id = player_id
                print(string.format("[Flow] Player lost (reason=%d), opponent wins", battle_result.reason))
            else
                -- No losing reason specified, check health and enemies
                local player_alive = (battle_result.health or 0) > 0
                
                -- Check enemies status
                local all_enemies_defeated = true
                if battle_result.enemies and #battle_result.enemies > 0 then
                    for _, enemy in ipairs(battle_result.enemies) do
                        if enemy.health > 0 then
                            all_enemies_defeated = false
                            print(string.format("[Flow] Enemy %s still alive with %d health", enemy.id, enemy.health))
                            break
                        end
                    end
                else
                    -- No enemies in result, assume all defeated
                    print("[Flow] No enemies in battle result, assuming all defeated")
                end
                
                if player_alive and all_enemies_defeated then
                    -- Player survived and all enemies defeated
                    winner_id = player_id
                    loser_id = opponent_id
                    print("[Flow] Player survived and all enemies defeated, player wins")
                else
                    -- Player died or enemies survived
                    winner_id = opponent_id
                    loser_id = player_id
                    print("[Flow] Player died or enemies survived, opponent wins")
                end
            end
            
            -- Record the result
            TournamentCore.record_battle_result(tournament_id, round, match_index, winner_id, loser_id)
            print(string.format("[Flow] Recorded result: %s defeated %s", winner_id, loser_id))
            
        else
            print("[Flow] No battle result received, using NPC resolution")
            -- Fall back to NPC resolution
            await(TournamentFlow.resolve_npc_battle(tournament_id, round, match_index, match))
        end
    end)
end

-- Resolve NPC battle
function TournamentFlow.resolve_npc_battle(tournament_id, round, match_index, match)
    return async(function()
        local TournamentCore = require("scripts/net-game-tourney/tournament-core")
        
        local npc1_id, npc2_id = match.player1.id, match.player2.id
        print(string.format("[Flow] NPC battle: %s vs %s", npc1_id, npc2_id))
        
        local result = TournamentCore.get_npc_battle_result(tournament_id, round, match_index, npc1_id, npc2_id)
        
        if result then
            TournamentCore.record_battle_result(tournament_id, round, match_index, result.winner_id, result.loser_id)
            print(string.format("[Flow] NPC result: %s defeated %s", result.winner_id, result.loser_id))
            
            -- Simulate battle time
            await(Async.sleep(1.0))
        else
            print("[Flow] Failed to get NPC battle result")
        end
    end)
end

-- Show board to all players
function TournamentFlow.show_board_to_all(tournament_id, view_type)
    return async(function()
        local TournamentCore = require("scripts/net-game-tourney/tournament-core")
        local TournamentUI = require("scripts/net-game-tourney/tournament-ui")
        local constants = require("scripts/net-game-tourney/tournament-constants")
        
        local tournament = TournamentCore.get_tournament(tournament_id)
        if not tournament then return end
        
        -- Show to all players
        for _, participant in ipairs(tournament.participants) do
            if participant.type == "player" and Net.is_player(participant.id) then
                local player_id = participant.id
                local area_id = Net.get_player_area(player_id)
                
                -- Save area state
                local original_song = Net.get_song(area_id)
                local original_name = Net.get_area_name(area_id)
                
                -- Setup for tournament view
                Net.set_song(area_id, constants.tournament_music)
                Net.set_area_name(area_id, "Tournament")
                
                -- Show UI
                Net.lock_player_input(player_id)
                Net.toggle_player_hud(player_id)
                
                TournamentUI.show_transition(player_id, false, 0.3)
                await(Async.sleep(0.3))
                
                TournamentUI.show_board(player_id, tournament, view_type)
                
                TournamentUI.show_transition(player_id, true, 0.3)
                await(Async.sleep(0.3))
                
                -- Wait for viewing
                await(Async.sleep(2.0))
                
                -- Cleanup and restore
                TournamentUI.show_transition(player_id, false, 0.3)
                await(Async.sleep(0.3))
                
                TournamentUI.cleanup(player_id)
                
                TournamentUI.show_transition(player_id, true, 0.3)
                Net.unlock_player_input(player_id)
                Net.toggle_player_hud(player_id)
                
                -- Restore area state
                Net.set_song(area_id, original_song)
                Net.set_area_name(area_id, original_name)
                
                await(Async.sleep(0.1))
            end
        end
    end)
end

-- Ask host to continue
function TournamentFlow.ask_host_continue(tournament_id)
    return async(function()
        local TournamentCore = require("scripts/net-game-tourney/tournament-core")
        
        local tournament = TournamentCore.get_tournament(tournament_id)
        if not tournament or not tournament.host_id then
            print("[Flow] No host, auto-continuing")
            return true
        end
        
        local host_id = tournament.host_id
        
        if not Net.is_player(host_id) then
            print("[Flow] Host disconnected, auto-continuing")
            return true
        end
        
        await(Async.message_player(host_id, "Round " .. tournament.current_round .. " complete!"))
        await(Async.sleep(0.5))
        Net.message_player(host_id,"Continue to next round?")
        local choice = await(Async.quiz_player(host_id, "Continue", "End"))
        
        return choice == 0
    end)
end

-- Announce winner
function TournamentFlow.announce_winner(tournament_id)
    return async(function()
        local TournamentCore = require("scripts/net-game-tourney/tournament-core")
        
        local tournament = TournamentCore.get_tournament(tournament_id)
        if not tournament then return end
        
        local winner = TournamentCore.get_winner(tournament_id)
        if not winner then
            print("[Flow] No winner found")
            return
        end
        
        -- Announce to all players
        for _, participant in ipairs(tournament.participants) do
            if participant.type == "player" and Net.is_player(participant.id) then
                Net.message_player(participant.id, "Tournament Complete! Winner: " .. winner.name)
                await(Async.sleep(0.1))
            end
        end
        
        print("[Flow] Tournament winner: " .. winner.name)
    end)
end

-- Cleanup tournament
function TournamentFlow.cleanup_tournament(tournament_id)
    local TournamentCore = require("scripts/net-game-tourney/tournament-core")
    local TournamentUI = require("scripts/net-game-tourney/tournament-ui")
    
    local tournament = TournamentCore.get_tournament(tournament_id)
    if not tournament then return end
    
    -- Cleanup UI for players
    for _, participant in ipairs(tournament.participants) do
        if participant.type == "player" and Net.is_player(participant.id) then
            TournamentUI.cleanup(participant.id)
        end
    end
    
    -- Cleanup state
    TournamentCore.cleanup_tournament(tournament_id)
    
    print("[Flow] Tournament cleanup complete")
end

return TournamentFlow