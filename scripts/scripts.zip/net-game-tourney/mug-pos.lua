local POSITIONS = {
top_tier = {},
middle_tier_interprolation ={},
middle_tier={},
bottom_tier_interprolation ={},
bottom_tier = {
        [1] = {
            x = 8,
            y = 132,
        },
        [2] = {
            x = 34,
            y = 132,
        },
        [3] = {
            x = 64,
            y = 132,
        },
        [4] = {
            x = 90,
            y = 132,
        },
        [5] = {
            x = 128,
            y = 132,
        },
        [6] = {
            x = 154,
            y = 132,
        },
        [7] = {
            x = 184,
            y = 132,
        },
        [8] = {
            x = 210,
            y = 132,
        },
    }
}
return POSITIONS