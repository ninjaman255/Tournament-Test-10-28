local battle_helpers = include("battle_helpers.lua")
---@type Spells
local Spells = include("spells.lua")
local character_animation = _folderpath .. "battle.animation"
local CHARACTER_TEXTURE = Engine.load_texture(_folderpath .. "battle.png")
local anim_speed = 1
local attack_count = 0

--possible states for character
local states = { IDLE = 1, JUMP = 2, LAND = 3, RINGS = 4, TENT = 5 }
-- Load character resources
---@param self Entity
function package_init(self, character_info)
    -- Required function, main package information

    local base_animation_path = character_animation
    self:set_texture(CHARACTER_TEXTURE)
    self.animation = self:get_animation()
    self.animation:load(base_animation_path)
    self.animation:set_playback_speed(anim_speed)
    -- Load extra resources
    -- Set up character meta
    self:set_name(character_info.name)
    self:set_health(character_info.hp)
    self:set_height(character_info.height)
    self:share_tile(false)
    self:set_explosion_behavior(4, 1, false)
    self:set_offset(0, 0)
    self.shockwave_anim = character_info.shockwave_anim
    self.has_areagrab = (character_info.has_areagrab)
    self.animation:set_state("SPAWN")
    self.frame_counter = 0
    self.frames_between_actions = character_info.frames_between_actions
    self.cascade_frame_index = character_info.cascade_frame
    self.started = false
    self.jump_speed = 32

    self.attack_damage = character_info.damage
    self.tent_damage = character_info.tent_damage

    if (self:get_rank() == Rank.NM) then
        self.jump_speed = 10
    end

    self.move_direction = Direction.Right
    self.defense = Battle.DefenseVirusBody.new()
    self:add_defense_rule(self.defense)

    self:set_shadow(Shadow.Small)
    self:show_shadow(true)

    ---CircusMan Hands
    self.left_hand = self:create_node() --Nodes automatically attach to what you create them off of. No need to spawn!
    self.left_hand:set_texture(Engine.load_texture(_folderpath .. "hands.png")) --Just set their texture...
    self.left_hand_anim = Engine.Animation.new(_folderpath .. "hands.animation") --And they have no get_animation, so we create one...
    self.left_hand:set_layer(-3) --Set their layer, they're already a sprite...
    self.left_hand_anim:set_state("IDLE_LH")
    self.left_hand_anim:refresh(self.left_hand)
    self.left_hand_anim:set_playback(Playback.Loop)

    self.right_hand = self:create_node() --Nodes automatically attach to what you create them off of. No need to spawn!
    self.right_hand:set_texture(Engine.load_texture(_folderpath .. "hands.png")) --Just set their texture...
    self.right_hand_anim = Engine.Animation.new(_folderpath .. "hands.animation") --And they have no get_animation, so we create one...
    self.right_hand:set_layer(-3) --Set their layer, they're already a sprite...
    self.right_hand_anim:set_state("IDLE_RH")
    self.right_hand_anim:refresh(self.right_hand)
    self.right_hand_anim:set_playback(Playback.Loop)

    local ref = self
    --This is how we animate nodes.
    self.animate_component = Battle.Component.new(self, Lifetimes.Battlestep)
    self.animate_component.update_func = function(self, dt)
        ref.left_hand_anim:update(dt, ref.left_hand)
        ref.right_hand_anim:update(dt, ref.right_hand)
    end
    self:register_component(self.animate_component)

    self.can_move_to_func = function(tile)
        if (self.state == states.TENT) then
            return true
        else
            local canMove = is_tile_free_for_movement(tile, self)
            return canMove
        end
    end

    ---state idle
    ---@param frame number
    self.action_idle = function(frame)
        if (frame == self.frames_between_actions) then

            self.set_state(states.JUMP)
            local moved
            battle_helpers.jump_in_back_row(self, self.jump_speed)
            if (not moved) then
                self:jump(self:get_tile(), 140, frames(self.jump_speed), frames(0), ActionOrder.Immediate, nil)
            end
            self.animation:set_state("BOUNCE_UP")
            self.left_hand_anim:set_state("JUMP_LH")
            self.right_hand_anim:set_state("JUMP_RH")
            self.animation:on_frame(1, function()
                --circusMan not targetable in air.
                self:toggle_hitbox(false)
            end)
        end
    end

    ---state jump
    ---@param frame number
    self.action_jump = function(frame)
        self:set_facing(self:get_tile():get_facing())
        if (frame == self.jump_speed - 1) then
            self.animation:set_state("BOUNCE_DOWN")
            self:toggle_hitbox(true)

        elseif (frame == self.jump_speed + 6) then
            if (attack_count < 3) then
                self.animation:set_state("CLAP")
                self.animation:on_frame(3, function()
                    self:toggle_counter(true)
                    Spells.clap(self, "CLAP_TOP", 1)
                    Spells.clap(self, "CLAP_BOTTOM", 3)
                    self.set_state(states.IDLE)
                end)
                self.animation:on_complete(function()
                    self:toggle_counter(false)
                end)
            else
                --select either tent or lions
                local rand = math.random(1, 3)
                if (rand < 3) then
                    self.set_state(states.RINGS)
                    attack_count = -1
                else
                    self.set_state(states.TENT)
                    attack_count = -1
                end
            end
            attack_count = attack_count + 1
        end
    end


    --CircusM turns into a tent
    self.action_tent = function(frame)
        if (frame == 1) then
            self.previous_position = nil
            self.tent_target = battle_helpers.find_target(self):get_tile()
            self.animation:set_state("START_TENT")
            self.animation:on_complete(function()
                self:set_offset(0, 999)
                self.left_hand:set_offset(0, 999);
                self.right_hand:set_offset(0, 999);
                self:hide()
                self:show_shadow(false)
                Spells.tent_create(self)
            end)
        end
        if (frame < 10) then
            self.tent_target:highlight(Highlight.Flash)
        end
    end

    self.action_rings = function(frame)

        if (frame == 10) then
            self.animation:set_state("WHIP")
            self.left_hand_anim:set_state("WHIP_LH")
            self.right_hand_anim:set_state("WHIP_RH")
            Spells.summon_lion(self)
        elseif (frame == 50) then
            self.animation:set_state("WHIP")
            self.left_hand_anim:set_state("WHIP_LH")
            self.right_hand_anim:set_state("WHIP_RH")
            Spells.summon_lion(self)
        elseif (frame == 90) then
            self.animation:set_state("WHIP")
            self.left_hand_anim:set_state("WHIP_LH")
            self.right_hand_anim:set_state("WHIP_RH")
            Spells.summon_lion(self)
            self.set_state(states.IDLE)
        end
    end

    ---state land
    ---@param frame number
    self.action_land = function(frame)
    end


    --utility to set the update state, and reset frame counter
    ---@param state number
    self.set_state = function(state)
        self.state = state
        self.frame_counter = 0
    end

    local actions = { [1] = self.action_idle, [2] = self.action_jump, [4] = self.action_rings, [5] = self.action_tent }

    self.update_func = function()
        self.frame_counter = self.frame_counter + 1
        if not self.started then
            self.current_direction = self:get_facing()
            self.enemy_dir = self:get_facing()
            self.started = true
            self.set_state(states.IDLE)
        else
            local action_func = actions[self.state]
            action_func(self.frame_counter)
        end
    end






end

function TileToString(tile)
    return "Tile: [" .. tostring(tile:x()) .. "," .. tostring(tile:y()) .. "]"

end

function is_tile_free_for_movement(tile, character)
    --Basic check to see if a tile is suitable for a chracter of a team to move to

    if tile:get_team() ~= character:get_team() then
        return false
    end
    if (tile:is_edge()) then
        return false
    end
    local occupants = tile:find_entities(function(ent)
        if (Battle.Character.from(ent) ~= nil or Battle.Obstacle.from(ent) ~= nil) then
            return true
        else
            return false
        end
    end)
    if #occupants == 1 and occupants[1]:get_id() == character:get_id() then
        return true
    end
    if #occupants > 0 then
        return false
    end

    return true
end

--find a target character


return package_init
