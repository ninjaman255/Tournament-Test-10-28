local shared_package_init = include("./character.lua")
local character_id = "com.louise.enemy."
function package_init(character)
    local character_info = {
        name = "CrcusMan",
        hp = 700,
        damage = 20,
        palette = _folderpath .. "V1.png",
        height = 44,
        frames_between_actions = 60,
        shockwave_anim = "shockwave.animation",
        tent_damage = 3
    }
    if character:get_rank() == Rank.EX then
        character_info.damage = 50
        character_info.tent_damage = 5
        character_info.frames_between_actions = 50
        character_info.hp = 1200
    end
    if character:get_rank() == Rank.SP then
        character_info.damage = 100
        character_info.hp = 1600
        character_info.frames_between_actions = 40
        character_info.tent_damage = 10
    end
    if character:get_rank() == Rank.NM then
        character_info.damage = 300
        character_info.tent_damage = 75
        character_info.frames_between_actions = 30
        character_info.hp = 3200
    end
    shared_package_init(character, character_info)
end
