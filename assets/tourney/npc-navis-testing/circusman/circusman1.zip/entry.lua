local package_id = "com.louise.CircusMan"
local character_id = "com.louise.enemy."

function package_requires_scripts()
  Engine.define_character(character_id .. "CircusMan", _modpath .. "CircusMan")

end

function package_init(package)
  package:declare_package_id(package_id)
  package:set_name("CircusMan")
  package:set_description("Bn6 CircusMan")
  package:set_speed(1)
  package:set_attack(20)
  package:set_health(1)
  package:set_preview_texture_path(_modpath .. "preview.png")
end

function package_build(mob)
  local spawner = mob:create_spawner(character_id .. "CircusMan", Rank.V1)
  spawner:spawn_at(5, 2)
end
