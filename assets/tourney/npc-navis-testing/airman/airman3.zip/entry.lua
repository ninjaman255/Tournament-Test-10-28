local package_id = "com.louise_AirManV3"
local character_id = "com.louise_enemy_AirManV1"

function package_requires_scripts()
  Engine.requires_character("com.louise_enemy_AirManV1")
end

function package_init(package)
  package:declare_package_id(package_id)
  package:set_name("AirManV3")
  package:set_description("AirMan V3 Remastered!")
  package:set_speed(1)
  package:set_attack(150)
  package:set_health(1500)
  package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob)
local texPath = _modpath.."background.png"
local animPath = _modpath.."background.animation"
mob:set_background(texPath, animPath, -0.5, -0.5)
mob:stream_music(_modpath.."airman.mid", 0, 0)
local spawner = mob:create_spawner(character_id, Rank.SP)
spawner:spawn_at(5, 2)
end