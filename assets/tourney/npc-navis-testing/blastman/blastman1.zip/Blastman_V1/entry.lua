local battle_helpers = include("battle_helpers.lua")
local character_info = {name = "BlastMan", hp = 400,height=80}



--local wave_sfx = Engine.load_audio(_modpath .. "shockwave.ogg")
local blastman_animation = _modpath.."battle.animation"
local BLASTMAN_TEXTURE = Engine.load_texture(_modpath .. "battle.png")
local exploding_line_texture = Engine.load_texture(_modpath .. "explosion.png")
local exploding_line_animation = _modpath.."explosion.animation"
local fire_tornado_texture = Engine.load_texture(_modpath .. "tornado.png")
local fire_tornado_animation = _modpath.."tornado.animation"
local tummy_fire_texture = Engine.load_texture(_modpath .. "tummy_fire.png")
local tummy_fire_animation = _modpath.."tummy_fire.animation"
local wind_texture = Engine.load_texture(_modpath .. "wind.png")
local wind_animation = _modpath.."wind.animation"
local fireball_texture = Engine.load_texture(_modpath .. "fireball.png")
local fireball_animation = _modpath.."fireball.animation"
local blastcube_texture = Engine.load_texture(_modpath .. "blastcube.png")
local blastcube_animation = _modpath.."blastcube.animation"

local fireball_sfx = Engine.load_audio(_modpath .. "BlastManFireBall.ogg")
local tornado_sfx = Engine.load_audio(_modpath .. "BlastManWhirlwind.ogg")
local explosion_sfx = Engine.load_audio(_modpath .. "BlastManExplosion.ogg")





local fireball_speed = 8 -- lower is quicker
local anim_speed = 1 -- higher is faster
local wait_length = 60 -- lower is quicker
local exploding_line_dmg = 10
local fire_tornado_dmg = 10
local fireball_dmg = 20



--local move_counter = 0
--local wind_dir
--local wind_toggle = false

function package_init(self)

	self.move_counter = 0
	--self.attack_counter = 0
	--self.which_attack = 0
	
	
	
	if self:get_rank() == Rank.V1 then
		character_info = {name = "BlastMan", hp = 400,height=80}
		exploding_line_dmg = 10
		fire_tornado_dmg = 10
		fireball_dmg = 20
		anim_speed = 1
		fireball_speed = 8
		wait_length = 60
	elseif self:get_rank() == Rank.EX then
		character_info = {name = "BlastMan", hp = 800,height=80}
		exploding_line_dmg = 50
		fire_tornado_dmg = 50
		fireball_dmg = 70
		anim_speed = 1
		fireball_speed = 7
		wait_length = 60
		
	elseif self:get_rank() == Rank.SP then
		character_info = {name = "BlastMan", hp = 1400,height=80}
		exploding_line_dmg = 90
		fire_tornado_dmg = 90
		fireball_dmg = 150
		anim_speed = 2
		fireball_speed = 6
		wait_length = 40
		
	elseif self:get_rank() == Rank.RV then
		character_info = {name = "BlastMan", hp = 2000,height=80}
		exploding_line_dmg = 150
		fire_tornado_dmg = 140
		fireball_dmg = 270
		anim_speed = 3
		fireball_speed = 5
		wait_length = 30
	end
	
	
	
    local base_animation_path = blastman_animation
	self:set_texture(BLASTMAN_TEXTURE, true)
    self.animation = self:get_animation()
    self.animation:load(base_animation_path)
	self.animation:set_playback_speed(anim_speed)

    -- Load extra resources

    -- Set up character meta
    self:set_name(character_info.name)
    self:set_health(character_info.hp)
    self:set_height(character_info.height)
    self:share_tile(false)
    self:set_explosion_behavior(4, 1, false)
    self:set_offset(0, 0)
	self:set_facing(Direction.Left)
	self:set_element(Element.Fire)
	self:share_tile(false)
	self:set_float_shoe(true)
	self:set_air_shoe(true)

	self.can_move_to_func = function(tile)
		if tile:is_edge() or tile:get_team() ~= self:get_team() or tile:is_reserved({ self:get_id(), self._reserver }) then
		  return false
		end

		local has_character = false

		tile:find_characters(function(c)
		  if c:get_id() ~= self:get_id() then
			has_character = true
		  end
		  return false
		end)
		
		tile:find_obstacles(function(c)
		  if c:get_id() ~= self:get_id() then
			has_character = true
		  end
		  return false
		end)

		return not has_character
	end
	
	
	self.can_move_to_func_back_row = function(tile)
		if tile:is_edge() or tile:get_team() ~= self:get_team() or tile:is_reserved({ self:get_id(), self._reserver }) then
		  return false
		end

		local has_character = false

		tile:find_characters(function(c)
			if c:get_id() ~= self:get_id() then
				has_character = true
			end
			return false
		end)
		
		tile:find_obstacles(function(c)
		  if c:get_id() ~= self:get_id() then
			has_character = true
		  end
		  return false
		end)

		if tile:get_tile(Direction.Right,1):is_edge() == false then
			has_character = true
		end

		return not has_character
	end
	
	
	self.can_move_to_func_target_enemy = function(tile)
	
	if tile:is_edge() or tile:get_team() ~= self:get_team() or tile:is_reserved({ self:get_id(), self._reserver }) then
		return false
	end


	local has_enemy = false
	local x = 0
	while x < 7 do 
		if tile:get_tile(Direction.Left, x):is_edge() then
			return has_enemy
		end
		tile:get_tile(Direction.Left, x):find_characters(function(c)
			if c:get_id() ~= self:get_id() then
				has_enemy = true
			end
			return false
		end)
		
		tile:find_obstacles(function(c)
			if c:get_id() ~= self:get_id() then
				has_enemy = false
			end
			return false
		end)
		
		x = x + 1
	end
	return has_enemy
	
	end
	
	
	self.can_move_to_func_target_enemy_three = function(tile)
	
	if tile:is_edge() or tile:get_team() ~= self:get_team() or tile:is_reserved({ self:get_id(), self._reserver }) then
		return false
	end


	local has_enemy = false
	local x = 0
	while x < 4 do 
		if tile:get_tile(Direction.Left, x):is_edge() then
			return has_enemy
		end
		tile:get_tile(Direction.Left, x):find_characters(function(c)
			if c:get_id() ~= self:get_id() then
				has_enemy = true
			end
			return false
		end)
		
		tile:find_obstacles(function(c)
			if c:get_id() ~= self:get_id() then
				has_enemy = false
			end
			return false
		end)
		
		x = x + 1
	end
	return has_enemy
	
	end
	
	--[[self:register_status_callback(
		Hit.stun,
		function()
			print("Got stunned")
			idle(self)
		end
	)]]--

	self.on_countered_func = function()
		print("Got Countered")
		idle(self)
	end
	self.on_countered = self.on_countered_func
	
	
	self:register_status_callback(Hit.Flinch, function()
        self.animation:set_state("HIT")
        self.animation:on_complete(function()
            idle(self)
        end)
    end)
	
	
	
	
    idle(self)
	
end

idle = function(self)
	self.animation:set_state("IDLE")
    self.animation:set_playback(Playback.Loop)
    self.frames_between_actions = 40 
    --self.cascade_frame_index = 5 --lower = faster shockwaves
    self.ai_wait = self.frames_between_actions
    self.ai_taken_turn = false
	local wait_time = 0
	
	
	
	
	self.update_func = function ()
		
		wait_time = wait_time + 1

		if wait_time < wait_length then
		  return
		end

		self.update_func = function() end
		
		if self.move_counter < 3 then
			move(self)
		else
			self.move_counter = 0
			self.rando = math.random(1,3)
			if self.rando == 1 then 
				exploding_line(self)
			elseif self.rando == 2 then
				fire_tornado(self)
			elseif self.rando == 3 then
				fire_wave(self)
			end
		end
	end
end

function move(self)

	self.move_counter = self.move_counter + 1

	local anim = self:get_animation()
	anim:set_state("TELEPORT_OUT")
	anim:on_complete(function()
		
		--anim:set_playback(Playback.Once)

		local target_tile = find_valid_move_location(self)
		--character:toggle_hitbox(false)

		self:slide(target_tile, frames(0), frames(0), ActionOrder.Voluntary, function()
		end)
		
		anim:set_state("TELEPORT_IN")
		anim:on_complete(function()
				idle(self)
		end)

	end)
	return
end

function find_valid_move_location(self)
	local target_tile
	local field = self:get_field()

	local tiles = field:find_tiles(function(tile)
		return self.can_move_to_func(tile)
	end)
  
	--print (#tiles)
	if #tiles >= 1 then
		target_tile = tiles[math.random(#tiles)]
	else
		target_tile = self:get_tile()
	end
	
	local start_tile = self:get_tile()
	if #tiles > 1 then
		while target_tile == start_tile do
		-- pick another, don't try to jump on the same tile if it's not necessary
		target_tile = tiles[math.random(#tiles)]
		end
	end
  
  return target_tile
end

function find_valid_move_location_targeted(self)
	local target_tile
	local field = self:get_field()

	local tiles = field:find_tiles(function(tile)
		return self.can_move_to_func_target_enemy(tile)
	end)
  
	--print (#tiles)
	if #tiles >= 1 then
		target_tile = tiles[math.random(#tiles)]
	else
		target_tile = self:get_tile()
	end
	
	local start_tile = self:get_tile()
	if #tiles > 1 then
		while target_tile == start_tile do
		-- pick another, don't try to jump on the same tile if it's not necessary
		target_tile = tiles[math.random(#tiles)]
		end
	end
  
  return target_tile
end

function find_valid_move_location_targeted_three(self)
	local target_tile
	local field = self:get_field()

	local tiles = field:find_tiles(function(tile)
		return self.can_move_to_func_target_enemy_three(tile)
	end)
  
	print (#tiles)
	if #tiles >= 1 then
		target_tile = tiles[math.random(#tiles)]
	else
		
		tiles = field:find_tiles(function(tile)
			return self.can_move_to_func(tile)
		end)
		
		if #tiles >= 1 then 
			target_tile = tiles[math.random(#tiles)]
		else
			target_tile = self:get_tile()
		end
	end
	
	local start_tile = self:get_tile()
	if #tiles > 1 then
		while target_tile == start_tile do
		-- pick another, don't try to jump on the same tile if it's not necessary
		target_tile = tiles[math.random(#tiles)]
		end
	end
  
  return target_tile
end

function find_valid_move_location_back_row(self)
	local target_tile
	local field = self:get_field()

	local tiles = field:find_tiles(function(tile)
		return self.can_move_to_func_back_row(tile)
	end)
  
	--print (#tiles)
	if #tiles >= 1 then
		target_tile = tiles[math.random(#tiles)]
	else
		
		tiles = field:find_tiles(function(tile)
			return self.can_move_to_func(tile)
		end)
		
		if #tiles >= 1 then 
			target_tile = tiles[math.random(#tiles)]
		else
			target_tile = self:get_tile()
		end
	end
	
	local start_tile = self:get_tile()
	if #tiles > 1 then
		while target_tile == start_tile do
		-- pick another, don't try to jump on the same tile if it's not necessary
		target_tile = tiles[math.random(#tiles)]
		end
	end
  
  return target_tile
end

function exploding_line(self)
	self.move_counter = 0
	local anim = self:get_animation()
	anim:set_state("TELEPORT_OUT")
	anim:on_complete(function()
		local target_tile = find_valid_move_location_targeted(self)
		self:slide(target_tile, frames(0), frames(0), ActionOrder.Voluntary, function()
		end)
		anim:set_state("TELEPORT_IN")
		anim:on_complete(function()
			anim:set_state("EXPLODING_LINE")
			self:toggle_counter(true)
			anim:on_frame(5, function()
				self:toggle_counter(false)
				--Engine.play_audio(slam_sfx, AudioPriority.Highest)
				spawn_explosion(self,self:get_field())
			end)
			anim:on_complete(function()
				self:toggle_counter(false)
				idle(self)
			end)
		end)

	end)
	return
end

function spawn_explosion(owner, field)
    local spawn_next
	local tile = owner:get_tile(owner:get_facing(),1)
    spawn_next = function()
        --Engine.play_audio(wave_sfx, AudioPriority.Highest)

        local spell = Battle.Spell.new(owner:get_team())
        spell:set_facing(owner:get_facing())
        spell:highlight_tile(Highlight.Solid)
        spell:set_hit_props(HitProps.new(exploding_line_dmg, Hit.Impact | Hit.Flinch | Hit.Flash, Element.Fire, owner:get_context() , Drag.None))

        local sprite = spell:sprite()
        sprite:set_texture(exploding_line_texture)
		sprite:set_layer(-1)

        local animation = spell:get_animation()
        animation:load(exploding_line_animation)
        animation:set_state("DEFAULT")
        animation:refresh(sprite)
		animation:set_playback_speed(anim_speed)
        animation:on_frame(4, function()
            tile = tile:get_tile(owner:get_facing(), 1)
			if tile:is_edge() then return end
            spawn_next()
        end, true)
        animation:on_complete(function() spell:erase() end)

        spell.update_func = function()
            spell:get_current_tile():attack_entities(spell)
        end
		
		spell.collision_func = function()
			spell:erase()
			return
		end

       field:spawn(spell, tile)
	   Engine.play_audio(explosion_sfx, AudioPriority.Highest)
    end

    spawn_next()
end

function fire_tornado(self)
	self.move_counter = 0
	local anim = self:get_animation()
	anim:set_state("TELEPORT_OUT")
	anim:on_complete(function()
		local target_tile = find_valid_move_location_targeted_three(self)
		self:slide(target_tile, frames(0), frames(0), ActionOrder.Voluntary, function()
		end)
		anim:set_state("TELEPORT_IN")
		anim:on_complete(function()
		self:toggle_counter(true)
			anim:set_state("CHARGE_FIRE_TORNADO")
			local spell = Battle.Spell.new(self:get_team())
			spell:set_facing(self:get_facing())
			spell:highlight_tile(Highlight.Solid)
			self:get_field():spawn(spell, self:get_tile(self:get_facing(),1))
			self:get_field():spawn(spell, self:get_tile(self:get_facing(),2))
			self:get_field():spawn(spell, self:get_tile(self:get_facing(),3))
			local yellow_counter = 0
			spell.update_func = function()
				--print("in update func")
				yellow_counter = yellow_counter + 1
				if yellow_counter == 200 then
					spell.update_func = function()end
					spell:erase()
				end
			end
			
			
			anim:on_complete(function()
				self:toggle_counter(false)
				anim:set_state("SHOOT_FIRE_TORNADO")
				anim:on_frame(2, function()
					spell:erase()
					spawn_fire_tornado(self, self:get_field())
				end)
				anim:on_complete(function()
					idle(self)
				end)
			end)
		end)
	end)
	return
end

function spawn_fire_tornado(owner, field)
    
	local spell2 = Battle.Spell.new(owner:get_team())
    spell2:set_facing(owner:get_facing())
	local sprite2 = spell2:sprite()
	sprite2:set_texture(tummy_fire_texture)
	sprite2:set_layer(-1)

	local animation2 = spell2:get_animation()
	animation2:load(tummy_fire_animation)
	animation2:set_state("DEFAULT")
	animation2:refresh(sprite2)
	animation2:set_playback_speed(anim_speed)
	animation2:on_complete(function() 
        spell2:erase() 
	end)
	
	field:spawn(spell2, owner:get_tile())
	Engine.play_audio(tornado_sfx, AudioPriority.Highest)
	
	local x = 1
    while x < 4 do 
        local spell = Battle.Spell.new(owner:get_team())
        spell:set_facing(owner:get_facing())
        spell:highlight_tile(Highlight.Solid)
        spell:set_hit_props(HitProps.new(fire_tornado_dmg, Hit.Impact | Hit.Flinch | Hit.Flash, Element.Fire, owner:get_context() , Drag.None))
    
        local sprite = spell:sprite()
        sprite:set_texture(fire_tornado_texture)
        sprite:set_layer(-1)
    
        local animation = spell:get_animation()
        animation:load(fire_tornado_animation)
        animation:set_state("DEFAULT")
        animation:refresh(sprite)
        animation:set_playback_speed(anim_speed)
        animation:on_complete(function() 
            spell:erase() 
        end)
		
		spell.update_func = function()
            spell:get_current_tile():attack_entities(spell)
        end
		
        field:spawn(spell, owner:get_tile(owner:get_facing(),x))
        x = x + 1
    end
	

	
    return
end

function fire_wave(self)
	self.move_counter = 0
	local anim = self:get_animation()
	anim:set_state("TELEPORT_OUT")
	anim:on_complete(function()
		local target_tile = find_valid_move_location_back_row(self)
		self:slide(target_tile, frames(0), frames(0), ActionOrder.Voluntary, function()
		end)
		anim:set_state("TELEPORT_IN")
		anim:on_complete(function()
			wind_toggle = true
			anim:set_state("CHARGE_FIRE_WAVE")
			local field = self:get_field()
			
			if math.random(1,2) == 1 then
				wind_dir = "ver"
			else
				wind_dir = "hor"
			end
			local counter = 0
			local random_number = 10
			self.update_func = function()
				local result = counter % random_number
				if (result == 0) then
					if wind_dir == "hor" then
						local spawn_tile = math.random(1,3)
						spawn_wind(self, field, spawn_tile)
						random_number = math.random(15,30)
					elseif wind_dir == "ver" then
						local spawn_tile = math.random(1,6)
						spawn_wind(self, field, spawn_tile)
						random_number = math.random(10,25)
					end
				end
				counter = counter + 1
			end
			
			anim:on_complete(function()
				self.update_func = function() end
				anim:set_state("SHOOT_FIRE_WAVE")
				
				if wind_dir == "hor" then
					local fireball = spawn_fireball(self)
					local tile = field:tile_at(7,1)
					field:spawn(fireball,tile)
					local fireball = spawn_fireball(self)
					local tile = field:tile_at(7,2)
					field:spawn(fireball,tile)
					local fireball = spawn_fireball(self)
					local tile = field:tile_at(7,3)
					field:spawn(fireball,tile)
				elseif wind_dir == "ver" then
					local fireball = spawn_fireball(self)
					local tile = field:tile_at(1,4)
					field:spawn(fireball,tile)
					local fireball = spawn_fireball(self)
					local tile = field:tile_at(2,4)
					field:spawn(fireball,tile)
					local fireball = spawn_fireball(self)
					local tile = field:tile_at(3,4)
					field:spawn(fireball,tile)
					local fireball = spawn_fireball(self)
					local tile = field:tile_at(4,4)
					field:spawn(fireball,tile)
					local fireball = spawn_fireball(self)
					local tile = field:tile_at(5,4)
					field:spawn(fireball,tile)
					local fireball = spawn_fireball(self)
					local tile = field:tile_at(6,4)
					field:spawn(fireball,tile)
				end
				Engine.play_audio(fireball_sfx, AudioPriority.Highest)
				
				anim:on_complete(function()
					idle(self)
				end)
				
				
				
			end)
		end)

	end)
	return
end

function spawn_wind(owner,field, spawn_tile)
    local spell = Battle.Spell.new(owner:get_team())
    spell:set_facing(owner:get_facing())
	spell:set_offset(0.0, -30.0)
    --spell:highlight_tile(Highlight.Solid)
    spell:set_hit_props(HitProps.new(0, Hit.None, Element.Fire, owner:get_context() , Drag.None))

    local sprite = spell:sprite()
    sprite:set_texture(wind_texture)
    sprite:set_layer(-1)

    local animation = spell:get_animation()
    animation:load(wind_animation)
    if wind_dir == "hor" then
        animation:set_state("WIND_HOR")
    else
        animation:set_state("WIND_VER")
    end
    animation:refresh(sprite)
    animation:set_playback_speed(anim_speed)
    animation:set_playback(Playback.Loop)
    
    
	
	local do_once = true
	local loop_count = 0
	spell.update_func = function()
	
		if do_once then 
			if wind_dir == "hor" then
				dest = field:tile_at(0,spawn_tile)
			elseif wind_dir == "ver" then
				dest = field:tile_at(spawn_tile,0)
			end
			spell:slide(dest, frames(50), frames(0), ActionOrder.Voluntary, function()end)
			do_once = false
		end
		if loop_count >= 10 then
			if spell:is_sliding() == false then
				spell:delete()
			end
		end
		
		loop_count = loop_count + 1
		
	end
	
	spell.can_move_to_func = function(tile)
        return true
    end
    
    
    if wind_dir == "hor" then
		tile = field:tile_at(7,spawn_tile)
	elseif wind_dir == "ver" then
		tile = field:tile_at(spawn_tile,4)
	end
	
    field:spawn(spell, tile)
    
    return
end

function spawn_fireball(owner)
    local spell = Battle.Spell.new(owner:get_team())
    spell:set_facing(owner:get_facing())
	if wind_dir == "hor" then
		spell:set_offset(-25, -30.0)
	else
		spell:set_offset(0.0, -30.0)
	end
	spell:set_texture(fireball_texture, true)
    spell:highlight_tile(Highlight.Solid)
    spell:set_hit_props(HitProps.new(fireball_dmg, Hit.Impact | Hit.Flinch | Hit.Flash, Element.Fire, owner:get_context(), Drag.None))

    local animation = spell:get_animation()
    animation:load(fireball_animation)
    if wind_dir == "hor" then
        animation:set_state("FIREBALL_HOR")
    else
        animation:set_state("FIREBALL_VER")
    end
    animation:set_playback_speed(anim_speed)
    animation:set_playback(Playback.Loop)
     

	spell.update_func = function(self, dt) 
        self:get_current_tile():attack_entities(self)

        if self:is_sliding() == false then 
            if self:get_current_tile():is_edge() and self.slide_started then 
                self:delete()
            end 

            if wind_dir == "hor" then
				dest = self:get_tile(spell:get_facing(), 1)
			elseif wind_dir == "ver" then
				dest = self:get_tile(Direction.Up, 1)
			end
            local ref = self
            self:slide(dest, frames(fireball_speed), frames(0), ActionOrder.Voluntary, 
                function()
                    ref.slide_started = true 
                end
            )
        end
    end
	
	spell.attack_func = function() 
        -- nothing
    end
	
	spell.can_move_to_func = function(tile)
        return true
    end
	
	spell.collision_func = function()
		spell:erase()
	end
	
	spell.delete_func = function(self) 
    end
        
    return spell
end
