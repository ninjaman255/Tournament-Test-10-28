local shared_package_init = include("./character.lua")
function package_init(character)
    local character_info = {
        name = "Rock",
        hp = 200,
        height = 44,
    }
    shared_package_init(character, character_info)
end
