-- Animations and Textures
local CHARACTER_ANIMATION = _folderpath .. "battle.animation"
local CHARACTER_TEXTURE = Engine.load_texture(_folderpath .. "battle.png")
--possible states for character
local states = { DEFAULT = 1, SEEK = 2, ATTACK = 3 }
-- Load character resources
---@param self Entity
function package_init(self, character_info)
    -- Required function, main package information
    local base_animation_path = CHARACTER_ANIMATION
    self:set_texture(CHARACTER_TEXTURE)
    self.animation = self:get_animation()
    self.animation:load(base_animation_path)
    -- Load extra resources
    -- Set up character meta
    -- Common Properties
    self:set_name(character_info.name)
    self:set_health(character_info.hp)
    self:set_height(character_info.height)

    --Other Setup
    self:set_explosion_behavior(1, 1, false)
    -- entity will spawn with this animation.
    self.animation:set_state("IDLE")
end

return package_init
