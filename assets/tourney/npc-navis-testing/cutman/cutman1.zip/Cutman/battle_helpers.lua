--Functions for easy reuse in scripts
--Version 1.0

---@class BattleHelper
battle_helpers = {}

---comment
---@param field #reference to battlefield
---@param tile #tile to spawn the visual artifact on
---@param texture #texture to use
---@param animation_path #path to animation
---@param animation_state #state to use
---@param position_x #offsetX
---@param position_y #offsetY
function battle_helpers.spawn_visual_artifact(field, tile, texture, animation_path, animation_state, position_x,
                                              position_y)
    local visual_artifact = Battle.Artifact.new()
    visual_artifact:set_texture(texture, true)
    local anim = visual_artifact:get_animation()
    anim:load(animation_path)
    anim:set_state(animation_state)
    anim:on_complete(function()
        visual_artifact:delete()
    end)
    visual_artifact:sprite():set_offset(position_x, position_y)
    anim:refresh(visual_artifact:sprite())
    field:spawn(visual_artifact, tile:x(), tile:y())
end

battle_helpers.can_move_to_func = function(tile, entity)
    if not tile:is_walkable() or tile:get_team() ~= entity:get_team() or
        tile:is_reserved({ entity:get_id(), entity._reserver }) then
        return false
    end

    local has_character = false

    tile:find_characters(function(c)
        if c:get_id() ~= entity:get_id() then
            has_character = true
        end
        return false
    end)

    tile:find_obstacles(function(c)
        if c:get_health() > 1 and c:get_id() ~= entity:get_id() then
            has_character = true
        end
        return false
    end)

    return not has_character
end

-- This function returns a target enemy.
function battle_helpers.find_target(self)
    local field = self:get_field()
    local team = self:get_team()
    local target_list = field:find_characters(function(other_character)
        return other_character:get_team() ~= team
    end)
    if #target_list == 0 then

        return
    end
    local target_character = target_list[1]
    return target_character
end

battle_helpers.can_move_to_func_front_row = function(tile)
    if not tile:is_walkable() or tile:get_team() ~= self:get_team() or
        tile:is_reserved({ self:get_id(), self._reserver }) then
        return false
    end

    local has_character = false

    tile:find_characters(function(c)
        if c:get_id() ~= self:get_id() then
            has_character = true
        end
        return false
    end)

    if tile:get_tile(Direction.Left, 1):get_team() == self:get_team() then
        has_character = true
    end

    return not has_character
end


battle_helpers.can_move_to_func_target_enemy = function(tile)

    if not tile:is_walkable() or tile:get_team() ~= self:get_team() or
        tile:is_reserved({ self:get_id(), self._reserver }) then
        return false
    end

    local has_enemy = false
    local x = 0
    while x < 6 do
        if tile:get_tile(Direction.Left, x):is_edge() then
            return has_enemy
        end
        tile:get_tile(Direction.Left, x):find_characters(function(c)
            if c:get_id() ~= self:get_id() then
                has_enemy = true
            end
            return false
        end)
        x = x + 1
    end
    return has_enemy



end

function battle_helpers.find_target(self)
    local field = self:get_field()
    local team = self:get_team()
    local target_list = field:find_characters(function(other_character)
        return other_character:get_team() ~= team
    end)
    if #target_list == 0 then
        print("No targets found!")
        return
    end
    local target_character = target_list[1]
    return target_character
end

-- This function moves the character to an adjacent tile.
function battle_helpers.move_random_adjacent(character)
    local field = character:get_field()
    local my_tile = character:get_tile()
    local tile_array = {}
    local adjacent_tiles = { my_tile:get_tile(Direction.Up, 1),
        my_tile:get_tile(Direction.Down, 1),
        my_tile:get_tile(Direction.Left, 1),
        my_tile:get_tile(Direction.Right, 1)
    }
    for index, prospective_tile in ipairs(adjacent_tiles) do
        if battle_helpers.can_move_to_func(prospective_tile, character) and prospective_tile ~= character.last_tile and
            my_tile ~= prospective_tile then
            table.insert(tile_array, prospective_tile)
        end
    end
    if #tile_array == 0 then return false end
    target_tile = tile_array[math.random(1, #tile_array)]
    if target_tile then
        moved = character:teleport(target_tile, ActionOrder.Immediate)
        character.last_tile = character:get_tile()
    end
    return moved
end

--This function moves the character towards a position.
function battle_helpers.move_towards_row(character, row)
    local field = character:get_field()
    local my_tile = character:get_tile()
    local tile_array = {}
    local target_tile = nil

    -- Check which tile the bunny needs to move towards to reach megaman.
    if (row < my_tile:y()) then
        target_tile = my_tile:get_tile(Direction.Up, 1)
    else
        target_tile = my_tile:get_tile(Direction.Down, 1)
    end

    if battle_helpers.can_move_to_func(target_tile, character) then
        moved = character:teleport(target_tile, ActionOrder.Immediate)
        return moved
    else
        --if cant move to prospective tile, move to a random tile left or right.
        local alternate_tiles = { my_tile:get_tile(Direction.Left, 1),
            my_tile:get_tile(Direction.Right, 1) }

        for index, prospective_tile in ipairs(alternate_tiles) do
            if battle_helpers.can_move_to_func(prospective_tile, character) and
                my_tile ~= prospective_tile then
                table.insert(tile_array, prospective_tile)
            end
        end
        if #tile_array == 0 then return false end
        target_tile = tile_array[math.random(1, #tile_array)]
        if target_tile then
            moved = character:teleport(target_tile, ActionOrder.Immediate)
        end
        return moved
    end
end

--- Moves character in front of enemy as close as possible.
---@param character any
---@param enemy_char any
---@return Tile
function battle_helpers.move_in_front_of_enemy(character, enemy_char)
    local field = character:get_field()
    local my_tile = character:get_tile()
    local available_tiles = {}

    -- add tiles in row from enemy char to end of field
    local check_tile = enemy_char:get_tile()
    while not check_tile:is_edge() do
        table.insert(available_tiles, check_tile)
        check_tile = check_tile:get_tile(enemy_char:get_facing(), 1)
    end

    for index, prospective_tile in ipairs(available_tiles) do
        if battle_helpers.can_move_to_func(prospective_tile, character) then
            character:teleport(prospective_tile, ActionOrder.Immediate)
            return prospective_tile
        end
    end
    return nil
end

function Tiletostring(tile)
    return "Tile: [" .. tostring(tile:x()) .. "," .. tostring(tile:y()) .. "]"
end

return battle_helpers
