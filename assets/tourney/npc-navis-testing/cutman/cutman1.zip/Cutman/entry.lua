local shared_package_init = include("./character.lua")
function package_init(character)
    local character_info = {
        name = "Cutman",
        hp = 900,
        scissor_damage = 80,
        boomerang_damage = 100,
        cut_damage = 100,
        palette = _folderpath .. "palette.png",
        height = 44,
        frames_between_actions = 34,
        fast_hop_frames = 4,
        scissor_max = 1
    }
    if character:get_rank() == Rank.EX then
        character_info.hp = 1200
        character_info.scissor_damage = 160
        character_info.boomerang_damage = 140
        character_info.cut_damage = 150
        character_info.scissor_max = 2
    end
	if character:get_rank() == Rank.SP then
        character_info.hp = 1500
        character_info.scissor_damage = 200
        character_info.boomerang_damage = 280
        character_info.cut_damage = 250
        character_info.scissor_max = 2
    end
    if character:get_rank() == Rank.NM then
        character_info.damage = 250
        character_info.palette = _folderpath .. "DS.png"
        character_info.hp = 2500
        character_info.scissor_damage = 240
        character_info.boomerang_damage = 260
        character_info.cut_damage = 300
        character_info.scissor_max = 3
        character_info.frames_between_actions = 23
    end
    shared_package_init(character, character_info)
end
