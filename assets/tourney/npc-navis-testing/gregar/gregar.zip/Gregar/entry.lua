----
--[[

    BurnerMan boss character from "Rockman EXE6: Cyber Beast Gregar/Cyber Beast Falzar"
    Ported to Open Net Battle (ONB) by K1rbYat1Na

    TODO:
    Must have 2 independent hitboxes, on mouth and body. Has only one right now (on body).
    Falling rocks should have the "Pierce Underground" property (movement & Beast Pressure).
    Gatling Tail should have the "Pierce Underground" property.
    Beast Out Impact's claws should have the "Delete Card" property.
    Beast Pressure's direct hit should have the "Pierce Underground" property.
    Maybe do some fixes for Beast Out Impact's fang attack.

    Other notes:
    "Pierce Guard" - can damage through shields (e.g., Met Guard, Reflecmet, Blues Shield). Destroys Obstacles on hit.
    "Pierce Invisible" - can damage through the Invisible effect.
    "Pierce Underground" - can damage through the Yukashita/Yukashita Mogura effect.
    "Delete Card" - deletes 1 chip from the hit Character's hand.
    It's impossible to hit both hitboxes at once. If an attack hits both hitboxes on the same frame (e.g., Dream Sword), Gregar only takes damage once.

    Moveset:

    Gregar has Air Shoes (can step on holes), Float Shoes (can't be affected by panels), and Super Armor (can't flinch).
    Gregar does the falling rocks attack twice in a row, then uses of the next attacks.

    Attacks:

    "FALLING ROCKS" (movement)
    Gregar jumps up and two rocks rain down on the enemy's area when it lands. It will follow up with one of the following.
    Non-elemental. Causes Flinching and Flashing. Has "Pierce Guard" property.

    BURNING BREATH
    Gregar fires his fire breath attack, covering the panel immediately in front of it and the back two columns of the enemy's area.
    Fire-elemental. Causes Flinching and Flashing. Hitboxes can only damage the same entity once.

    LIGHTNING BREATH
    Gregar fires its elec breath attacks, hitting the front of the enemy's area and his current row.
    Elec-elemental. Causes Stun for 90 frames (1.5 seconds). Has "Pierce Invisible" property.

    GATLING TAIL
    Gregar readies its tail and fires it up and down the enemy's column. In the SP version, this attack also tracks the enemy's current column as it is in use.

    BEAST OUT IMPACT
    Gregar disappears. Then, a 2x3 area just in front of the enemy's back column lights up. His claws will slash that area, while his head will rush down the row.
    Claws:
    Non-elemental. Don't cause Flinching or Flashing. Has "Pierce Guard" and "Delete Card" properties.
    Fang:
    Non-elemental. Causes Flinching and Flashing.  Has "Pierce Guard" property.
    
]]--
----

local print_debug = false -- Turns on/off the debug text.

-- THE CHARACTER GRAPHIC ASSETS --
local GREGAR_TEXTURE = Engine.load_texture(_folderpath.."gfx/gregar.png") --.grayscaled
local GREGAR_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/gregar.png")
local GREGAR_ANIMPATH = _folderpath.."gfx/gregar.animation"
local OTHERS_TEXTURE = Engine.load_texture(_folderpath.."gfx/gregar2.grayscaled.png")
local OTHERS_ANIMPATH = _folderpath.."gfx/gregar2.animation"
local STONE_TEXTURE = Engine.load_texture(_folderpath.."gfx/stone.grayscaled.png")
local STONE_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/stone.png")
local STONE_ANIMPATH = _folderpath.."gfx/stone.animation"
----------------------------------

-- OTHER GRAPHIC ASSETS --
local BURNINGBREATH_TEXTURE = Engine.load_texture(_folderpath.."gfx/burningbreath.grayscaled.png")
local BURNINGBREATH_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/burningbreath.png")
local BURNINGBREATH_ANIMPATH = _folderpath.."gfx/burningbreath.animation"
local LIGHTNINGBREATH_TEXTURE = Engine.load_texture(_folderpath.."gfx/lightningbreath.grayscaled.png")
local LIGHTNINGBREATH_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/lightningbreath.png")
local LIGHTNINGBREATH_ANIMPATH = _folderpath.."gfx/lightningbreath.animation"
local SLASH_TEXTURE = Engine.load_texture(_folderpath.."gfx/slash.grayscaled.png")
local SLASH_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/slash.png")
local SLASH_ANIMPATH = _folderpath.."gfx/slash.animation"
--------------------------

-- SHADOWS --
local SHADOW1_TEXTURE = Engine.load_texture(_folderpath.."gfx/shadow1.png")
local SHADOW2_TEXTURE = Engine.load_texture(_folderpath.."gfx/shadow2.png")
-------------

-- HIT GFXS --
local EFFECT1_TEXTURE = Engine.load_texture(_folderpath.."gfx/effect1.grayscaled.png")
local EFFECT1_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/effect1.png")
local EFFECT1_ANIMPATH = _folderpath.."gfx/effect1.animation"
local EFFECT2_TEXTURE = Engine.load_texture(_folderpath.."gfx/effect2.grayscaled.png")
local EFFECT2_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/effect2.png")
local EFFECT2_ANIMPATH = _folderpath.."gfx/effect2.animation"
local EFFECT13_TEXTURE = Engine.load_texture(_folderpath.."gfx/effect13.grayscaled.png")
local EFFECT13_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/effect13.png")
local EFFECT13_ANIMPATH = _folderpath.."gfx/effect13.animation"
local EFFECT_CHIP_TEXTURE = Engine.load_texture(_folderpath.."gfx/effect_chip.grayscaled.png")
local EFFECT_CHIP_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/effect_chip.png")
local EFFECT_CHIP_ANIMPATH = _folderpath.."gfx/effect_chip.animation"
local BOOM_TEXTURE = Engine.load_texture(_folderpath.."gfx/boom.grayscaled.png")
local BOOM_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/boom.png")
local BOOM_ANIMPATH = _folderpath.."gfx/boom.animation"
--------------

-- AUDIO ASSETS --
local GREGAR_ROAR_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_239.ogg", true)
local GREGAR_SHAKE_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_18.ogg", true)
local GREGAR_STOMP_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_219.ogg", true)
local GREGAR_STOMP2_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_176.ogg", true)
local STONE_BREAK_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_193.ogg", true)
local STONE_BREAK2_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_101.ogg", true)
local BURNINGBREATH_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_344.ogg", true)
local LIGHTNINGBREATH_CHARGE_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_164.ogg", true)
local LIGHTNINGBREATH_ATTACK_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_70.ogg", true)
local CANNON_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_278.ogg", true)
local BEASTOUTIMPACT_CLAW_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_207.ogg", true)
local BEASTOUTIMPACT_FANG_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_124.ogg", true)
------------------

-- Prints the debug text.
local function debug_print(text)
    if print_debug then
        print("[Gregar] "..text)
    end
end

--(Function by Alrysc, edited by K1rbYat1Na)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or nil
    facing = facing or nil
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

local function find_best_target(user)
    --local facing = user:get_facing()
    local target = nil
    local field = user:get_field()
    local query = function(c)
        return c:get_team() ~= user:get_team()
    end
    local potential_threats = field:find_characters(query)
    local goal_hp = 0
    if #potential_threats > 0 then
        for i = 1, #potential_threats, 1 do
            local possible_target = potential_threats[i]
            if possible_target and not possible_target:is_deleted() and possible_target:get_health() >= goal_hp then
                target = possible_target
            end
        end
    end
    return target
end

--@beastpresure - boolean - if true, increases damage and changes landing SFX. Used for Gregar's Beast Pressure.
local function create_rock(user, target_tile, beastpressure)
    local rock = graphic_init("spell", 0, 0, STONE_TEXTURE, STONE_PALETTE, STONE_ANIMPATH, -3, "0", Playback.Once, user, user:get_facing())
    rock:set_name("FallingRock")
    local speed = 12
    local time = 0
    local initial_height = 332
    --local acceleration = initial_height/(fall_time*fall_time)
    local damage = user.damage_fallingrocks
    if beastpressure then
        damage = user.damage_beastpressure_fallingrocks
    end
    rock:set_hit_props(
        HitProps.new()
        :dmg(damage)
        :impact()
        :flinch()
        :flash()
        :pierce()
        --:underground()
        :retangible()
        :from(user:get_context())
        :no_counter()
    )
    rock.collision_func = function(self)
        --[[
        local hit_effect = graphic_init("artifact", 0, 0, EFFECT_TEXTURE, EFFECT_PALETTE, EFFECT_ANIMPATH, -999, "1", Playback.Once, user, user:get_facing(), true)
        hit_effect:get_animation():on_complete(function(self)
            hit_effect:delete()
        end)
        user:get_field():spawn(hit_effect, target_tile)
        ]]
    end
    rock:set_elevation(speed*27)
    rock:set_shadow(SHADOW1_TEXTURE)
    rock:show_shadow(true)
    local function rock_break(tile)
        local piece1 = graphic_init("artifact", 0, 0, STONE_TEXTURE, STONE_PALETTE, STONE_ANIMPATH, -3, "1", Playback.Once, user, user:get_facing())
        piece1.time = -6
        piece1.flash_count = 0
        piece1:set_shadow(SHADOW2_TEXTURE)
        piece1:show_shadow(true)
        local piece2 = graphic_init("artifact", 0, 0, STONE_TEXTURE, STONE_PALETTE, STONE_ANIMPATH, -3, "1", Playback.Once, user, user:get_facing())
        piece2.time = -8
        piece2.flash_count = 0
        piece2:set_shadow(SHADOW2_TEXTURE)
        piece2:show_shadow(true)
        piece1.update_func = function(self)
            local time = self.time
            if self:get_elevation() > -1 then 
                self:set_offset(self:get_offset().x + 4, 0)
                self:set_elevation(-((time*time)/2 - 20))
            else
                if time % 4 < 2 then
                    self:hide()
                    if self.flash_count > 3 then
                        self:delete()
                    end
                else
                    self:reveal()
                    self.flash_count = self.flash_count + 1
                end
            end
            self.time = self.time+1
        end
        piece2.update_func = function(self)
            local time = self.time
            if self:get_elevation() > -1 then 
                self:set_offset(self:get_offset().x - 2, 0)
                self:set_elevation(-((time*time)/3 - 30))
            else
                if time % 4 < 2 then
                    self:hide()
                    if self.flash_count > 3 then
                        self:delete()
                    end
                else
                    self:reveal()
                    self.flash_count = self.flash_count + 1
                end
            end
            self.time = self.time+1
        end
        user:get_field():spawn(piece1, tile)
        user:get_field():spawn(piece2, tile)
    end
    rock.update_func = function(self)
        if self:get_elevation() == 0 then 
            self:delete()
            rock_break(self:get_tile())
            if not beastpressure then
                Engine.play_audio(STONE_BREAK_AUDIO, AudioPriority.Low)
            end
            self:get_tile():attack_entities(self)
            return
        end
        --rock:set_elevation(initial_height - speed*time)
        self:set_elevation(self:get_elevation() - speed)
        time = time + 1
        if time == 20 then 
            speed = speed + 2
        end
    end
    rock.attack_func = function(self, other)
        local offset_x = math.random(-6,5)
        local offset_y = math.random(-7,4)
        local hit_effect = graphic_init("artifact", (offset_x*2), (offset_y*2), EFFECT1_TEXTURE, EFFECT1_PALETTE, EFFECT1_ANIMPATH, -999, "0", Playback.Once, self, self:get_facing(), true, true, true)
        self:get_field():spawn(hit_effect, self:get_tile())
        --if Battle.Obstacle.from(other) ~= nil then other:set_health(0) end
    end
    user:get_field():spawn(rock, target_tile)
end

local function drop_rock(user, drop_tile, beastpressure)
    local spell = Battle.Spell.new(user:get_team())
    spell:set_name("FallingRock")
    local counter = 13

    spell.update_func = function(self)
        if counter > 0 then 
            drop_tile:highlight(Highlight.Flash)
        elseif counter == 0 then 
            create_rock(user, drop_tile, beastpressure)
            self:delete()
        end
        counter = counter - 1
    end

    user:get_field():spawn(spell, drop_tile)
end

local function rock_spawner2(user, frames)
    local spawner = Battle.Spell.new(user:get_team())
    --
    spawner.frames = 1
    spawner.update_func = function(self)
        for f=1,#user.beastpressure_frames do
            if self.frames == user.beastpressure_frames[f] then
                local tile_filter = function(tile)
                    return not tile:is_edge() and tile:get_team() ~= user:get_team() and #tile:find_entities(function(c) return c:get_name() == "FallingRock" end) <= 0
                end
                user.tile_list = user:get_field():find_tiles(tile_filter)
                local enemy_filter = function(character)
                    return character:get_team() ~= user:get_team() and character:get_health() > 0
                end
                local enemy_list = user:get_field():find_nearest_characters(user, enemy_filter)
                local stone = nil
                if enemy_list[1] then
                    stone = enemy_list[1]:get_tile()
                end
                if stone == nil or #stone:find_entities(function(c) return c:get_name() == "FallingRock" end) > 0 then
                    if #user.tile_list > 0 then
                        stone = user.tile_list[math.random(1, #user.tile_list)]
                    end
                end
                if stone ~= nil then
                    drop_rock(user, stone, true)
                end
            end
        end
        if self.frames == 196 then
            self:delete()
        end
        self.frames = self.frames + 1
    end
    spawner.battle_end_func = function(self, other)
        self:delete()
    end
    spawner.delete_func = function(self, other)
        self:erase()
    end
    user:get_field():spawn(spawner,0,0)
    return spawner
end

local function rock_spawner(user)
    local spawner = Battle.Spell.new(user:get_team())
    --
    spawner.frames = 1
    spawner.update_func = function(self)
        for i=1, 13, 12 do
            if self.frames == i then
                local tile_filter = function(tile)
                    return not tile:is_edge() and tile:get_team() ~= user:get_team() and #tile:find_entities(function(c) return c:get_name() == "FallingRock" end) <= 0
                end
                user.tile_list = user:get_field():find_tiles(tile_filter)
                local enemy_filter = function(character)
                    return character:get_team() ~= user:get_team() and character:get_health() > 0
                end
                local enemy_list = user:get_field():find_nearest_characters(user, enemy_filter)
                local stone = nil
                if enemy_list[1] then
                    stone = enemy_list[1]:get_tile()
                end
                if stone == nil or #stone:find_entities(function(c) return c:get_name() == "FallingRock" end) > 0 then
                    if #user.tile_list > 0 then
                        stone = user.tile_list[math.random(1, #user.tile_list)]
                    end
                end
                if stone ~= nil then
                    drop_rock(user, stone)
                end
            end
        end
        if self.frames == 14 then
            self:delete()
        end
        self.frames = self.frames + 1
    end
    spawner.battle_end_func = function(self, other)
        self:delete()
    end
    spawner.delete_func = function(self, other)
        self:erase()
    end
    user:get_field():spawn(spawner,0,0)
    return spawner
end

local function create_burning_hitbox(user, tile)
    local hitbox = graphic_init("spell", 0, 0, BURNINGBREATH_TEXTURE, BURNINGBREATH_PALETTE, BURNINGBREATH_ANIMPATH, -3, "0", Playback.Loop, user, user:get_facing())
    hitbox:set_hit_props(
        HitProps.new()
        :dmg(user.damage_burningbreath)
        :impact()
        :flinch()
        :flash()
        :from(user:get_context())
        :elem(Element.Fire)
    )
    hitbox.frames = 0
    hitbox.update_func = function(self)
        if user.flinching then
            self:delete()
        end
        self.frames = self.frames + 1
        self:highlight_tile(Highlight.Solid)
        self:get_tile():attack_entities(self)
        if self.frames == 116 then
            self:get_animation():set_state("1")
            self:get_animation():refresh(self:sprite())
        end
        if self.frames == 121 then
            self:delete()
        end
    end
    hitbox.attack_func = function(self, other)
        local offset_x = math.random(-6,5)
        local offset_y = math.random(-7,4)
        local hit_effect = graphic_init("artifact", (offset_x*2), (offset_y*2), EFFECT2_TEXTURE, EFFECT2_PALETTE, EFFECT2_ANIMPATH, -999, "0", Playback.Once, self, self:get_facing(), true, true, true)
        user:get_field():spawn(hit_effect, self:get_tile())
    end
    hitbox.battle_end_func = function(self, other)
        self:delete()
    end
    hitbox.delete_func = function(self, other)
        self:erase()
    end
    user:get_field():spawn(hitbox, tile)
    return hitbox
end

local function create_lightning_hitbox(user, tile)
    local hitbox = Battle.Spell.new(user:get_team())
    hitbox:set_facing(user:get_facing())
    hitbox:set_hit_props(
        HitProps.new()
        :dmg(user.damage_lightningbreath)
        :impact()
        :pierce()
        :retangible()
        :flinch()
        :stun(frames(90))
        :from(user:get_context())
        :elem(Element.Elec)
    )
    hitbox.update_func = function(self)
        self:highlight_tile(Highlight.Solid)
        self:get_tile():attack_entities(self)
        if (user.lightning1 == nil or user.lightning1:is_deleted()) or (user.lightning2 == nil or user.lightning2:is_deleted())  then
            self:delete()
        end
    end
    hitbox.battle_end_func = function(self, other)
        self:delete()
    end
    hitbox.delete_func = function(self, other)
        self:erase()
    end
    user:get_field():spawn(hitbox, tile)
    return hitbox
end

local function create_highlight(user, target_tile, hl_timer)
    local spell = Battle.Spell.new(user:get_team())
    spell.timer = hl_timer
    spell.update_func = function(self)
        if self.timer > 0 then
            self.timer = self.timer - 1
            self:highlight_tile(Highlight.Flash)
        else
            self:erase()
        end
    end
    user:get_field():spawn(spell, target_tile)
    return spell
end

local function create_gatling_hitbox(user, target_tile)
    local tail = graphic_init("spell", 0, 0, OTHERS_TEXTURE, GREGAR_PALETTE, OTHERS_ANIMPATH, -3, "TAIL", Playback.Once, user, user:get_facing())
    tail:set_hit_props(
        HitProps.new()
        :dmg(user.damage_gatlingtail)
        :impact()
        --:underground()
        --:retangible()
        :flinch()
        :flash()
        :from(user:get_context())
    )
    tail.timing = 2
    tail.elevation = 91*2
    tail:set_elevation(tail.elevation)
    tail.slide_started = false
    tail.on_spawn_func = function(self)
        Engine.play_audio(CANNON_AUDIO, AudioPriority.Low)
        local shoot = graphic_init("artifact", 0, 0, OTHERS_TEXTURE, GREGAR_PALETTE, OTHERS_ANIMPATH, -3, "SHOOT", Playback.Once, self, self:get_facing(), true)
        self:get_field():spawn(shoot, self:get_tile())
    end
    tail.can_move_to_func = function(tile) return true end
    tail.update_func = function(self)
        if self.timing > 0 then
            self.timing = self.timing - 1
        else
            if self.elevation > 14 then
                self.elevation = self.elevation - (13*2)
                self:set_elevation(self.elevation)
                local ref = self
                self:slide(target_tile, frames(6), frames(0), ActionOrder.Voluntary, function()
                    ref.slide_started = true
                end)
            else
                local hit_effect = graphic_init("artifact", 0, 0, BOOM_TEXTURE, BOOM_PALETTE, BOOM_ANIMPATH, -999, "0", Playback.Once, self, self:get_facing(), true, true, true)
                self:get_field():spawn(hit_effect, target_tile)
                --self:set_elevation(0)
                user.shake_component.timer = 17
                --user.shake_component.timer = user.shake_component.timer + 18
                --self:shake_camera(10, 0.283)
                target_tile:attack_entities(self)
                self:delete()
            end
        end
    end
    tail.battle_end_func = function(self, other)
        self:delete()
    end
    tail.delete_func = function(self, other)
        self:erase()
    end
    user:get_field():spawn(tail, user:get_tile())
    return tail
end

local function create_slash_hitbox(user, props)
    local hitbox = Battle.Spell.new(user:get_team())
    hitbox:set_facing(user:get_facing())
    hitbox:set_hit_props(props)
    hitbox.update_func = function(self)
        self:get_tile():attack_entities(self)
    end
    hitbox.attack_func = function(self, other)
        local offset_x = math.random(-6,5)
        local offset_y = math.random(-7,4)
        local hit_effect = graphic_init("artifact", (offset_x*2), (offset_y*2), EFFECT_CHIP_TEXTURE, EFFECT_CHIP_PALETTE, EFFECT_CHIP_ANIMPATH, -999, "0", Playback.Once, self, self:get_facing(), true, true, true)
        self:get_field():spawn(hit_effect, self:get_tile())
    end
    hitbox.battle_end_func = function(self, other)
        self:delete()
    end
    hitbox.delete_func = function(self, other)
        self:erase()
    end
    --user:get_field():spawn(hitbox, target_tile)
    return hitbox
end

local function create_slash(user, props, target_tile, state, dir_tile)
    local slash1 = graphic_init("artifact", 0, 0, SLASH_TEXTURE, SLASH_PALETTE, SLASH_ANIMPATH, -3, state, Playback.Once, user, user:get_facing(), true)
    local slash2 = graphic_init("spell", 0, 0, nil, nil, SLASH_ANIMPATH, nil, state, Playback.Once, user, user:get_facing())
    local hitbox1 = create_slash_hitbox(user, props)
    local hitbox2 = create_slash_hitbox(user, props)
    local hitbox3 = create_slash_hitbox(user, props)
    slash2.on_spawn_func = function()
        Engine.play_audio(BEASTOUTIMPACT_CLAW_AUDIO, AudioPriority.Low)
    end
    local slash_anim = slash2:get_animation()
    slash_anim:on_frame(2, function()
        user:get_field():spawn(hitbox1, target_tile:get_tile(dir_tile, 1))
    end)
    slash_anim:on_frame(3, function()
        hitbox1:erase()
        user:get_field():spawn(hitbox2, target_tile)
    end)
    slash_anim:on_frame(4, function()
        hitbox2:erase()
        user:get_field():spawn(hitbox3, target_tile:get_tile(Direction.reverse(dir_tile), 1))
    end)
    slash_anim:on_frame(5, function()
        hitbox3:erase()
    end)
    slash_anim:on_complete(function()
        slash2:erase()
    end)
    user:get_field():spawn(slash1, target_tile)
    user:get_field():spawn(slash2, target_tile)
    --return slash
end

local function create_claw(user, target_tile, slash_tile, state, dir_tile)
    local claw = graphic_init("spell", 0, 0, OTHERS_TEXTURE, GREGAR_PALETTE, OTHERS_ANIMPATH, -3, state, Playback.Once, user, user:get_facing())
    local props = HitProps.new()
    :dmg(user.damage_beastoutimpact_claw)
    :impact()
    :breaking()
    --:retangible()
    :flinch()
    :flash()
    :from(user:get_context())
    --Hit.DeleteCard
    claw:set_hit_props(props)
    claw.slide_started = false
    claw.on_spawn_func = function()
        create_slash(user, props, slash_tile, state, dir_tile)
    end
    claw.can_move_to_func = function(tile) return true end
    claw.update_func = function(self)
        --if self:is_deleted() then return end
        self:get_tile():attack_entities(self)
        local tile = self:get_tile(dir_tile, 1)
        local ref = self
        if (dir_tile == Direction.Up and tile == nil) or (dir_tile == Direction.Down and tile:is_edge()) then
            self:delete()
        else
            self:slide(tile, frames(3), frames(0), ActionOrder.Voluntary, function()
                ref.slide_started = true
            end)
        end
    end
    claw.attack_func = function(self, other)
        local offset_x = math.random(-6,5)
        local offset_y = math.random(-7,4)
        local hit_effect = graphic_init("artifact", (offset_x*2), (offset_y*2), EFFECT_CHIP_TEXTURE, EFFECT_CHIP_PALETTE, EFFECT_CHIP_ANIMPATH, -999, "0", Playback.Once, self, self:get_facing(), true, true, true)
        self:get_field():spawn(hit_effect, self:get_tile())
    end
    claw.battle_end_func = function(self, other)
        self:delete()
    end
    claw.delete_func = function(self, other)
        self:erase()
    end
    user:get_field():spawn(claw, target_tile)
    return claw
end

local function create_collision_attack1(user)
    local hitbox = Battle.Spell.new(user:get_team())
    hitbox:set_facing(user:get_facing())
    local props = HitProps.new()
    :dmg(user.damage_beastpressure_directhit)
    :impact()
    :breaking()
    --:underworld()
    --:retangible()
    :flinch()
    :flash()
    :from(user:get_context())
    hitbox:set_hit_props(props)
    hitbox.update_func = function(self)
        self:get_tile():attack_entities(self)
        self:erase()
    end
    hitbox.attack_func = function(self, other)
        --if Battle.Obstacle.from(other) ~= nil then other:delete() end
    end
    user:get_field():spawn(hitbox, user:get_tile())
    return hitbox
end

local function create_collision_attack2(user)
    local hitbox = Battle.Spell.new(user:get_team())
    hitbox:set_facing(user:get_facing())
    local props = HitProps.new()
    :dmg(user.damage_beastoutimpact_fang)
    :impact()
    :breaking()
    --:retangible()
    :flinch()
    :flash()
    :from(user:get_context())
    hitbox:set_hit_props(props)
    hitbox.update_func = function(self)
        self:get_tile():attack_entities(self)
    end
    hitbox.attack_func = function(self, other)
        local offset_x = math.random(-6,5)
        local offset_y = math.random(-7,4)
        local hit_effect = graphic_init("artifact", (offset_x*2), (offset_y*2), EFFECT13_TEXTURE, EFFECT13_PALETTE, EFFECT13_ANIMPATH, -999, "0", Playback.Once, user, user:get_facing(), true, true, true)
        user:get_field():spawn(hit_effect, other:get_tile())
    end
    hitbox.battle_end_func = function(self, other)
        self:delete()
    end
    hitbox.delete_func = function(self, other)
        self:erase()
    end
    return hitbox
end

local function check_characters(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_id() ~= self:get_id() and c:get_team() ~= self:get_team()
    end)
    return #characters > 0
end

local function check_characters_health(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0
    end)
    return #characters > 0
end

--(Function by Alrysc, edited by K1rbYat1Na)
function create_collision_attack(user, tile)
    local spell = Battle.Spell.new(user:get_team())
    local hit_props = HitProps.new()
    :dmg(user.damage)
    :impact()
    :flinch()
    :flash()
    :from(user:get_context())
    :elem(user:get_element())
    spell:set_hit_props(hit_props)
    spell.update_func = function(self)
        tile:attack_entities(self)
        self:delete()
    end
    user:get_field():spawn(spell, tile)
end

--(Function by Alrysc)
-- TODO: When we get is_passthrough or something, check to see if target became flashing before 
    -- we are allowed to spawn another one. Don't want to instakill viruses
-- self.collision_available can do something related to that. Does nothing now
function check_collision(self)
    local t = self:get_tile()
    if self.collision_available
    and (
    self:get_animation():get_state() == "B_LEGS_BEASTOUTIMPACT" or 
    self:get_animation():get_state() == "B_LEGS_BEASTPRESSURE_CHARGE" or 
    self:get_animation():get_state() == "B_LEGS_BEASTPRESSURE_HIT"
    )
    and check_characters(t, self) then 
        create_collision_attack(self, t)
    end
end

function package_init(self)
    self.anim_once = true
    self.anim_once_2 = false
    self.frames = 0
    self:set_name("Gregar")
    self.health = 2500
    self.damage = 10
    self.damage_fallingrocks = 50
    self.damage_burningbreath = 100
    self.damage_lightningbreath = 100
    self.damage_beastoutimpact_claw = 60
    self.damage_beastoutimpact_fang = 100
    self.damage_gatlingtail = 70
    self.damage_beastpressure_directhit = 180
    self.damage_beastpressure_fallingrocks = 180
    self.gatlingtail_can_track = false
    self.movement_frame = 30
    self.fallingrock_frame = 27
    self.burningbreath_frame = 31
    self.lightningbreath_frame = 31
    self.breath_frame = 121
    self.breath_frame2 = 13
    self.gatilingtail_shots = 9
    self.gatilingtail_end_delay = 60
    self.beastoutimpact_claw_delay = 16
    self.beastoutimpact_speed_frames = 5
    self.beastoutimpact_end_delay = 27
    self.beastpressure_frames = 
    { -- 19, 20
        4, 23, 42,
        62, 81, 100,
        120, 139, 158,
        178
    }
    self.beastpressure_speed_frames = 2
    if self:get_rank() == Rank.SP then
        self.health = 4000
        self.damage = 10
        self.damage_fallingrocks = 150
        self.damage_burningbreath = 300
        self.damage_lightningbreath = 300
        self.damage_beastoutimpact_claw = 180
        self.damage_beastoutimpact_fang = 300
        self.damage_gatlingtail = 210
        self.damage_beastpressure_directhit = 540
        self.damage_beastpressure_fallingrocks = 540
        self.gatlingtail_can_track = true
        self.movement_frame = 20
        self.fallingrock_frame = 15
        self.burningbreath_frame = 21
        self.lightningbreath_frame = 21
        --self.breath_frame = 121
        self.gatilingtail_shots = 12
        self.gatilingtail_end_delay = 40
        self.beastoutimpact_claw_delay = 10
        self.beastoutimpact_speed_frames = 4
        self.beastoutimpact_end_delay = 15
        self.beastpressure_frames = 
        { -- 13, 14
            4, 17, 30,
            44, 57, 70,
            84, 97, 110,
            124, 137, 150,
            164, 177, 190
        }
        self.beastpressure_speed_frames = 1
    end
    self:set_health(self.health)
    self:set_height(66)
	self:set_facing(Direction.Left)
    self:set_element(Element.None)
    self:set_explosion_behavior(11, 2, true)
    self:set_texture(GREGAR_TEXTURE)
    self:set_air_shoe(true)
    self:set_float_shoe(true)

    self:sprite():set_layer(0)
    self.b_legs_anim = self:get_animation()
    self.b_legs_anim:load(GREGAR_ANIMPATH)
    self.b_legs_anim:set_state("B_LEGS_IDLE")
    self.b_legs_anim:set_playback(Playback.Loop)
    self.b_legs_anim:refresh(self:sprite())

    self.shadow = self:create_node()
    self.shadow:set_texture(self:get_texture())
    self.shadow:set_layer(999)
    self.shadow:enable_parent_shader(true)
    self.shadow_anim = Engine.Animation.new(GREGAR_ANIMPATH)
    self.shadow_anim:copy_from(self:get_animation())
    self.shadow_anim:set_state("SHADOW_IDLE")
    self.shadow_anim:refresh(self.shadow)
    self.shadow_anim:set_playback(Playback.Loop)

    --self.shadow:set_color_mode(ColorMode.Multiply)
    --self.shadow:set_color(Color.new(0, 0, 0, 255))

    self.body = self:create_node()
    self.body:set_texture(self:get_texture())
    self.body:set_layer(-1)
    self.body:enable_parent_shader(true)
    self.body_anim = Engine.Animation.new(GREGAR_ANIMPATH)
    self.body_anim:copy_from(self:get_animation())
    self.body_anim:set_state("BODY_IDLE")
    self.body_anim:refresh(self.body)
    self.body_anim:set_playback(Playback.Loop)

    --self.body:set_color_mode(ColorMode.Multiply)
    --self.body:set_color(Color.new(0, 0, 0, 255))

    self.f_legs = self:create_node()
    self.f_legs:set_texture(self:get_texture())
    self.f_legs:set_layer(-1)
    self.f_legs:enable_parent_shader(true)
    self.f_legs_anim = Engine.Animation.new(GREGAR_ANIMPATH)
    self.f_legs_anim:copy_from(self:get_animation())
    self.f_legs_anim:set_state("F_LEGS_IDLE")
    self.f_legs_anim:refresh(self.f_legs)
    self.f_legs_anim:set_playback(Playback.Loop)

    --self.f_legs:set_color_mode(ColorMode.Multiply)
    --self.f_legs:set_color(Color.new(0, 0, 0, 255))

    self.head = self:create_node()
    self.head:set_texture(self:get_texture())
    self.head:set_layer(-1)
    self.head:enable_parent_shader(true)
    self.head_anim = Engine.Animation.new(GREGAR_ANIMPATH)
    self.head_anim:copy_from(self:get_animation())
    self.head_anim:set_state("HEAD_IDLE")
    self.head_anim:refresh(self.head)
    self.head_anim:set_playback(Playback.Loop)

    --self.head:set_color_mode(ColorMode.Multiply)
    --self.head:set_color(Color.new(0, 0, 0, 255))

    self.ring = self:create_node()
    self.ring:set_texture(self:get_texture())
    self.ring:set_layer(-1)
    self.ring:enable_parent_shader(true)
    self.ring_anim = Engine.Animation.new(GREGAR_ANIMPATH)
    self.ring_anim:copy_from(self:get_animation())
    self.ring_anim:set_state("LIGHTNINGBREATH_RING0")
    self.ring_anim:refresh(self.ring)
    self.ring_anim:set_playback(Playback.Loop)

    --self.ring:set_color_mode(ColorMode.Multiply)
    --self.ring:set_color(Color.new(0, 0, 0, 255))

    local ref = self
    --This is how we animate nodes.
    self.animate_component = Battle.Component.new(self, Lifetimes.Battlestep)
    self.animate_component.update_func = function(self, dt)
        ref.shadow_anim:update(dt, ref.shadow)
        ref.body_anim:update(dt, ref.body)
        ref.f_legs_anim:update(dt, ref.f_legs)
        ref.head_anim:update(dt, ref.head)
        ref.ring_anim:update(dt, ref.ring)
    end
    self:register_component(self.animate_component)

    self.shake_component = Battle.Component.new(self, Lifetimes.Battlestep)
    self.shake_component.timer = 0
    self.shake_component.update_func = function(self, dt)
        if self.timer > 0 then
            self.timer = self.timer - 1
            ref:shake_camera(20, 0.05)
        end
    end
    self:register_component(self.shake_component)
    self.shake_component2 = Battle.Component.new(self, Lifetimes.Battlestep)
    self.shake_component2.timer = 0
    self.shake_component2.update_func = function(self, dt)
        if self.timer > 0 then
            self.timer = self.timer - 1
            ref:shake_camera(20, 0.05)
        end
    end
    self:register_component(self.shake_component2)

    self.on_countered = function(self)
        debug_print("Countered")
        --self:toggle_counter(false)
        self.hit_func(self)
    end

    local status_defense = Battle.DefenseRule.new(10, DefenseOrder.Always)
    status_defense.filter_statuses_func = function(hit_props)
        debug_print("filter_statuses_func")
        hit_props.flags = hit_props.flags & (~Hit.Blind) & (~Hit.Confuse) & (~Hit.Root) & (~Hit.Freeze) & (~Hit.Bubble) & (~Hit.Drag)
        return hit_props
    end
    self:add_defense_rule(status_defense)

    self.hit_func = function()
        debug_print("Hit func runs")
        self.flinching = false
        self.collision_available = true
        self.moving_to_enemy_tile = false
        self:share_tile(false)
        flinch(self)
    end

    self.spawn_tile = nil
    self.prev_tile = nil
    self.next_tile = nil
    self.slide_tile = nil

    local field = nil
    self.on_spawn_func = function()
        field = self:get_field()
        self.spawn_tile = self:get_tile()
    end
    self.battle_start_func = function()
        self.prev_tile = self:get_tile()
    end
    self.delete_func = function(self)
        self.update_func = function(self)
            self.b_legs_anim:set_state("B_LEGS_STUN")
            self.b_legs_anim:refresh(self:sprite())
            self.shadow_anim:set_state("SHADOW_STUN")
            self.shadow_anim:refresh(self.shadow)
            self.body_anim:set_state("BODY_STUN")
            self.body_anim:refresh(self.body)
            self.f_legs_anim:set_state("F_LEGS_STUN")
            self.f_legs_anim:refresh(self.f_legs)
            self.head_anim:set_state("HEAD_STUN")
            self.head_anim:refresh(self.head)
            self.ring_anim:set_state("LIGHTNINGBREATH_RING0")
            self.ring_anim:refresh(self.ring)
            self:set_offset(0,0)
            self:set_elevation(0)
            self.shadow:set_offset(0,0)
            --self.shadow:set_elevation(0)
            self.body:set_offset(0,0)
            --self.body:set_elevation(0)
            self.f_legs:set_offset(0,0)
            --self.f_legs:set_elevation(0)
            self.head:set_offset(0,0)
            --self.head:set_elevation(0)
        end
    end

    self.lightning1 = nil
    self.lightning2 = nil
    self.sliding = false
    self.change_pattern = true
    function flinch(self)
        --print("Flinch played")
        --teleport_back(self)
        --[[
        if self:get_current_tile() == self.next_tile then
            local orig_tile = self.next_tile
            self.next_tile:remove_entity_by_id(self:get_id())
            self.next_tile = orig_tile
            self.next_tile:add_entity(self)
            self.next_tile = nil
        elseif self:get_current_tile() == self.prev_tile then
            local orig_tile = self.prev_tile
            self.prev_tile:remove_entity_by_id(self:get_id())
            self.prev_tile = orig_tile
            self.prev_tile:add_entity(self)
            self.prev_tile = nil
        end
        if self.original_tile then
            self:teleport(self.original_tile, ActionOrder.Voluntary)
            self:get_current_tile():remove_entity_by_id(self:get_id())
            self.original_tile:add_entity(self)
            self.original_tile = nil
        end]]
        self.shake_component2.timer = 0
        if self.pattern[self.pattern_index] == "BEAST OUT IMPACT" then
            self:teleport(field:tile_at(self.spawn_tile:x(),self:get_tile():y()), ActionOrder.Immediate)
            self.sliding = false
        else
            if self.sliding then
                if self:get_tile() ~= self.slide_tile then
                    self:teleport(self.slide_tile, ActionOrder.Immediate)
                end
                self.slide_tile = nil
                self.sliding = false
            end
        end
        if self.lightning1 ~= nil and not self.lightning1:is_deleted() then
            self.lightning1:erase()
        end
        if self.lightning2 ~= nil and not self.lightning2:is_deleted() then
            self.lightning2:erase()
        end
        --[[
        self.b_legs_anim:set_state("B_LEGS_STUN")
        self.b_legs_anim:refresh(self:sprite())
        self.shadow_anim:set_state("SHADOW_STUN")
        self.shadow_anim:refresh(self.shadow)
        self.body_anim:set_state("BODY_STUN")
        self.body_anim:refresh(self.body)
        self.f_legs_anim:set_state("F_LEGS_STUN")
        self.f_legs_anim:refresh(self.f_legs)
        self.head_anim:set_state("HEAD_STUN")
        self.head_anim:refresh(self.head)
        self.ring_anim:set_state("LIGHTNINGBREATH_RING0")
        self.ring_anim:refresh(self.ring)
        self:set_offset(0,0)
        self.shadow:set_offset(0,0)
        self.body:set_offset(0,0)
        self.f_legs:set_offset(0,0)
        self.head:set_offset(0,0)
        self.anim_once = true
        self.anim_once_2 = false
        self.moving_to_edge = false
        self.moving_to_enemy_tile = false
        self.pattern_index = self.pattern_index + 1
        if self.pattern_index > #self.pattern then
            self.pattern_index = 1
        end
        self.change_pattern = true
        ]]
        --print("I am flinching")
        --if not self.flinching then
        self.b_legs_anim:set_state("B_LEGS_STUN")
        self.b_legs_anim:refresh(self:sprite())
        self.shadow_anim:set_state("SHADOW_STUN")
        self.shadow_anim:refresh(self.shadow)
        self.body_anim:set_state("BODY_STUN")
        self.body_anim:refresh(self.body)
        self.f_legs_anim:set_state("F_LEGS_STUN")
        self.f_legs_anim:refresh(self.f_legs)
        self.head_anim:set_state("HEAD_STUN")
        self.head_anim:refresh(self.head)
        self.ring_anim:set_state("LIGHTNINGBREATH_RING0")
        self.ring_anim:refresh(self.ring)
        self:set_offset(0,0)
        self:set_elevation(0)
        self.shadow:set_offset(0,0)
        --self.shadow:set_elevation(0)
        self.body:set_offset(0,0)
        --self.body:set_elevation(0)
        self.f_legs:set_offset(0,0)
        --self.f_legs:set_elevation(0)
        self.head:set_offset(0,0)
        --self.head:set_elevation(0)
        --self.b_legs_anim:on_complete(function()
            --If we didn't just attack, we want to make sure the idle speed is correct. This is also set in the actual idle, but just for extra measure.
            --Shouldn't be necessary
            --[[
            if activity ~= "STONE FALL" then 
                self.anim_once = true
                self.anim_once_2 = false
                self.moving_to_edge = false
                self.moving_to_enemy_tile = false
                self.pattern_index = self.pattern_index + 1
                if self.pattern[self.pattern_index] == "BREATH" or self.pattern[self.pattern_index] == "GATLING TAIL" or self.pattern[self.pattern_index] == "BEAST OUT IMPACT" or self.pattern[self.pattern_index] == "CHOOSE ATTACK" then
                    self.pattern_index = self.pattern_index + 1
                end
                if self.pattern_index > #self.pattern then
                    self.pattern_index = 1
                end
                self.change_pattern = true
            end]]
            --print("I am done flinching")
            --print("Anim done")
            --self.flinching = false
        --end)
        --end
        self.flinching = true
    end

    self:register_status_callback(Hit.Stun, self.hit_func)
    --self:register_status_callback(Hit.Flinch, self.hit_func)
    --self:register_status_callback(Hit.Drag, self.hit_func)

    self.flinching = false
    self.collision_available = true
    self.moving_to_edge = false
    self.moving_to_enemy_tile = false
    self.can_move_to_func = function(tile)
        --if self:is_rooted() then return false end
        if not self.moving_to_edge and tile:is_edge() then
            return false
        end
        --[[
        if(tile:is_reserved({self:get_id()})) then
            return false
        end
        ]]
        if not self.moving_to_enemy_tile and (tile:get_team() ~= self:get_team()) then
            return false
        end
        return true
        --return not check_characters_health(tile, self)
    end

    self.y_offset_max = -600
    self.y_offset = self.y_offset_max
    self.cooldown = 1
    self.elevation_max = 130
    self.elevation = 0
    self.reached_tile = false
    self.move_state = 0
    self.front_tile = nil
    self.back_tile = nil
    self.collision_attack = nil
    self.collision_spawned = false
    self.stone1 = nil
    self.stone2 = nil

    self.pattern = {
        "STONE FALL", "STONE FALL", "BREATH",
        "STONE FALL", "STONE FALL", "BREATH",
        "STONE FALL", "STONE FALL", "BREATH",
        "STONE FALL", "STONE FALL", "GATLING TAIL",
        "STONE FALL", "STONE FALL", "BREATH",
        "STONE FALL", "STONE FALL", "BEAST OUT IMPACT",
        "STONE FALL", "STONE FALL", "BREATH",
        "STONE FALL", "STONE FALL", "BREATH",
        "STONE FALL", "STONE FALL", "GATLING TAIL",
        "STONE FALL", "STONE FALL", "BREATH",
        "STONE FALL", "STONE FALL", "BREATH",
        "STONE FALL", "STONE FALL", "CHOOSE ATTACK", --"BEAST PRESSURE",
        "STONE FALL", "STONE FALL", "BREATH",
        "STONE FALL", "STONE FALL", "GATLING TAIL",
        "STONE FALL", "STONE FALL", "BREATH",
        "STONE FALL", "STONE FALL", "BREATH",
        "STONE FALL", "STONE FALL", "BREATH",
        "STONE FALL", "STONE FALL", "BEAST OUT IMPACT",
        "STONE FALL", "STONE FALL", "GATLING TAIL",
        "STONE FALL", "STONE FALL", "BREATH",
        "STONE FALL", "STONE FALL", "BREATH",
        "STONE FALL", "STONE FALL", "BREATH",
        "STONE FALL", "STONE FALL", "GATLING TAIL",
        "STONE FALL", "STONE FALL", "CHOOSE ATTACK"
    }
    self.pattern_index = 1
    self.breath_type = 0
    self.tile_list = nil
    self.tile_list_r = nil
    self.tile_list_f = {}
    self.enemy_list = nil
    local activity = self.pattern[self.pattern_index]
    self.update_func = function(self)
        --self.frames = self.frames + 1
        --TILE RESERVER
        local x_start = 1
        local x_mid = 1
        local x_end = x_start+2
        if self:get_facing() == Direction.Left then
            x_start = field:width()
            x_mid = -1
            x_end = x_start-2
        end
        for x=x_start, x_end, x_mid do
            for y=1, field:height() do
                local tile = field:tile_at(x,y)
                if tile:get_team() == self:get_team() then
                    field:tile_at(x,y):reserve_entity_by_id(self:get_id())
                end
            end
        end
        ----
        --IF STUNNED
        if self.b_legs_anim:get_state() == "B_LEGS_STUN" then
            self.b_legs_anim:on_complete(function()
                self.flinching = false
                self.moving_to_edge = false
                self.moving_to_enemy_tile = false
                self.pattern_index = self.pattern_index + 1
                if self.pattern[self.pattern_index] == "BREATH" or self.pattern[self.pattern_index] == "GATLING TAIL" or self.pattern[self.pattern_index] == "BEAST OUT IMPACT" or self.pattern[self.pattern_index] == "CHOOSE ATTACK" then
                    self.pattern_index = self.pattern_index + 1
                end
                if self.pattern_index > #self.pattern then
                    self.pattern_index = 1
                end
                self.change_pattern = true
            end)
        end
        ----
        --CHANGES PATTERN
        if self.change_pattern then
            self.change_pattern = false
            self.frames = 0 -- Resets the frame counter.
            self.anim_once = true
            self.anim_once_2 = false
            self.move_state = 0
            self.moving_to_edge = false
            self.moving_to_enemy_tile = false
            activity = self.pattern[self.pattern_index]
        end
        if activity == "STONE FALL" then -- falling rocks
            if self.anim_once then -- starts moving
                self.anim_once = false
                self.b_legs_anim:set_state("B_LEGS_WARP")
                self.b_legs_anim:refresh(self:sprite())
                self.shadow_anim:set_state("SHADOW_WARP")
                self.shadow_anim:refresh(self.shadow)
                self.body_anim:set_state("BODY_WARP")
                self.body_anim:refresh(self.body)
                self.f_legs_anim:set_state("F_LEGS_WARP")
                self.f_legs_anim:refresh(self.f_legs)
                self.head_anim:set_state("HEAD_WARP")
                self.head_anim:refresh(self.head)
            end
            if self.b_legs_anim:get_state() == "B_LEGS_WARP" then
                if self.frames == 5 then -- disappears
                    self:toggle_hitbox(false)
                    self.y_offset = self.y_offset_max
                    self:set_offset(0,self.y_offset)
                    self.shadow:set_offset(0,-self.y_offset)
                    self.body:set_offset(0,0)
                    self.f_legs:set_offset(0,0)
                    self.head:set_offset(0,0)
                end
                if self.frames == self.movement_frame then -- moves to random tile (30/20)
                    local tile_filter = function(tile)
                        return not tile:is_edge() and tile:get_team() == self:get_team() and tile ~= self.prev_tile and tile ~= self:get_tile() and (tile:x() < 3 or tile:x() > 4)
                    end
                    self.tile_list = self:get_field():find_tiles(tile_filter)
                    self.next_tile = self.tile_list[math.random(1, #self.tile_list)]
                    self.prev_tile = self:get_tile()
                    self:teleport(self.next_tile, ActionOrder.Immediate)
                    self.b_legs_anim:set_state("B_LEGS_STAND")
                    self.b_legs_anim:refresh(self:sprite())
                    self.shadow_anim:set_state("SHADOW_STAND")
                    self.shadow_anim:refresh(self.shadow)
                    self.body_anim:set_state("BODY_STAND")
                    self.body_anim:refresh(self.body)
                    self.f_legs_anim:set_state("F_LEGS_STAND")
                    self.f_legs_anim:refresh(self.f_legs)
                    self.head_anim:set_state("HEAD_STAND")
                    self.head_anim:refresh(self.head)
                    self.frames = 0 -- Resets the frame counter.
                end
            end
            if self.b_legs_anim:get_state() == "B_LEGS_STAND" then
                if self.y_offset < 0 then
                    self.y_offset = self.y_offset + 40
                    self:set_offset(0,self.y_offset)
                    self.shadow:set_offset(0,-self.y_offset/2)
                    self.body:set_offset(0,0)
                    self.f_legs:set_offset(0,0)
                    self.head:set_offset(0,0)
                else
                    Engine.play_audio(GREGAR_STOMP_AUDIO, AudioPriority.Low)
                    self.shake_component.timer = 30
                    --self:shake_camera(10, 0.5)
                    self:toggle_hitbox(true)
                    self.b_legs_anim:set_state("B_LEGS_LAND1")
                    self.b_legs_anim:refresh(self:sprite())
                    self.shadow_anim:set_state("SHADOW_LAND1")
                    self.shadow_anim:refresh(self.shadow)
                    self.body_anim:set_state("BODY_LAND1")
                    self.body_anim:refresh(self.body)
                    self.f_legs_anim:set_state("F_LEGS_LAND1")
                    self.f_legs_anim:refresh(self.f_legs)
                    self.head_anim:set_state("HEAD_LAND1")
                    self.head_anim:refresh(self.head)
                    self.frames = 0 -- Resets the frame counter.
                end
            end
            if self.b_legs_anim:get_state() == "B_LEGS_LAND1" then
                if self.frames == 4 then
                    rock_spawner(self)
                end
                if self.frames >= self.fallingrock_frame then -- 27/15
                    self.pattern_index = self.pattern_index + 1
                    if self.pattern_index > #self.pattern then
                        self.pattern_index = 1
                    end
                    self.change_pattern = true
                end
            end
        elseif activity == "BREATH" then
            if self.anim_once then -- starts moving
                self.anim_once = false
                self.b_legs_anim:set_state("B_LEGS_WARP")
                self.b_legs_anim:refresh(self:sprite())
                self.shadow_anim:set_state("SHADOW_WARP")
                self.shadow_anim:refresh(self.shadow)
                self.body_anim:set_state("BODY_WARP")
                self.body_anim:refresh(self.body)
                self.f_legs_anim:set_state("F_LEGS_WARP")
                self.f_legs_anim:refresh(self.f_legs)
                self.head_anim:set_state("HEAD_WARP")
                self.head_anim:refresh(self.head)
            end
            if self.b_legs_anim:get_state() == "B_LEGS_WARP" then
                if self.frames == 5 then -- disappears
                    self:toggle_hitbox(false)
                    self.y_offset = self.y_offset_max
                    self:set_offset(0,self.y_offset)
                    self.shadow:set_offset(0,-self.y_offset)
                    self.body:set_offset(0,0)
                    self.f_legs:set_offset(0,0)
                    self.head:set_offset(0,0)
                end
                if self.frames == self.movement_frame then -- moves to random tile (30/20)
                    self.tile_list_f = {}
                    self.breath_type = math.random(1,2)
                    local enemy_filter = function(character)
                        return character:get_team() ~= self:get_team() and character:get_health() > 0
                    end
                    local enemy_list = self:get_field():find_nearest_characters(self, enemy_filter)
                    if enemy_list[1] then
                        self.enemy_list = enemy_list
                    end
                    local target_x = 2
                    if self:get_facing() == Direction.Left then
                        target_x = 5
                    end
                    local target_y = nil
                    if enemy_list[1] and self.breath_type == 2 then
                        target_y = enemy_list[1]:get_tile():y()
                    elseif self.breath_type == 1 then
                        target_y = 2
                    else
                        target_y = math.random(1,3)
                    end
                    self.next_tile = field:tile_at(target_x,target_y)
                    if self.breath_type == 1 then
                        local tile_filter = function(tile)
                            if not tile:is_edge() then
                                if tile == self.next_tile:get_tile(self:get_facing(),2)
                                or (self:get_facing() == Direction.Right and tile:x() > self.next_tile:get_tile(self:get_facing(),2):x()) 
                                or (self:get_facing() == Direction.Left  and tile:x() < self.next_tile:get_tile(self:get_facing(),2):x()) then
                                    return true
                                end
                            end
                        end
                        self.tile_list_f = self:get_field():find_tiles(tile_filter)
                    end
                    self.prev_tile = self:get_tile()
                    self:teleport(self.next_tile, ActionOrder.Immediate)
                    self.b_legs_anim:set_state("B_LEGS_STAND")
                    self.b_legs_anim:refresh(self:sprite())
                    self.shadow_anim:set_state("SHADOW_STAND")
                    self.shadow_anim:refresh(self.shadow)
                    self.body_anim:set_state("BODY_STAND")
                    self.body_anim:refresh(self.body)
                    self.f_legs_anim:set_state("F_LEGS_STAND")
                    self.f_legs_anim:refresh(self.f_legs)
                    self.head_anim:set_state("HEAD_STAND")
                    self.head_anim:refresh(self.head)
                    self.frames = 0 -- Resets the frame counter.
                end
            end
            if self.b_legs_anim:get_state() == "B_LEGS_STAND" then
                if self.y_offset < 0 then
                    self.y_offset = self.y_offset + 40
                    self:set_offset(0,self.y_offset)
                    self.shadow:set_offset(0,-self.y_offset/2)
                    self.body:set_offset(0,0)
                    self.f_legs:set_offset(0,0)
                    self.head:set_offset(0,0)
                else
                    Engine.play_audio(GREGAR_STOMP_AUDIO, AudioPriority.Low)
                    self.shake_component.timer = 30
                    --self:shake_camera(10, 0.5)
                    self:toggle_hitbox(true)
                    self.b_legs_anim:set_state("B_LEGS_LAND2")
                    self.b_legs_anim:refresh(self:sprite())
                    self.shadow_anim:set_state("SHADOW_LAND2")
                    self.shadow_anim:refresh(self.shadow)
                    self.body_anim:set_state("BODY_LAND2")
                    self.body_anim:refresh(self.body)
                    self.f_legs_anim:set_state("F_LEGS_LAND2")
                    self.f_legs_anim:refresh(self.f_legs)
                    self.head_anim:set_state("HEAD_LAND2")
                    self.head_anim:refresh(self.head)
                    self.frames = 0 -- Resets the frame counter.
                end
            end
            if self.b_legs_anim:get_state() == "B_LEGS_LAND2" then
                if self.frames >= 12 then
                    if self.breath_type == 1 then
                        self.b_legs_anim:set_state("B_LEGS_BURNINGBREATH_CHARGE")
                        self.b_legs_anim:refresh(self:sprite())
                        self.shadow_anim:set_state("SHADOW_BURNINGBREATH_CHARGE")
                        self.shadow_anim:refresh(self.shadow)
                        self.body_anim:set_state("BODY_BURNINGBREATH_CHARGE")
                        self.body_anim:refresh(self.body)
                        self.f_legs_anim:set_state("F_LEGS_BURNINGBREATH_CHARGE")
                        self.f_legs_anim:refresh(self.f_legs)
                        self.head_anim:set_state("HEAD_BURNINGBREATH_CHARGE")
                        self.head_anim:refresh(self.head)
                    else
                        self.b_legs_anim:set_state("B_LEGS_LIGHTNINGBREATH_CHARGE")
                        self.b_legs_anim:set_playback(Playback.Loop)
                        self.b_legs_anim:refresh(self:sprite())
                        self.shadow_anim:set_state("SHADOW_LIGHTNINGBREATH_CHARGE")
                        self.shadow_anim:set_playback(Playback.Loop)
                        self.shadow_anim:refresh(self.shadow)
                        self.body_anim:set_state("BODY_LIGHTNINGBREATH_CHARGE")
                        self.body_anim:set_playback(Playback.Loop)
                        self.body_anim:refresh(self.body)
                        self.f_legs_anim:set_state("F_LEGS_LIGHTNINGBREATH_CHARGE")
                        self.f_legs_anim:set_playback(Playback.Loop)
                        self.f_legs_anim:refresh(self.f_legs)
                        self.head_anim:set_state("HEAD_LIGHTNINGBREATH_CHARGE")
                        self.head_anim:set_playback(Playback.Loop)
                        self.head_anim:refresh(self.head)
                        self.ring_anim:set_state("LIGHTNINGBREATH_RING2")
                        self.ring_anim:set_playback(Playback.Loop)
                        self.ring_anim:refresh(self.ring)
                    end
                    self.frames = 0 -- Resets the frame counter.
                end
            end
            if self.b_legs_anim:get_state() == "B_LEGS_BURNINGBREATH_CHARGE" then
                for i=1, #self.tile_list_f do
                    self.tile_list_f[i]:highlight(Highlight.Flash)
                end
                if self.frames >= self.burningbreath_frame then -- 21/
                    self.b_legs_anim:set_state("B_LEGS_BREATH")
                    self.b_legs_anim:set_playback(Playback.Loop)
                    self.b_legs_anim:refresh(self:sprite())
                    self.shadow_anim:set_state("SHADOW_BREATH")
                    self.shadow_anim:set_playback(Playback.Loop)
                    self.shadow_anim:refresh(self.shadow)
                    self.body_anim:set_state("BODY_BREATH")
                    self.body_anim:set_playback(Playback.Loop)
                    self.body_anim:refresh(self.body)
                    self.f_legs_anim:set_state("F_LEGS_BREATH")
                    self.f_legs_anim:set_playback(Playback.Loop)
                    self.f_legs_anim:refresh(self.f_legs)
                    self.head_anim:set_state("HEAD_BREATH")
                    self.head_anim:set_playback(Playback.Loop)
                    self.head_anim:refresh(self.head)
                    Engine.play_audio(GREGAR_ROAR_AUDIO, AudioPriority.Low)
                    for i=1, #self.tile_list_f do
                        create_burning_hitbox(self, self.tile_list_f[i])
                    end
                    self.frames = 0 -- Resets the frame counter.
                end
            end
            if self.b_legs_anim:get_state() == "B_LEGS_LIGHTNINGBREATH_CHARGE" then
                for i=1, field:width() do
                    local hl_tile = self:get_tile(self:get_facing(),i+1)
                    if hl_tile and not hl_tile:is_edge() then 
                        hl_tile:highlight(Highlight.Flash)
                    else
                        break
                    end
                end
                local s_tile = self:get_tile(self:get_facing(), 2)
                for i=1, field:height() do
                    local hl_tile = field:tile_at(s_tile:x(), i)
                    if hl_tile and not hl_tile:is_edge() and i ~= s_tile:y() then 
                        hl_tile:highlight(Highlight.Flash)
                    end
                end
                for i=1, 16, 15 do
                    if self.frames == i then
                        Engine.play_audio(LIGHTNINGBREATH_CHARGE_AUDIO, AudioPriority.Low)
                    end
                end
                if self.frames >= self.lightningbreath_frame then -- 31/
                    self.b_legs_anim:set_state("B_LEGS_BREATH")
                    self.b_legs_anim:set_playback(Playback.Loop)
                    self.b_legs_anim:refresh(self:sprite())
                    self.shadow_anim:set_state("SHADOW_BREATH")
                    self.shadow_anim:set_playback(Playback.Loop)
                    self.shadow_anim:refresh(self.shadow)
                    self.body_anim:set_state("BODY_BREATH")
                    self.body_anim:set_playback(Playback.Loop)
                    self.body_anim:refresh(self.body)
                    self.f_legs_anim:set_state("F_LEGS_BREATH")
                    self.f_legs_anim:set_playback(Playback.Loop)
                    self.f_legs_anim:refresh(self.f_legs)
                    self.head_anim:set_state("HEAD_BREATH")
                    self.head_anim:set_playback(Playback.Loop)
                    self.head_anim:refresh(self.head)
                    self.ring_anim:set_state("LIGHTNINGBREATH_RING1")
                    self.ring_anim:set_playback(Playback.Loop)
                    self.ring_anim:refresh(self.ring)
                    Engine.play_audio(GREGAR_ROAR_AUDIO, AudioPriority.Low)
                    self.lightning1 = graphic_init("spell", 0, 0, LIGHTNINGBREATH_TEXTURE, LIGHTNINGBREATH_PALETTE, LIGHTNINGBREATH_ANIMPATH, -3, "0", Playback.Loop, self, self:get_facing())
                    self.lightning2 = graphic_init("spell", 0, 0, LIGHTNINGBREATH_TEXTURE, LIGHTNINGBREATH_PALETTE, LIGHTNINGBREATH_ANIMPATH, -3, "1", Playback.Loop, self, self:get_facing())
                    field:spawn(self.lightning1, self:get_tile(self:get_facing(), 4))
                    for i=1, field:width() do
                        local hl_tile = self:get_tile(self:get_facing(), i+1)
                        if hl_tile and not hl_tile:is_edge() then 
                            create_lightning_hitbox(self, hl_tile)
                        else
                            break
                        end
                    end
                    local s_tile = self:get_tile(self:get_facing(), 2)
                    field:spawn(self.lightning2, s_tile)
                    for i=1, field:height() do
                        local hl_tile = field:tile_at(s_tile:x(), i)
                        if hl_tile and not hl_tile:is_edge() and i ~= s_tile:y() then 
                            create_lightning_hitbox(self, hl_tile)
                        end
                    end
                    self.frames = 0 -- Resets the frame counter.
                end
            end
            if self.b_legs_anim:get_state() == "B_LEGS_BREATH" then
                if self:is_counterable() then
                    debug_print("IS counterable")
                else
                    debug_print("NOT counterable")
                end
                for i=6, (6+16)*5, 16 do
                    if self.frames == i then
                        if self.breath_type == 1 then
                            Engine.play_audio(BURNINGBREATH_AUDIO, AudioPriority.Low)
                        else
                            Engine.play_audio(LIGHTNINGBREATH_ATTACK_AUDIO, AudioPriority.Low)
                        end
                    end
                end
                if self.frames == 3+1 then
                    self:toggle_counter(true)
                end
                if self.frames == 30+1 then
                    self:toggle_counter(false)
                end
                if self.frames >= self.breath_frame then -- 121/
                    if self.breath_type == 1 then
                        self.b_legs_anim:set_state("B_LEGS_IDLE")
                        self.b_legs_anim:refresh(self:sprite())
                        self.shadow_anim:set_state("SHADOW_IDLE")
                        self.shadow_anim:refresh(self.shadow)
                        self.body_anim:set_state("BODY_IDLE")
                        self.body_anim:refresh(self.body)
                        self.f_legs_anim:set_state("F_LEGS_IDLE")
                        self.f_legs_anim:refresh(self.f_legs)
                        self.head_anim:set_state("HEAD_IDLE")
                        self.head_anim:refresh(self.head)
                    else
                        self.lightning1:delete()
                        self.lightning2:delete()
                        self.b_legs_anim:set_state("B_LEGS_IDLE")
                        self.b_legs_anim:refresh(self:sprite())
                        self.shadow_anim:set_state("SHADOW_IDLE")
                        self.shadow_anim:refresh(self.shadow)
                        self.body_anim:set_state("BODY_IDLE")
                        self.body_anim:refresh(self.body)
                        self.f_legs_anim:set_state("F_LEGS_IDLE")
                        self.f_legs_anim:refresh(self.f_legs)
                        self.head_anim:set_state("HEAD_IDLE")
                        self.head_anim:refresh(self.head)
                        self.ring_anim:set_state("LIGHTNINGBREATH_RING0")
                        self.ring_anim:refresh(self.ring)
                    end
                    self.frames = 0 -- Resets the frame counter.
                end
            end
            if self.b_legs_anim:get_state() == "B_LEGS_IDLE" then
                if self.frames >= self.breath_frame2 then
                    self.pattern_index = self.pattern_index + 1
                    if self.pattern_index > #self.pattern then
                        self.pattern_index = 1
                    end
                    self.change_pattern = true
                end
            end
        elseif activity == "GATLING TAIL" then
            if self.anim_once then
                self.anim_once = false
                self.b_legs_anim:set_state("B_LEGS_GATLINGTAIL_START")
                self.b_legs_anim:refresh(self:sprite())
                self.shadow_anim:set_state("SHADOW_GATLINGTAIL_START")
                self.shadow_anim:refresh(self.shadow)
                self.body_anim:set_state("BODY_GATLINGTAIL_START")
                self.body_anim:refresh(self.body)
                self.f_legs_anim:set_state("F_LEGS_GATLINGTAIL_START")
                self.f_legs_anim:refresh(self.f_legs)
                self.head_anim:set_state("HEAD_GATLINGTAIL_START")
                self.head_anim:refresh(self.head)
                self.gatlingtail_target_tile = nil
                self.frames = 0 -- Resets the frame counter.
            end
            --12 counter frames
            if self.frames == 44 then
                self:toggle_counter(true)
            end
            if self.frames == 56 then
                self:toggle_counter(false)
            end
            --x9/x12
            --highlight
            for i=33, 33+(14*(self.gatilingtail_shots-1)), 14 do
                if self.frames == i then
                    if i==33 then
                        local enemy_filter = function(character)
                            return character:get_team() ~= self:get_team() and character:get_health() > 0
                        end
                        local enemy_list = self:get_field():find_nearest_characters(self, enemy_filter)
                        if enemy_list[1] then
                            self.enemy_list = enemy_list
                        end
                        self.gatlingtail_target_tile = field:tile_at(self.enemy_list[1]:get_tile():x(), 1)
                        self.gatlingtail_dir_tile = Direction.Down
                    end
                    create_highlight(self, self.gatlingtail_target_tile, 20)
                end
            end
            --shoot
            for i=45, 45+(14*(self.gatilingtail_shots-1)), 14 do
                if self.frames == i then
                    self.b_legs_anim:set_state("B_LEGS_GATLINGTAIL_SHOOT")
                    self.b_legs_anim:refresh(self:sprite())
                    self.shadow_anim:set_state("SHADOW_GATLINGTAIL_SHOOT")
                    self.shadow_anim:refresh(self.shadow)
                    self.body_anim:set_state("BODY_GATLINGTAIL_SHOOT")
                    self.body_anim:refresh(self.body)
                    self.f_legs_anim:set_state("F_LEGS_GATLINGTAIL_SHOOT")
                    self.f_legs_anim:refresh(self.f_legs)
                    self.head_anim:set_state("HEAD_GATLINGTAIL_SHOOT")
                    self.head_anim:refresh(self.head)
                    create_gatling_hitbox(self, self.gatlingtail_target_tile)
                    local tracking = false
                    if self.gatlingtail_can_track then
                        local enemy_filter = function(c)
                            return c:get_team() ~= self:get_team() and c:get_health() > 0
                        end
                        local enemy_list = self:get_field():find_nearest_characters(self, enemy_filter)
                        if enemy_list[1] then
                            if     self.gatlingtail_target_tile:x() > enemy_list[1]:get_tile():x() then
                                tracking = Direction.Left
                            elseif self.gatlingtail_target_tile:x() < enemy_list[1]:get_tile():x() then
                                tracking = Direction.Right
                            end
                        end
                    end
                    if not self.gatlingtail_target_tile:get_tile(self.gatlingtail_dir_tile, 1):is_edge() then
                        self.gatlingtail_target_tile = self.gatlingtail_target_tile:get_tile(self.gatlingtail_dir_tile, 1)
                    else
                        self.gatlingtail_dir_tile = Direction.reverse(self.gatlingtail_dir_tile)
                        if tracking then
                            self.gatlingtail_target_tile = self.gatlingtail_target_tile:get_tile(tracking, 1)
                        end
                    end
                end
            end
            if self.frames == 46+(14*(self.gatilingtail_shots-1)) then
                self.b_legs_anim:set_state("B_LEGS_GATLINGTAIL_END")
                self.b_legs_anim:refresh(self:sprite())
                self.shadow_anim:set_state("SHADOW_GATLINGTAIL_END")
                self.shadow_anim:refresh(self.shadow)
                self.body_anim:set_state("BODY_GATLINGTAIL_END")
                self.body_anim:refresh(self.body)
                self.f_legs_anim:set_state("F_LEGS_GATLINGTAIL_END")
                self.f_legs_anim:refresh(self.f_legs)
                self.head_anim:set_state("HEAD_GATLINGTAIL_END")
                self.head_anim:refresh(self.head)
            end
            if self.frames == 46+(14*(self.gatilingtail_shots-1))+self.gatilingtail_end_delay then --60/40
                self.b_legs_anim:set_state("B_LEGS_IDLE")
                self.b_legs_anim:refresh(self:sprite())
                self.shadow_anim:set_state("SHADOW_IDLE")
                self.shadow_anim:refresh(self.shadow)
                self.body_anim:set_state("BODY_IDLE")
                self.body_anim:refresh(self.body)
                self.f_legs_anim:set_state("F_LEGS_IDLE")
                self.f_legs_anim:refresh(self.f_legs)
                self.head_anim:set_state("HEAD_IDLE")
                self.head_anim:refresh(self.head)
            end
            if self.frames == 47+(14*(self.gatilingtail_shots-1))+self.gatilingtail_end_delay then
                self.pattern_index = self.pattern_index + 1
                if self.pattern_index > #self.pattern then
                    self.pattern_index = 1
                end
                self.change_pattern = true
            end
        elseif activity == "BEAST OUT IMPACT" then
            if self.anim_once then
                self.anim_once = false
                self.moving_to_edge = true
                self.moving_to_enemy_tile = true
                self.b_legs_anim:set_state("B_LEGS_WARP")
                self.b_legs_anim:refresh(self:sprite())
                self.shadow_anim:set_state("SHADOW_WARP")
                self.shadow_anim:refresh(self.shadow)
                self.body_anim:set_state("BODY_WARP")
                self.body_anim:refresh(self.body)
                self.f_legs_anim:set_state("F_LEGS_WARP")
                self.f_legs_anim:refresh(self.f_legs)
                self.head_anim:set_state("HEAD_WARP")
                self.head_anim:refresh(self.head)
                self.frames = 0 -- Resets the frame counter.
            end
            if self.b_legs_anim:get_state() == "B_LEGS_WARP" then
                if self.frames == 5 then -- disappears
                    self:toggle_hitbox(false)
                    self.y_offset = self.y_offset_max
                    self:set_offset(0,self.y_offset)
                    --self.shadow:set_offset(0,-self.y_offset)
                    self.shadow:set_offset(0,0)
                    self.body:set_offset(0,0)
                    self.f_legs:set_offset(0,0)
                    self.head:set_offset(0,0)
                end
                if self.frames == 66 then -- highlights
                    for i=2, 5, 1 do
                        for j=1, 3, 1 do
                            local hl_tile = field:tile_at(i,j)
                            if (self:get_facing() == Direction.Right and i~=2) or (self:get_facing() == Direction.Left and i~=5) then
                                create_highlight(self, hl_tile, 16)
                            end
                        end
                    end
                end
                if self.frames == 66+self.beastoutimpact_claw_delay then -- claw 1 (16/10)
                    local target_tile = field:tile_at(3,3)
                    if self:get_facing() == Direction.Left then
                        target_tile = field:tile_at(4,3)
                    end
                    create_claw(self, target_tile, target_tile:get_tile(Direction.join(self:get_facing(), Direction.Up), 1), "CLAW_U", Direction.Up)
                    --create_slash(self, target_tile:get_tile(Direction.join(self:get_facing(), Direction.Up), 1), "2", Direction.Up)
                end
                if self.frames == 66+self.beastoutimpact_claw_delay+10 then -- claw 2
                    local target_tile = field:tile_at(4,0)
                    if self:get_facing() == Direction.Left then
                        target_tile = field:tile_at(3,0)
                    end
                    create_claw(self, target_tile, target_tile:get_tile(Direction.join(self:get_facing(), Direction.Down), 1):get_tile(Direction.Down, 1), "CLAW_D", Direction.Down)
                    --create_slash(self, target_tile:get_tile(Direction.join(self:get_facing(), Direction.Down), 1):get_tile(Direction.Down, 1), "0", Direction.Down)
                end
                if self.frames == 66+self.beastoutimpact_claw_delay+20 then -- fang
                    local enemy_filter = function(character)
                        return character:get_team() ~= self:get_team() and character:get_health() > 0
                    end
                    local enemy_list = self:get_field():find_nearest_characters(self, enemy_filter)
                    if enemy_list[1] then
                        self.enemy_list = enemy_list
                    end
                    self.front_tile = self.enemy_list[1]:get_tile()
                    local start_x = 0
                    if self:get_facing() == Direction.Left then start_x = self:get_field():width() end
                    self:teleport(self:get_field():tile_at(start_x,self.front_tile:y()), ActionOrder.Immediate)
                    --debug_print("TILE1: ("..self:get_tile():x()..";"..self:get_tile():y()..")")
                    self.b_legs_anim:set_state("B_LEGS_BEASTOUTIMPACT")
                    self.b_legs_anim:refresh(self:sprite())
                    self.shadow_anim:set_state("SHADOW_BEASTOUTIMPACT")
                    self.shadow_anim:refresh(self.shadow)
                    self.body_anim:set_state("BODY_BEASTOUTIMPACT")
                    self.body_anim:refresh(self.body)
                    self.f_legs_anim:set_state("F_LEGS_BEASTOUTIMPACT")
                    self.f_legs_anim:refresh(self.f_legs)
                    self.head_anim:set_state("HEAD_BEASTOUTIMPACT")
                    self.head_anim:refresh(self.head)
                    self.anim_once_2 = true
                    self.frames = 0 -- Resets the frame counter.
                end
            end
            if self.b_legs_anim:get_state() == "B_LEGS_BEASTOUTIMPACT" then
                if self.anim_once_2 then
                    self.anim_once_2 = false
                    Engine.play_audio(BEASTOUTIMPACT_FANG_AUDIO, AudioPriority.Low)
                    self:set_offset(0,0)
                    self.elevation = self.elevation_max
                    self:set_elevation(self.elevation)
                    self.shadow:set_offset(0,self.elevation/2)
                    self.shadow:set_offset(0,0)
                    self.body:set_offset(0,0)
                    self.f_legs:set_offset(0,0)
                    self.head:set_offset(0,0)
                    self.move_state = 1
                    self:toggle_hitbox(true)
                    self.collision_attack = create_collision_attack2(self)
                    self.collision_spawned = false
                    self.slide_tile = self:get_tile()
                end
                if self:get_tile() == self.front_tile then
                    if not self.collision_spawned then
                        self.collision_spawned = true
                        field:spawn(self.collision_attack, self:get_tile())
                    end
                else
                    if self.collision_spawned then
                        self.collision_spawned = false
                        self.collision_attack:erase()
                    end
                end
                if self.move_state == 1 then
                    --debug_print("TILE: ("..self:get_tile():x()..";"..self:get_tile():y()..")")
                    if not self.reached_tile then
                        if self:get_tile() ~= self.front_tile then
                            local nxt_tile = self:get_tile(self:get_facing(), 1)
                            self:slide(nxt_tile, frames(self.beastoutimpact_speed_frames), frames(0), ActionOrder.Voluntary, function()
                                self.sliding = true
                            end)
                        else
                            self.moving_to_edge = true
                            self.moving_to_enemy_tile = true
                            self.shake_component.timer = 20
                            --self:shake_camera(20, 0.5)
                            self.reached_tile = true
                            self.move_state = 2
                            self.frames = 0 -- Resets the frame counter.
                        end
                        self:set_elevation(self.elevation)
                        self.shadow:set_offset(0,self.elevation/2)
                        self.body:set_offset(0,0)
                        self.f_legs:set_offset(0,0)
                        self.head:set_offset(0,0)
                        if self.front_tile:x() == 3 or self.front_tile:x() == 4 then
                            self.elevation = self.elevation - 8
                        elseif self.front_tile:x() < 3 or self.front_tile:x() > 4 then
                            self.elevation = self.elevation - 4
                        end
                        self.front_tile:highlight(Highlight.Flash)
                    end
                elseif self.move_state == 2 then
                    if self.frames < 24 then
                    else
                        if self:get_facing() == Direction.Right then
                            self.back_tile = field:tile_at(2,self:get_tile():y())
                        else
                            self.back_tile = field:tile_at(5,self:get_tile():y())
                        end
                        self.move_state = 3
                        self.frames = 0 -- Resets the frame counter.
                    end
                elseif self.move_state == 3 then
                    if self.reached_tile then
                        if self:get_tile() ~= self.back_tile then
                            local nxt_tile = self:get_tile(self:get_facing_away(), 1)
                            self:slide(nxt_tile, frames(self.beastoutimpact_speed_frames), frames(0), ActionOrder.Voluntary, function()
                                self.sliding = true
                            end)
                        else
                            if not self:is_sliding() then
                                self.sliding = false
                                self.elevation = 0
                                self:set_elevation(self.elevation)
                                self.shadow:set_offset(0,0)
                                self.body:set_offset(0,0)
                                self.f_legs:set_offset(0,0)
                                self.head:set_offset(0,0)
                                self.b_legs_anim:set_state("B_LEGS_LAND3")
                                self.b_legs_anim:refresh(self:sprite())
                                self.shadow_anim:set_state("SHADOW_LAND3")
                                self.shadow_anim:refresh(self.shadow)
                                self.body_anim:set_state("BODY_LAND3")
                                self.body_anim:refresh(self.body)
                                self.f_legs_anim:set_state("F_LEGS_LAND3")
                                self.f_legs_anim:refresh(self.f_legs)
                                self.head_anim:set_state("HEAD_LAND3")
                                self.head_anim:refresh(self.head)
                                self.reached_tile = false
                                self.move_state = 4
                                self.frames = 0 -- Resets the frame counter.
                            end
                        end
                        self:set_elevation(self.elevation)
                        self.shadow:set_offset(0,self.elevation/2)
                        self.body:set_offset(0,0)
                        self.f_legs:set_offset(0,0)
                        self.head:set_offset(0,0)
                        if self.front_tile:x() == 3 or self.front_tile:x() == 4 then
                            self.elevation = self.elevation + 8
                        elseif self.front_tile:x() < 3 or self.front_tile:x() > 4 then
                            self.elevation = self.elevation + 4
                        end
                    end
                end
            end
            if self.b_legs_anim:get_state() == "B_LEGS_LAND3" then
                if self.frames == self.beastoutimpact_end_delay then -- 27/15
                    self.pattern_index = self.pattern_index + 1
                    if self.pattern_index > #self.pattern then
                        self.pattern_index = 1
                    end
                    self.change_pattern = true
                end
            end
        elseif activity == "BEAST PRESSURE" then
            if self.anim_once then
                self.anim_once = false
                self.moving_to_edge = true
                self.moving_to_enemy_tile = true
                self.b_legs_anim:set_state("B_LEGS_BEASTPRESSURE_ROAR")
                self.b_legs_anim:set_playback(Playback.Loop)
                self.b_legs_anim:refresh(self:sprite())
                self.shadow_anim:set_state("SHADOW_BEASTPRESSURE_ROAR")
                self.shadow_anim:set_playback(Playback.Loop)
                self.shadow_anim:refresh(self.shadow)
                self.body_anim:set_state("BODY_BEASTPRESSURE_ROAR")
                self.body_anim:set_playback(Playback.Loop)
                self.body_anim:refresh(self.body)
                self.f_legs_anim:set_state("F_LEGS_BEASTPRESSURE_ROAR")
                self.f_legs_anim:set_playback(Playback.Loop)
                self.f_legs_anim:refresh(self.f_legs)
                self.head_anim:set_state("HEAD_BEASTPRESSURE_ROAR")
                self.head_anim:set_playback(Playback.Loop)
                self.head_anim:refresh(self.head)
                Engine.play_audio(GREGAR_ROAR_AUDIO, AudioPriority.Low)
                self.frames = 0 -- Resets the frame counter.
            end
            if self.b_legs_anim:get_state() == "B_LEGS_BEASTPRESSURE_ROAR" then
                for i=12, 48, 18 do
                    if self.frames == i then
                        Engine.play_audio(GREGAR_SHAKE_AUDIO, AudioPriority.Low)
                    end
                end
                if self.frames == 63 then
                    self.b_legs_anim:set_state("B_LEGS_BEASTPRESSURE_READY")
                    self.b_legs_anim:refresh(self:sprite())
                    self.shadow_anim:set_state("SHADOW_BEASTPRESSURE_READY")
                    self.shadow_anim:refresh(self.shadow)
                    self.body_anim:set_state("BODY_BEASTPRESSURE_READY")
                    self.body_anim:refresh(self.body)
                    self.f_legs_anim:set_state("F_LEGS_BEASTPRESSURE_READY")
                    self.f_legs_anim:refresh(self.f_legs)
                    self.head_anim:set_state("HEAD_BEASTPRESSURE_READY")
                    self.head_anim:refresh(self.head)
                    self.frames = 0 -- Resets the frame counter.
                end
            end
            if self.b_legs_anim:get_state() == "B_LEGS_BEASTPRESSURE_READY" then
                if self.frames == 63 then
                    for i=0, field:width() do
                        local hl_tile = self:get_tile(self:get_facing(), i)
                        if hl_tile and not hl_tile:is_edge() then 
                            create_highlight(self, hl_tile, 16)
                        else
                            break
                        end
                    end
                end
                if self.frames == 79 then
                    self.b_legs_anim:set_state("B_LEGS_BEASTPRESSURE_CHARGE")
                    self.b_legs_anim:refresh(self:sprite())
                    self.shadow_anim:set_state("SHADOW_BEASTPRESSURE_CHARGE")
                    self.shadow_anim:refresh(self.shadow)
                    self.body_anim:set_state("BODY_BEASTPRESSURE_CHARGE")
                    self.body_anim:refresh(self.body)
                    self.f_legs_anim:set_state("F_LEGS_BEASTPRESSURE_CHARGE")
                    self.f_legs_anim:refresh(self.f_legs)
                    self.head_anim:set_state("HEAD_BEASTPRESSURE_CHARGE")
                    self.head_anim:refresh(self.head)
                    Engine.play_audio(BEASTOUTIMPACT_FANG_AUDIO, AudioPriority.Low)
                    self.slide_tile = self:get_tile()
                    self.anim_once_2 = true
                    self.frames = 0 -- Resets the frame counter.
                end
            end
            if self.b_legs_anim:get_state() == "B_LEGS_BEASTPRESSURE_CHARGE" then
                local nxt_tile = self:get_tile(self:get_facing(), 1)
                if not nxt_tile:is_edge() then
                    self:slide(nxt_tile, frames(self.beastpressure_speed_frames), frames(0), ActionOrder.Voluntary, function()
                        self.sliding = true
                    end)
                    self:share_tile(true)
                    create_collision_attack1(self)
                else
                    if self.anim_once_2 then
                        self.anim_once_2 = false
                        Engine.play_audio(GREGAR_STOMP2_AUDIO, AudioPriority.Low)
                        self.shake_component2.timer = 200
                        --self:shake_camera(10, 3.233)
                        self.b_legs_anim:set_state("B_LEGS_BEASTPRESSURE_HIT")
                        self.b_legs_anim:refresh(self:sprite())
                        self.shadow_anim:set_state("SHADOW_BEASTPRESSURE_HIT")
                        self.shadow_anim:refresh(self.shadow)
                        self.body_anim:set_state("BODY_BEASTPRESSURE_HIT")
                        self.body_anim:refresh(self.body)
                        self.f_legs_anim:set_state("F_LEGS_BEASTPRESSURE_HIT")
                        self.f_legs_anim:refresh(self.f_legs)
                        self.head_anim:set_state("HEAD_BEASTPRESSURE_HIT")
                        self.head_anim:refresh(self.head)
                        rock_spawner2(self, self.beastpressure_frames)
                        self.frames = 0 -- Resets the frame counter.
                        self.b_legs_anim:on_complete(function()
                            for i=1, field:width() do
                                local back_tile = self:get_tile(self:get_facing_away(), i)
                                if back_tile:get_tile(self:get_facing_away(), 1):is_edge() then
                                    self:teleport(back_tile, ActionOrder.Immediate)
                                    self:share_tile(false)
                                    break
                                end
                            end
                            self.b_legs_anim:set_state("B_LEGS_LAND2")
                            self.b_legs_anim:refresh(self:sprite())
                            self.shadow_anim:set_state("SHADOW_LAND2")
                            self.shadow_anim:refresh(self.shadow)
                            self.body_anim:set_state("BODY_LAND2")
                            self.body_anim:refresh(self.body)
                            self.f_legs_anim:set_state("F_LEGS_LAND2")
                            self.f_legs_anim:refresh(self.f_legs)
                            self.head_anim:set_state("HEAD_LAND2")
                            self.head_anim:refresh(self.head)
                            self.b_legs_anim:on_complete(function()
                                self.b_legs_anim:set_state("B_LEGS_IDLE")
                                self.b_legs_anim:set_playback(Playback.Loop)
                                self.b_legs_anim:refresh(self:sprite())
                                self.shadow_anim:set_state("SHADOW_IDLE")
                                self.shadow_anim:set_playback(Playback.Loop)
                                self.shadow_anim:refresh(self.shadow)
                                self.body_anim:set_state("BODY_IDLE")
                                self.body_anim:set_playback(Playback.Loop)
                                self.body_anim:refresh(self.body)
                                self.f_legs_anim:set_state("F_LEGS_IDLE")
                                self.f_legs_anim:set_playback(Playback.Loop)
                                self.f_legs_anim:refresh(self.f_legs)
                                self.head_anim:set_state("HEAD_IDLE")
                                self.head_anim:set_playback(Playback.Loop)
                                self.head_anim:refresh(self.head)
                            end)
                        end)
                    end
                end
            end
            if self.b_legs_anim:get_state() == "B_LEGS_BEASTPRESSURE_HIT" or self.b_legs_anim:get_state() == "B_LEGS_LAND2" or self.b_legs_anim:get_state() == "B_LEGS_IDLE" then
                if self.b_legs_anim:get_state() == "B_LEGS_BEASTPRESSURE_HIT" then
                    self:share_tile(true)
                    create_collision_attack1(self)
                end
                if self.frames >= 196 then
                    self.moving_to_edge = false
                    self.moving_to_enemy_tile = false
                    self.pattern_index = self.pattern_index + 1
                    if self.pattern_index > #self.pattern then
                        self.pattern_index = 1
                    end
                    self.change_pattern = true
                end
                for i=37, 37+36*4, 36 do
                    if self.frames == i then
                        Engine.play_audio(STONE_BREAK2_AUDIO, AudioPriority.Low)
                    end
                end
            end
            --[[
            if self.framecounter == 4 then
                
            elseif self.framecounter == 23 then
                
            elseif self.framecounter == 42 then
            elseif self.framecounter == 61 then
            elseif self.framecounter == 80 then
            elseif self.framecounter == 99 then
            elseif self.framecounter == 118 then
            elseif self.framecounter == 137 then
                
            elseif self.framecounter == 156 then
                
            elseif self.framecounter == 175 then
                
            end
            ]]
        elseif activity == "CHOOSE ATTACK" then
            if self:get_health() > math.floor(self.health/2) then
                activity = "BEAST OUT IMPACT"
            else
                activity = "BEAST PRESSURE"
            end
        end
        self.frames = self.frames + 1

        --[[
        if self.cooldown <= 0 then
            if self.b_legs_anim:get_state() == "B_LEGS_STUN" then
                self.b_legs_anim:on_complete(function()
                    self.flinching = false
                    self.anim_once = true
                    self.anim_once_2 = false
                    self.counter_sfx = 0
                    self.counter_hit = 0
                    self.framecounter = 0
                    self.moving_to_edge = false
                    self.moving_to_enemy_tile = false
                    self.pattern_index = self.pattern_index + 1
                    if self.pattern[self.pattern_index] == "BREATH" or self.pattern[self.pattern_index] == "GATLING TAIL" or self.pattern[self.pattern_index] == "BEAST OUT IMPACT" or self.pattern[self.pattern_index] == "CHOOSE ATTACK" then
                        self.pattern_index = self.pattern_index + 1
                    end
                    if self.pattern_index > #self.pattern then
                        self.pattern_index = 1
                    end
                    self.change_pattern = true
                end)
            end
            if self.change_pattern then
                self.change_pattern = false
                activity = self.pattern[self.pattern_index]
            end
            if activity == "STONE FALL" then
                if self.anim_once then
                    self.anim_once = false
                    self.prev_tile = self:get_tile()
                    self.b_legs_anim:set_state("B_LEGS_WARP")
                    self.b_legs_anim:refresh(self:sprite())
                    self.shadow_anim:set_state("SHADOW_WARP")
                    self.shadow_anim:refresh(self.shadow)
                    self.body_anim:set_state("BODY_WARP")
                    self.body_anim:refresh(self.body)
                    self.f_legs_anim:set_state("F_LEGS_WARP")
                    self.f_legs_anim:refresh(self.f_legs)
                    self.head_anim:set_state("HEAD_WARP")
                    self.head_anim:refresh(self.head)
                    self.b_legs_anim:on_frame(5, function()
                        self:toggle_hitbox(false)
                        self.y_offset = self.y_offset_max
                        self:set_offset(0,self.y_offset)
                        self.shadow:set_offset(0,-self.y_offset)
                        self.body:set_offset(0,0)
                        self.f_legs:set_offset(0,0)
                        self.head:set_offset(0,0)
                    end)
                    self.b_legs_anim:on_complete(function()
                        local tile_filter = function(tile)
                            return not tile:is_edge() and tile:get_team() == self:get_team() and tile ~= self.prev_tile and (tile:x() < 3 or tile:x() > 4)
                        end
                        self.tile_list = self:get_field():find_tiles(tile_filter)
                        self.next_tile = self.tile_list[math.random(1, #self.tile_list)]
                        self:teleport(self.next_tile, ActionOrder.Immediate)
                        self.b_legs_anim:set_state("B_LEGS_STAND")
                        self.b_legs_anim:refresh(self:sprite())
                        self.shadow_anim:set_state("SHADOW_STAND")
                        self.shadow_anim:refresh(self.shadow)
                        self.body_anim:set_state("BODY_STAND")
                        self.body_anim:refresh(self.body)
                        self.f_legs_anim:set_state("F_LEGS_STAND")
                        self.f_legs_anim:refresh(self.f_legs)
                        self.head_anim:set_state("HEAD_STAND")
                        self.head_anim:refresh(self.head)
                        self.anim_once_2 = true
                    end)
                end
                if self.b_legs_anim:get_state() == "B_LEGS_STAND" then
                    if self.y_offset < 0 then
                        self.y_offset = self.y_offset + 40
                        self:set_offset(0,self.y_offset)
                        self.shadow:set_offset(0,-self.y_offset/2)
                        self.body:set_offset(0,0)
                        self.f_legs:set_offset(0,0)
                        self.head:set_offset(0,0)
                    else
                        if self.anim_once_2 then
                            self.anim_once_2 = false
                            Engine.play_audio(GREGAR_STOMP_AUDIO, AudioPriority.Low)
                            --self.shake_component.timer = 30
                            self:shake_camera(10, 0.5)
                            self:toggle_hitbox(true)
                            self.b_legs_anim:set_state("B_LEGS_LAND1")
                            self.b_legs_anim:refresh(self:sprite())
                            self.shadow_anim:set_state("SHADOW_LAND1")
                            self.shadow_anim:refresh(self.shadow)
                            self.body_anim:set_state("BODY_LAND1")
                            self.body_anim:refresh(self.body)
                            self.f_legs_anim:set_state("F_LEGS_LAND1")
                            self.f_legs_anim:refresh(self.f_legs)
                            self.head_anim:set_state("HEAD_LAND1")
                            self.head_anim:refresh(self.head)
                            self.b_legs_anim:on_frame(3, function()
                                rock_spawner(self)
                            end)
                            self.b_legs_anim:on_complete(function()
                                self.anim_once = true
                                self.pattern_index = self.pattern_index + 1
                                if self.pattern_index > #self.pattern then
                                    self.pattern_index = 1
                                end
                                self.change_pattern = true
                            end)
                        end
                    end
                end
            elseif activity == "BREATH" then
                if self.anim_once then
                    self.anim_once = false
                    self.prev_tile = self:get_tile()
                    self.b_legs_anim:set_state("B_LEGS_WARP")
                    self.b_legs_anim:refresh(self:sprite())
                    self.shadow_anim:set_state("SHADOW_WARP")
                    self.shadow_anim:refresh(self.shadow)
                    self.body_anim:set_state("BODY_WARP")
                    self.body_anim:refresh(self.body)
                    self.f_legs_anim:set_state("F_LEGS_WARP")
                    self.f_legs_anim:refresh(self.f_legs)
                    self.head_anim:set_state("HEAD_WARP")
                    self.head_anim:refresh(self.head)
                    self.b_legs_anim:on_frame(5, function()
                        self:toggle_hitbox(false)
                        self.y_offset = self.y_offset_max
                        self:set_offset(0,self.y_offset)
                        self.shadow:set_offset(0,-self.y_offset)
                        self.body:set_offset(0,0)
                        self.f_legs:set_offset(0,0)
                        self.head:set_offset(0,0)
                    end)
                    self.b_legs_anim:on_complete(function()
                        self.tile_list_f = {}
                        self.breath_type = math.random(1,2)
                        local enemy_filter = function(character)
                            return character:get_team() ~= self:get_team() and character:get_health() > 0
                        end
                        local enemy_list = self:get_field():find_nearest_characters(self, enemy_filter)
                        if enemy_list[1] then
                            self.enemy_list = enemy_list
                        end
                        local target_x = 2
                        if self:get_facing() == Direction.Left then
                            target_x = 5
                        end
                        local target_y = nil
                        if enemy_list[1] and self.breath_type == 2 then
                            target_y = enemy_list[1]:get_tile():y()
                        elseif self.breath_type == 1 then
                            target_y = 2
                        else
                            target_y = math.random(1,3)
                        end
                        self.next_tile = field:tile_at(target_x,target_y)
                        if self.breath_type == 1 then
                            local tile_filter = function(tile)
                                if not tile:is_edge() then
                                    if tile == self.next_tile:get_tile(self:get_facing(),2)
                                    or (self:get_facing() == Direction.Right and tile:x() > self.next_tile:get_tile(self:get_facing(),2):x()) 
                                    or (self:get_facing() == Direction.Left  and tile:x() < self.next_tile:get_tile(self:get_facing(),2):x()) then
                                        return true
                                    end
                                end
                            end
                            self.tile_list_f = self:get_field():find_tiles(tile_filter)
                        end
                        self:teleport(self.next_tile, ActionOrder.Immediate)
                        self.b_legs_anim:set_state("B_LEGS_STAND")
                        self.b_legs_anim:refresh(self:sprite())
                        self.shadow_anim:set_state("SHADOW_STAND")
                        self.shadow_anim:refresh(self.shadow)
                        self.body_anim:set_state("BODY_STAND")
                        self.body_anim:refresh(self.body)
                        self.f_legs_anim:set_state("F_LEGS_STAND")
                        self.f_legs_anim:refresh(self.f_legs)
                        self.head_anim:set_state("HEAD_STAND")
                        self.head_anim:refresh(self.head)
                        self.anim_once_2 = true
                    end)
                end
                if self.b_legs_anim:get_state() == "B_LEGS_STAND" then
                    if self.y_offset < 0 then
                        self.y_offset = self.y_offset + 40
                        self:set_offset(0,self.y_offset)
                        self.shadow:set_offset(0,-self.y_offset/2)
                        self.body:set_offset(0,0)
                        self.f_legs:set_offset(0,0)
                        self.head:set_offset(0,0)
                    else
                        if self.anim_once_2 then
                            self.anim_once_2 = false
                            Engine.play_audio(GREGAR_STOMP_AUDIO, AudioPriority.Low)
                            --self.shake_component.timer = 30
                            self:shake_camera(10, 0.5)
                            self:toggle_hitbox(true)
                            self.b_legs_anim:set_state("B_LEGS_LAND2")
                            self.b_legs_anim:refresh(self:sprite())
                            self.shadow_anim:set_state("SHADOW_LAND2")
                            self.shadow_anim:refresh(self.shadow)
                            self.body_anim:set_state("BODY_LAND2")
                            self.body_anim:refresh(self.body)
                            self.f_legs_anim:set_state("F_LEGS_LAND2")
                            self.f_legs_anim:refresh(self.f_legs)
                            self.head_anim:set_state("HEAD_LAND2")
                            self.head_anim:refresh(self.head)
                            self.b_legs_anim:on_complete(function()
                                if self.breath_type == 1 then
                                    self.b_legs_anim:set_state("B_LEGS_BURNINGBREATH_CHARGE")
                                    self.b_legs_anim:refresh(self:sprite())
                                    self.shadow_anim:set_state("SHADOW_BURNINGBREATH_CHARGE")
                                    self.shadow_anim:refresh(self.shadow)
                                    self.body_anim:set_state("BODY_BURNINGBREATH_CHARGE")
                                    self.body_anim:refresh(self.body)
                                    self.f_legs_anim:set_state("F_LEGS_BURNINGBREATH_CHARGE")
                                    self.f_legs_anim:refresh(self.f_legs)
                                    self.head_anim:set_state("HEAD_BURNINGBREATH_CHARGE")
                                    self.head_anim:refresh(self.head)
                                    self.b_legs_anim:on_complete(function()
                                        self.b_legs_anim:set_state("B_LEGS_BREATH")
                                        self.b_legs_anim:refresh(self:sprite())
                                        self.shadow_anim:set_state("SHADOW_BREATH")
                                        self.shadow_anim:refresh(self.shadow)
                                        self.body_anim:set_state("BODY_BREATH")
                                        self.body_anim:refresh(self.body)
                                        self.f_legs_anim:set_state("F_LEGS_BREATH")
                                        self.f_legs_anim:refresh(self.f_legs)
                                        self.head_anim:set_state("HEAD_BREATH")
                                        self.head_anim:refresh(self.head)
                                        Engine.play_audio(GREGAR_ROAR_AUDIO, AudioPriority.Low)
                                        for i=1, #self.tile_list_f do
                                            create_burning_hitbox(self, self.tile_list_f[i])
                                        end
                                        self.b_legs_anim:on_complete(function()
                                            self.b_legs_anim:set_state("B_LEGS_IDLE")
                                            self.b_legs_anim:refresh(self:sprite())
                                            self.shadow_anim:set_state("SHADOW_IDLE")
                                            self.shadow_anim:refresh(self.shadow)
                                            self.body_anim:set_state("BODY_IDLE")
                                            self.body_anim:refresh(self.body)
                                            self.f_legs_anim:set_state("F_LEGS_IDLE")
                                            self.f_legs_anim:refresh(self.f_legs)
                                            self.head_anim:set_state("HEAD_IDLE")
                                            self.head_anim:refresh(self.head)
                                        end)
                                    end)
                                else
                                    self.b_legs_anim:set_state("B_LEGS_LIGHTNINGBREATH_CHARGE")
                                    self.b_legs_anim:refresh(self:sprite())
                                    self.shadow_anim:set_state("SHADOW_LIGHTNINGBREATH_CHARGE")
                                    self.shadow_anim:refresh(self.shadow)
                                    self.body_anim:set_state("BODY_LIGHTNINGBREATH_CHARGE")
                                    self.body_anim:refresh(self.body)
                                    self.f_legs_anim:set_state("F_LEGS_LIGHTNINGBREATH_CHARGE")
                                    self.f_legs_anim:refresh(self.f_legs)
                                    self.head_anim:set_state("HEAD_LIGHTNINGBREATH_CHARGE")
                                    self.head_anim:refresh(self.head)
                                    self.ring_anim:set_state("LIGHTNINGBREATH_RING2")
                                    self.ring_anim:refresh(self.ring)
                                    self.ring_anim:set_playback(Playback.Loop)
                                    for i=1, 6, 5 do
                                        self.b_legs_anim:on_frame(i, function()
                                            Engine.play_audio(LIGHTNINGBREATH_CHARGE_AUDIO, AudioPriority.Low)
                                        end)
                                    end
                                    self.b_legs_anim:on_complete(function()
                                        self.b_legs_anim:set_state("B_LEGS_BREATH")
                                        self.b_legs_anim:refresh(self:sprite())
                                        self.shadow_anim:set_state("SHADOW_BREATH")
                                        self.shadow_anim:refresh(self.shadow)
                                        self.body_anim:set_state("BODY_BREATH")
                                        self.body_anim:refresh(self.body)
                                        self.f_legs_anim:set_state("F_LEGS_BREATH")
                                        self.f_legs_anim:refresh(self.f_legs)
                                        self.head_anim:set_state("HEAD_BREATH")
                                        self.head_anim:refresh(self.head)
                                        self.ring_anim:set_state("LIGHTNINGBREATH_RING1")
                                        self.ring_anim:refresh(self.ring)
                                        self.ring_anim:set_playback(Playback.Loop)
                                        Engine.play_audio(GREGAR_ROAR_AUDIO, AudioPriority.Low)
                                        self.lightning1 = graphic_init("spell", 0, 0, LIGHTNINGBREATH_TEXTURE, LIGHTNINGBREATH_PALETTE, LIGHTNINGBREATH_ANIMPATH, -3, "0", Playback.Loop, self, self:get_facing())
                                        self.lightning2 = graphic_init("spell", 0, 0, LIGHTNINGBREATH_TEXTURE, LIGHTNINGBREATH_PALETTE, LIGHTNINGBREATH_ANIMPATH, -3, "1", Playback.Loop, self, self:get_facing())
                                        field:spawn(self.lightning1, self:get_tile(self:get_facing(), 4))
                                        for i=1, field:width() do
                                            local hl_tile = self:get_tile(self:get_facing(), i+1)
                                            if hl_tile and not hl_tile:is_edge() then 
                                                create_lightning_hitbox(self, hl_tile)
                                            else
                                                break
                                            end
                                        end
                                        local s_tile = self:get_tile(self:get_facing(), 2)
                                        field:spawn(self.lightning2, s_tile)
                                        for i=1, field:height() do
                                            local hl_tile = field:tile_at(s_tile:x(), i)
                                            if hl_tile and not hl_tile:is_edge() and i ~= s_tile:y() then 
                                                create_lightning_hitbox(self, hl_tile)
                                            end
                                        end
                                        self.b_legs_anim:on_complete(function()
                                            self.lightning1:delete()
                                            self.lightning2:delete()
                                            self.b_legs_anim:set_state("B_LEGS_IDLE")
                                            self.b_legs_anim:refresh(self:sprite())
                                            self.shadow_anim:set_state("SHADOW_IDLE")
                                            self.shadow_anim:refresh(self.shadow)
                                            self.body_anim:set_state("BODY_IDLE")
                                            self.body_anim:refresh(self.body)
                                            self.f_legs_anim:set_state("F_LEGS_IDLE")
                                            self.f_legs_anim:refresh(self.f_legs)
                                            self.head_anim:set_state("HEAD_IDLE")
                                            self.head_anim:refresh(self.head)
                                            self.ring_anim:set_state("LIGHTNINGBREATH_RING0")
                                            self.ring_anim:refresh(self.ring)
                                        end)
                                    end)
                                end
                            end)
                        end
                    end
                elseif self.b_legs_anim:get_state() == "B_LEGS_BURNINGBREATH_CHARGE" then
                    for i=1, #self.tile_list_f do
                        self.tile_list_f[i]:highlight(Highlight.Flash)
                    end
                elseif self.b_legs_anim:get_state() == "B_LEGS_LIGHTNINGBREATH_CHARGE" then
                    for i=1, field:width() do
                        local hl_tile = self:get_tile(self:get_facing(),i+1)
                        if hl_tile and not hl_tile:is_edge() then 
                            hl_tile:highlight(Highlight.Flash)
                        else
                            break
                        end
                    end
                    local s_tile = self:get_tile(self:get_facing(), 2)
                    for i=1, field:height() do
                        local hl_tile = field:tile_at(s_tile:x(), i)
                        if hl_tile and not hl_tile:is_edge() and i ~= s_tile:y() then 
                            hl_tile:highlight(Highlight.Flash)
                        end
                    end
                elseif self.b_legs_anim:get_state() == "B_LEGS_BREATH" then
                    if self:is_counterable() then
                        debug_print("IS counterable")
                    else
                        debug_print("NOT counterable")
                    end
                    self.counter_sfx = self.counter_sfx + 1
                    self.counter_hit = self.counter_hit + 1
                    for i=6, (6+16)*5, 16 do
                        if self.counter_sfx == i then
                            if self.breath_type == 1 then
                                Engine.play_audio(BURNINGBREATH_AUDIO, AudioPriority.Low)
                            else
                                Engine.play_audio(LIGHTNINGBREATH_ATTACK_AUDIO, AudioPriority.Low)
                            end
                        end
                    end
                    if self.counter_hit == 2 then
                        self:toggle_counter(true)
                    elseif self.counter_hit == 11 then
                        self:toggle_counter(false)
                    end
                elseif self.b_legs_anim:get_state() == "B_LEGS_IDLE" then
                    self.framecounter = self.framecounter + 1
                    if self.breath_type == 1 then
                        if self.framecounter == 12 then
                            self.anim_once = true
                            self.counter_sfx = 0
                            self.counter_hit = 0
                            self.framecounter = 0
                            self.pattern_index = self.pattern_index + 1
                            if self.pattern_index > #self.pattern then
                                self.pattern_index = 1
                            end
                            self.change_pattern = true
                        end
                    else
                        if self.framecounter == 7 then
                            self.anim_once = true
                            self.counter_sfx = 0
                            self.counter_hit = 0
                            self.framecounter = 0
                            self.pattern_index = self.pattern_index + 1
                            if self.pattern_index > #self.pattern then
                                self.pattern_index = 1
                            end
                            self.change_pattern = true
                        end
                    end
                end
            elseif activity == "GATLING TAIL" then
                if self.anim_once then
                    self.anim_once = false
                    self.b_legs_anim:set_state("B_LEGS_GATLINGTAIL_START")
                    self.b_legs_anim:refresh(self:sprite())
                    self.shadow_anim:set_state("SHADOW_GATLINGTAIL_START")
                    self.shadow_anim:refresh(self.shadow)
                    self.body_anim:set_state("BODY_GATLINGTAIL_START")
                    self.body_anim:refresh(self.body)
                    self.f_legs_anim:set_state("F_LEGS_GATLINGTAIL_START")
                    self.f_legs_anim:refresh(self.f_legs)
                    self.head_anim:set_state("HEAD_GATLINGTAIL_START")
                    self.head_anim:refresh(self.head)
                    local target_tile = nil
                    self.b_legs_anim:on_frame(5, function()
                        local enemy_filter = function(character)
                            return character:get_team() ~= self:get_team() and character:get_health() > 0
                        end
                        local enemy_list = self:get_field():find_nearest_characters(self, enemy_filter)
                        if enemy_list[1] then
                            self.enemy_list = enemy_list
                        end
                        target_tile = field:tile_at(self.enemy_list[1]:get_tile():x(), 1)
                        create_highlight(self, target_tile, 20)
                    end)
                    self.b_legs_anim:on_complete(function()
                        self.b_legs_anim:set_state("B_LEGS_GATLINGTAIL_SHOOT")
                        self.b_legs_anim:refresh(self:sprite())
                        self.shadow_anim:set_state("SHADOW_GATLINGTAIL_SHOOT")
                        self.shadow_anim:refresh(self.shadow)
                        self.body_anim:set_state("BODY_GATLINGTAIL_SHOOT")
                        self.body_anim:refresh(self.body)
                        self.f_legs_anim:set_state("F_LEGS_GATLINGTAIL_SHOOT")
                        self.f_legs_anim:refresh(self.f_legs)
                        self.head_anim:set_state("HEAD_GATLINGTAIL_SHOOT")
                        self.head_anim:refresh(self.head)
                        local dir_tile = Direction.Down
                        for i=1, 1+4*8, 4 do
                            self.b_legs_anim:on_frame(i, function()
                                create_gatling_hitbox(self, target_tile)
                                if not target_tile:get_tile(dir_tile, 1):is_edge() then
                                    target_tile = target_tile:get_tile(dir_tile, 1)
                                else
                                    dir_tile = Direction.reverse(dir_tile)
                                end
                            end)
                        end
                        for i=2, 2+4*8, 4 do
                            self.b_legs_anim:on_frame(i, function()
                                create_highlight(self, target_tile, 20)
                            end)
                        end
                    end)
                end
                if self.b_legs_anim:get_state() == "B_LEGS_GATLINGTAIL_SHOOT" then
                    if self.counter_hit < 14 then
                        self.counter_hit = self.counter_hit + 1
                        if self.counter_hit == 4 then
                            self:toggle_counter(true)
                        elseif self.counter_hit == 13 then
                            self:toggle_counter(false)
                        end
                    end
                    self.b_legs_anim:on_complete(function()
                        self.anim_once = true
                        self.counter_hit = 0
                        self.pattern_index = self.pattern_index + 1
                        if self.pattern_index > #self.pattern then
                            self.pattern_index = 1
                        end
                        self.change_pattern = true
                    end)
                end
            elseif activity == "BEAST OUT IMPACT" then
                if self.anim_once then
                    self.anim_once = false
                    self.moving_to_edge = true
                    self.moving_to_enemy_tile = true
                    self.b_legs_anim:set_state("B_LEGS_WARP2")
                    self.b_legs_anim:refresh(self:sprite())
                    self.shadow_anim:set_state("SHADOW_WARP2")
                    self.shadow_anim:refresh(self.shadow)
                    self.body_anim:set_state("BODY_WARP2")
                    self.body_anim:refresh(self.body)
                    self.f_legs_anim:set_state("F_LEGS_WARP2")
                    self.f_legs_anim:refresh(self.f_legs)
                    self.head_anim:set_state("HEAD_WARP2")
                    self.head_anim:refresh(self.head)
                    self.b_legs_anim:on_frame(5, function()
                        self:toggle_hitbox(false)
                        self.y_offset = self.y_offset_max
                        self:set_offset(0,self.y_offset)
                        --self.shadow:set_offset(0,-self.y_offset)
                        self.shadow:set_offset(0,0)
                        self.body:set_offset(0,0)
                        self.f_legs:set_offset(0,0)
                        self.head:set_offset(0,0)
                    end)
                    self.b_legs_anim:on_frame(6, function()
                        for i=2, 5, 1 do
                            for j=1, 3, 1 do
                                local hl_tile = field:tile_at(i,j)
                                if (self:get_facing() == Direction.Right and i~=2) or (self:get_facing() == Direction.Left and i~=5) then
                                    create_highlight(self, hl_tile, 16)
                                end
                            end
                        end
                    end)
                    self.b_legs_anim:on_frame(7, function()
                        local target_tile = field:tile_at(3,3)
                        if self:get_facing() == Direction.Left then
                            target_tile = field:tile_at(4,3)
                        end
                        create_claw(self, target_tile, target_tile:get_tile(Direction.join(self:get_facing(), Direction.Up), 1), "CLAW_U", Direction.Up)
                        --create_slash(self, target_tile:get_tile(Direction.join(self:get_facing(), Direction.Up), 1), "2", Direction.Up)
                    end)
                    self.b_legs_anim:on_frame(8, function()
                        local target_tile = field:tile_at(4,0)
                        if self:get_facing() == Direction.Left then
                            target_tile = field:tile_at(3,0)
                        end
                        create_claw(self, target_tile, target_tile:get_tile(Direction.join(self:get_facing(), Direction.Down), 1):get_tile(Direction.Down, 1), "CLAW_D", Direction.Down)
                        --create_slash(self, target_tile:get_tile(Direction.join(self:get_facing(), Direction.Down), 1):get_tile(Direction.Down, 1), "0", Direction.Down)
                    end)
                    self.b_legs_anim:on_complete(function()
                        local enemy_filter = function(character)
                            return character:get_team() ~= self:get_team() and character:get_health() > 0
                        end
                        local enemy_list = self:get_field():find_nearest_characters(self, enemy_filter)
                        if enemy_list[1] then
                            self.enemy_list = enemy_list
                        end
                        self.front_tile = self.enemy_list[1]:get_tile()
                        local start_x = 0
                        if self:get_facing() == Direction.Left then start_x = 7 end
                        self:teleport(self:get_field():tile_at(start_x,self.front_tile:y()), ActionOrder.Immediate)
                        --debug_print("TILE1: ("..self:get_tile():x()..";"..self:get_tile():y()..")")
                        self.b_legs_anim:set_state("B_LEGS_BEASTOUTIMPACT")
                        self.b_legs_anim:refresh(self:sprite())
                        self.shadow_anim:set_state("SHADOW_BEASTOUTIMPACT")
                        self.shadow_anim:refresh(self.shadow)
                        self.body_anim:set_state("BODY_BEASTOUTIMPACT")
                        self.body_anim:refresh(self.body)
                        self.f_legs_anim:set_state("F_LEGS_BEASTOUTIMPACT")
                        self.f_legs_anim:refresh(self.f_legs)
                        self.head_anim:set_state("HEAD_BEASTOUTIMPACT")
                        self.head_anim:refresh(self.head)
                        self.anim_once_2 = true
                    end)
                end
                if self.b_legs_anim:get_state() == "B_LEGS_BEASTOUTIMPACT" then
                    if self.anim_once_2 then
                        self.anim_once_2 = false
                        Engine.play_audio(BEASTOUTIMPACT_FANG_AUDIO, AudioPriority.Low)
                        self:set_offset(0,0)
                        self.elevation = self.elevation_max
                        self:set_elevation(self.elevation)
                        self.shadow:set_offset(0,self.elevation/2)
                        self.shadow:set_offset(0,0)
                        self.body:set_offset(0,0)
                        self.f_legs:set_offset(0,0)
                        self.head:set_offset(0,0)
                        self.move_state = 1
                        self:toggle_hitbox(true)
                        self.collision_attack = create_collision_attack2(self)
                        self.collision_spawned = false
                        self.slide_tile = self:get_tile()
                    end
                    if self:get_tile() == self.front_tile then
                        if not self.collision_spawned then
                            self.collision_spawned = true
                            field:spawn(self.collision_attack, self:get_tile())
                        end
                    else
                        if self.collision_spawned then
                            self.collision_spawned = false
                            self.collision_attack:erase()
                        end
                    end
                    if self.move_state == 1 then
                        --debug_print("TILE: ("..self:get_tile():x()..";"..self:get_tile():y()..")")
                        if not self.reached_tile then
                            if self:get_tile() ~= self.front_tile then
                                local nxt_tile = self:get_tile(self:get_facing(), 1)
                                self:slide(nxt_tile, frames(5), frames(0), ActionOrder.Voluntary, function()
                                    self.sliding = true
                                end)
                            else
                                self.moving_to_edge = true
                                self.moving_to_enemy_tile = true
                                --self.shake_component.timer = 20
                                self:shake_camera(20, 0.5)
                                self.reached_tile = true
                                self.move_state = 2
                            end
                            self:set_elevation(self.elevation)
                            self.shadow:set_offset(0,self.elevation/2)
                            self.body:set_offset(0,0)
                            self.f_legs:set_offset(0,0)
                            self.head:set_offset(0,0)
                            if self.front_tile:x() == 3 or self.front_tile:x() == 4 then
                                self.elevation = self.elevation - 8
                            elseif self.front_tile:x() < 3 or self.front_tile:x() > 4 then
                                self.elevation = self.elevation - 4
                            end
                            self.front_tile:highlight(Highlight.Flash)
                        end
                    elseif self.move_state == 2 then
                        if self.framecounter < 22 then
                            self.framecounter = self.framecounter + 1
                        else
                            if self:get_facing() == Direction.Right then
                                self.back_tile = field:tile_at(2,self:get_tile():y())
                            else
                                self.back_tile = field:tile_at(5,self:get_tile():y())
                            end
                            self.framecounter = 0
                            self.move_state = 3
                        end
                    elseif self.move_state == 3 then
                        if self.reached_tile then
                            if self:get_tile() ~= self.back_tile then
                                local nxt_tile = self:get_tile(self:get_facing_away(), 1)
                                self:slide(nxt_tile, frames(5), frames(0), ActionOrder.Voluntary, function()
                                    self.sliding = true
                                end)
                            else
                                if not self:is_sliding() then
                                    self.sliding = false
                                    self.elevation = 0
                                    self:set_elevation(self.elevation)
                                    self.shadow:set_offset(0,0)
                                    self.body:set_offset(0,0)
                                    self.f_legs:set_offset(0,0)
                                    self.head:set_offset(0,0)
                                    self.b_legs_anim:set_state("B_LEGS_LAND3")
                                    self.b_legs_anim:refresh(self:sprite())
                                    self.shadow_anim:set_state("SHADOW_LAND3")
                                    self.shadow_anim:refresh(self.shadow)
                                    self.body_anim:set_state("BODY_LAND3")
                                    self.body_anim:refresh(self.body)
                                    self.f_legs_anim:set_state("F_LEGS_LAND3")
                                    self.f_legs_anim:refresh(self.f_legs)
                                    self.head_anim:set_state("HEAD_LAND3")
                                    self.head_anim:refresh(self.head)
                                    self.reached_tile = false
                                    self.move_state = 4
                                end
                            end
                            self:set_elevation(self.elevation)
                            self.shadow:set_offset(0,self.elevation/2)
                            self.body:set_offset(0,0)
                            self.f_legs:set_offset(0,0)
                            self.head:set_offset(0,0)
                            if self.front_tile:x() == 3 or self.front_tile:x() == 4 then
                                self.elevation = self.elevation + 8
                            elseif self.front_tile:x() < 3 or self.front_tile:x() > 4 then
                                self.elevation = self.elevation + 4
                            end
                        end
                    end
                elseif self.b_legs_anim:get_state() == "B_LEGS_LAND3" then
                    self.b_legs_anim:on_complete(function()
                        self.anim_once = true
                        self.anim_once_2 = false
                        self.move_state = 0
                        self.moving_to_edge = false
                        self.moving_to_enemy_tile = false
                        self.pattern_index = self.pattern_index + 1
                        if self.pattern_index > #self.pattern then
                            self.pattern_index = 1
                        end
                        self.change_pattern = true
                    end)
                end
            elseif activity == "BEAST PRESSURE" then
                if self.anim_once then
                    self.anim_once = false
                    self.moving_to_edge = true
                    self.moving_to_enemy_tile = true
                    self.b_legs_anim:set_state("B_LEGS_BEASTPRESSURE_ROAR")
                    self.b_legs_anim:refresh(self:sprite())
                    self.shadow_anim:set_state("SHADOW_BEASTPRESSURE_ROAR")
                    self.shadow_anim:refresh(self.shadow)
                    self.body_anim:set_state("BODY_BEASTPRESSURE_ROAR")
                    self.body_anim:refresh(self.body)
                    self.f_legs_anim:set_state("F_LEGS_BEASTPRESSURE_ROAR")
                    self.f_legs_anim:refresh(self.f_legs)
                    self.head_anim:set_state("HEAD_BEASTPRESSURE_ROAR")
                    self.head_anim:refresh(self.head)
                    Engine.play_audio(GREGAR_ROAR_AUDIO, AudioPriority.Low)
                    for i=5, 17, 6 do 
                        self.b_legs_anim:on_frame(i, function()
                            Engine.play_audio(GREGAR_SHAKE_AUDIO, AudioPriority.Low)
                        end)
                    end
                    self.b_legs_anim:on_complete(function()
                        self.b_legs_anim:set_state("B_LEGS_BEASTPRESSURE_READY")
                        self.b_legs_anim:refresh(self:sprite())
                        self.shadow_anim:set_state("SHADOW_BEASTPRESSURE_READY")
                        self.shadow_anim:refresh(self.shadow)
                        self.body_anim:set_state("BODY_BEASTPRESSURE_READY")
                        self.body_anim:refresh(self.body)
                        self.f_legs_anim:set_state("F_LEGS_BEASTPRESSURE_READY")
                        self.f_legs_anim:refresh(self.f_legs)
                        self.head_anim:set_state("HEAD_BEASTPRESSURE_READY")
                        self.head_anim:refresh(self.head)
                        self.b_legs_anim:on_frame(3, function()
                            for i=0, field:width() do
                                local hl_tile = self:get_tile(self:get_facing(), i)
                                if hl_tile and not hl_tile:is_edge() then 
                                    create_highlight(self, hl_tile, 16)
                                else
                                    break
                                end
                            end
                        end)
                        self.b_legs_anim:on_complete(function()
                            self.b_legs_anim:set_state("B_LEGS_BEASTPRESSURE_CHARGE")
                            self.b_legs_anim:refresh(self:sprite())
                            self.shadow_anim:set_state("SHADOW_BEASTPRESSURE_CHARGE")
                            self.shadow_anim:refresh(self.shadow)
                            self.body_anim:set_state("BODY_BEASTPRESSURE_CHARGE")
                            self.body_anim:refresh(self.body)
                            self.f_legs_anim:set_state("F_LEGS_BEASTPRESSURE_CHARGE")
                            self.f_legs_anim:refresh(self.f_legs)
                            self.head_anim:set_state("HEAD_BEASTPRESSURE_CHARGE")
                            self.head_anim:refresh(self.head)
                            Engine.play_audio(BEASTOUTIMPACT_FANG_AUDIO, AudioPriority.Low)
                            self.anim_once_2 = true
                            self.slide_tile = self:get_tile()
                        end)
                    end)
                end
                if self.b_legs_anim:get_state() == "B_LEGS_BEASTPRESSURE_CHARGE" then
                    local nxt_tile = self:get_tile(self:get_facing(), 1)
                    if not nxt_tile:is_edge() then
                        self:slide(nxt_tile, frames(2), frames(0), ActionOrder.Voluntary, function()
                            self.sliding = true
                        end)
                        self:share_tile(true)
                        create_collision_attack1(self)
                    else
                        if self.anim_once_2 then
                            self.anim_once_2 = false
                            Engine.play_audio(GREGAR_STOMP2_AUDIO, AudioPriority.Low)
                            --self.shake_component.timer = 194
                            self:shake_camera(10, 3.233)
                            self.b_legs_anim:set_state("B_LEGS_BEASTPRESSURE_HIT")
                            self.b_legs_anim:refresh(self:sprite())
                            self.shadow_anim:set_state("SHADOW_BEASTPRESSURE_HIT")
                            self.shadow_anim:refresh(self.shadow)
                            self.body_anim:set_state("BODY_BEASTPRESSURE_HIT")
                            self.body_anim:refresh(self.body)
                            self.f_legs_anim:set_state("F_LEGS_BEASTPRESSURE_HIT")
                            self.f_legs_anim:refresh(self.f_legs)
                            self.head_anim:set_state("HEAD_BEASTPRESSURE_HIT")
                            self.head_anim:refresh(self.head)
                            self.b_legs_anim:on_complete(function()
                                for i=1, field:width() do
                                    local back_tile = self:get_tile(self:get_facing_away(), i)
                                    if back_tile:get_tile(self:get_facing_away(), 1):is_edge() then
                                        self:teleport(back_tile, ActionOrder.Immediate)
                                        self:share_tile(false)
                                        break
                                    end
                                end
                                self.b_legs_anim:set_state("B_LEGS_LAND2")
                                self.b_legs_anim:refresh(self:sprite())
                                self.shadow_anim:set_state("SHADOW_LAND2")
                                self.shadow_anim:refresh(self.shadow)
                                self.body_anim:set_state("BODY_LAND2")
                                self.body_anim:refresh(self.body)
                                self.f_legs_anim:set_state("F_LEGS_LAND2")
                                self.f_legs_anim:refresh(self.f_legs)
                                self.head_anim:set_state("HEAD_LAND2")
                                self.head_anim:refresh(self.head)
                                self.b_legs_anim:on_complete(function()
                                    self.b_legs_anim:set_state("B_LEGS_IDLE")
                                    self.b_legs_anim:refresh(self:sprite())
                                    self.b_legs_anim:set_playback(Playback.Loop)
                                    self.shadow_anim:set_state("SHADOW_IDLE")
                                    self.shadow_anim:refresh(self.shadow)
                                    self.shadow_anim:set_playback(Playback.Loop)
                                    self.body_anim:set_state("BODY_IDLE")
                                    self.body_anim:refresh(self.body)
                                    self.body_anim:set_playback(Playback.Loop)
                                    self.f_legs_anim:set_state("F_LEGS_IDLE")
                                    self.f_legs_anim:refresh(self.f_legs)
                                    self.f_legs_anim:set_playback(Playback.Loop)
                                    self.head_anim:set_state("HEAD_IDLE")
                                    self.head_anim:refresh(self.head)
                                    self.head_anim:set_playback(Playback.Loop)
                                end)
                            end)
                        end
                    end
                end
                if self.b_legs_anim:get_state() == "B_LEGS_BEASTPRESSURE_HIT" or self.b_legs_anim:get_state() == "B_LEGS_LAND2" or self.b_legs_anim:get_state() == "B_LEGS_IDLE" then
                    if self.b_legs_anim:get_state() == "B_LEGS_BEASTPRESSURE_HIT" then
                        self:share_tile(true)
                        create_collision_attack1(self)
                    end
                    if self.framecounter >= 194 then
                        self.anim_once = true
                        self.anim_once_2 = false
                        self.framecounter = 0
                        self.moving_to_edge = false
                        self.moving_to_enemy_tile = false
                        self.pattern_index = self.pattern_index + 1
                        if self.pattern_index > #self.pattern then
                            self.pattern_index = 1
                        end
                        self.change_pattern = true
                    else
                        self.framecounter = self.framecounter + 1
                    end
                    for i=4, 4+38*4, 38 do
                        if self.framecounter == i then
                            local tile_filter = function(tile)
                                return not tile:is_edge() and tile:get_team() ~= self:get_team()
                            end
                            self.tile_list = self:get_field():find_tiles(tile_filter)
                            local enemy_filter = function(character)
                                return character:get_team() ~= self:get_team() and character:get_health() > 0
                            end
                            local enemy_list = self:get_field():find_nearest_characters(self, enemy_filter)
                            if enemy_list[1] then
                                self.enemy_list = enemy_list
                                self.stone1 = self.enemy_list[1]:get_tile()
                            else
                                self.stone1 = self.tile_list[math.random(1, #self.tile_list)]
                            end
                            if self.stone1 ~= nil then
                                drop_rock(self, self.stone1, true)
                            end
                        end
                    end
                    for i=23, 23+38*4, 38 do
                        if self.framecounter == i then
                            local tile_filter = function(tile)
                                return not tile:is_edge() and tile:get_team() ~= self:get_team()
                            end
                            self.tile_list = self:get_field():find_tiles(tile_filter)
                            local enemy_filter = function(character)
                                return character:get_team() ~= self:get_team() and character:get_health() > 0
                            end
                            local enemy_list = self:get_field():find_nearest_characters(self, enemy_filter)
                            if enemy_list[1] then
                                self.enemy_list = enemy_list
                            end
                            if enemy_list[1] and enemy_list[1]:get_tile() ~= self.stone1 then
                                self.enemy_list = enemy_list
                                self.stone2 = self.enemy_list[1]:get_tile()
                            else
                                repeat
                                    self.stone2 = self.tile_list[math.random(1, #self.tile_list)]
                                until self.stone2 ~= self.stone1
                            end
                            if self.stone2 ~= nil then
                                drop_rock(self, self.stone2, true)
                            end
                        end
                    end
                end
                
                --[[
                if self.framecounter == 4 then
                    
                elseif self.framecounter == 23 then
                    
                elseif self.framecounter == 42 then
                elseif self.framecounter == 61 then
                elseif self.framecounter == 80 then
                elseif self.framecounter == 99 then
                elseif self.framecounter == 118 then
                elseif self.framecounter == 137 then
                    
                elseif self.framecounter == 156 then
                    
                elseif self.framecounter == 175 then
                    
                end
            elseif activity == "CHOOSE ATTACK" then
                if self:get_health() > math.floor(self.health/2) then
                    activity = "BEAST OUT IMPACT"
                else
                    activity = "BEAST PRESSURE"
                end
            end
        else
            self.cooldown = self.cooldown - 1
        end]]
    end
end