----
--[[

    Colonel boss character from "Rockman EXE5: Team of Colonel" and "Rockman EXE5DS: Twin Leaders"
    Ported to Open Net Battle (ONB) by K1rbYat1Na

    Instantly turns any manipulatable Obstacles on the Player's tiles into Colonel Army.
    If the Player is to the left of a manipulatable Obstacle, turns into a gunner.
    If the Player is within 2 panels to the right of a manipulatable Obstacle, turns into a swordsman.
    Colonel can pass through his soldiers.

    Moveset:

    Colonel moves randomly 5 times, then uses Screen Divide. Can use it several times.
    If he's about use it for the 3rd time in a row and the Player is on back column, he uses Colonel Cannon instead.
    After that, he moves close to the Player and uses Colonel Cannon on every 3rd pattern loop.
    After that, he moves randomly once and uses Blind Rain Shower on every 6th pattern loop if HP≤50% (any version except for V1).
    Starting from the 3rd loops, he can randomly drop 1 or 2 Stone Cubes on the Player's tiles. Stone Cube has 200 HP.
    If Colonel's Confused or Blind, his idle time doesn't increase but his first Screen Divide becomes slower.
    If Colonel's Rooted, he skips IDLE and MOVE and spams attacks. Rooting can block Blind Rain Shower.

    Colonel DS can't use Battle Chips. His DSLV generates randomly on spawn.
    If the EXE5DS mode is ON, Blind Rain Shower causes Flashing.

--]]
----
local print_debug = false -- Turns on/off the debug text.

-- HIT SOUNDS --
local AUDIO_DAMAGE_ENEMY = Engine.load_audio(_folderpath.."sfx/EXE5_18.ogg", true)
local AUDIO_DAMAGE_OBS = Engine.load_audio(_folderpath.."sfx/EXE5_136.ogg", true)
----------------

-- THE CHARACTER GRAPHIC ASSETS --
local CHARACTER_TEXTURE = nil
local CHARACTER_PALETTE = nil
local CHARACTER_ANIMPATH = _folderpath.."gfx/battle.animation"
local COLONELCAPE_TEXTURE = Engine.load_texture(_folderpath.."gfx/colonelcape.grayscaled.png")
local COLONELCAPE_ANIMPATH = _folderpath.."gfx/colonelcape.animation"
----------------------------------

-- OTHER GRAPHIC ASSETS --
local COLONELARMY_TEXTURE = Engine.load_texture(_folderpath.."gfx/colonelarmy.grayscaled.png")
local COLONELARMY_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/colonelarmy.png")
local COLONELARMY_ANIMPATH = _folderpath.."gfx/colonelarmy.animation"
local SCREENDIVIDE_TEXTURE = Engine.load_texture(_folderpath.."gfx/screendivide.grayscaled.png")
local SCREENDIVIDE_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/screendivide.png")
local SCREENDIVIDE_ANIMPATH = _folderpath.."gfx/screendivide.animation"
--------------------------

-- OTHER GFXS --
local SLASH_TEXTURE = Engine.load_texture(_folderpath.."gfx/slash.grayscaled.png")
local SLASH_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/slash.png")
local SLASH_ANIMPATH = _folderpath.."gfx/slash.animation"
local SENSHAHOU_BOOM_TEXTURE = Engine.load_texture(_folderpath.."gfx/senshahou_boom.grayscaled.png")
local SENSHAHOU_BOOM_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/senshahou_boom.png")
local SENSHAHOU_BOOM_ANIMPATH = _folderpath.."gfx/senshahou_boom.animation"
local SENSHAHOU_SPREAD_TEXTURE = Engine.load_texture(_folderpath.."gfx/senshahou_spread.grayscaled.png")
local SENSHAHOU_SPREAD_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/senshahou_spread.png")
local SENSHAHOU_SPREAD_ANIMPATH = _folderpath.."gfx/senshahou_spread.animation"
local BOOM_TEXTURE = Engine.load_texture(_folderpath.."gfx/boom.grayscaled.png")
local BOOM_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/boom.png")
local BOOM_ANIMPATH = _folderpath.."gfx/boom.animation"
----------------

-- HIT GFXS --
local HIT_GUN_TEXTURE = Engine.load_texture(_folderpath.."gfx/effect_gun.grayscaled.png")
local HIT_GUN_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/effect_gun.png")
local HIT_GUN_ANIMPATH = _folderpath.."gfx/effect_gun.animation"
--------------

-- OTHER SOUNDS --
local SWORD_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE5_37.ogg", true)
local GUN_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE5_103.ogg", true)
local SCREENDIVIDE_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE5_138.ogg", true)
local CANNON_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE5_265.ogg", true)
local SENSHAHOU_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE5_123.ogg", true)
local STOMP_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE5_11.ogg", true)
local CAPETHROW_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE5_71.ogg", true)
local BLINRAINSHOWER_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE5_64.ogg", true)
local DREAMSWORD_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE5_234.ogg", true)
------------------

-- STONE CUBE --
local CUBE_TEXTURE = Engine.load_texture(_folderpath.."stonecube/gfx/cube.grayscaled.png")
local CUBE_PALETTE = Engine.load_texture(_folderpath.."stonecube/gfx/palette/cube.png")
local CUBE_ANIMPATH = _folderpath.."stonecube/gfx/cube.animation"
local SHADOW_TEXTURE_1 = Engine.load_texture(_folderpath.."stonecube/gfx/shadow1.png")

local PIECES_TEXTURE = Engine.load_texture(_folderpath.."stonecube/gfx/pieces.grayscaled.png")
local PIECES_PALETTE_STONE = Engine.load_texture(_folderpath.."stonecube/gfx/palette/stone.png")
local PIECES_ANIMPATH = _folderpath.."stonecube/gfx/pieces.animation"

local SMOKE_TEXTURE = Engine.load_texture(_folderpath.."stonecube/gfx/smoke.grayscaled.png") -- flip for Player 2
local SMOKE_PALETTE = Engine.load_texture(_folderpath.."stonecube/gfx/palette/smoke.png")
local SMOKE_ANIMPATH = _folderpath.."stonecube/gfx/smoke.animation"

local EFFECT_TEXTURE = Engine.load_texture(_folderpath.."stonecube/gfx/effect.grayscaled.png") -- flip for Player 2
local EFFECT_PALETTE = Engine.load_texture(_folderpath.."stonecube/gfx/palette/effect.png")
local EFFECT_ANIMPATH = _folderpath.."stonecube/gfx/effect.animation"

local CRACK_AUDIO = Engine.load_audio(_folderpath.."stonecube/sfx/EXE6_324.ogg", true)
----------------

-- LIBRARIES --
local ObstacleInfo = include("ObstacleInfo.lua")
---------------

-- Prints the debug text.
local function debug_print(text)
    if print_debug then
        print("[Colonel] "..text)
    end
end

--(Function by Alrysc, edited by K1rbYat1Na)
local function graphic_init(type, x, y, texture, palette, animation, layer, state, anim_playback, user, facing, delete_on_complete, relative_to_user, flip)
    texture = texture or nil
    animation = animation or nil
    layer = layer or nil
    state = state or nil
    anim_playback = anim_playback or nil
    facing = facing or nil
    delete_on_complete = delete_on_complete or false
    flip = flip or false
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())
    end
    if palette then
        graphic:store_base_palette(palette)
        graphic:set_palette(graphic:get_base_palette())
    end
    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then 
        graphic:set_facing(facing)
    end
    
    if relative_to_user and user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

local function shuffle(t)
    local n = #t
    while n > 1 do
        -- Pick a random index j from 1 to n
        local k = math.random(n)
        -- Swap the element at index n with the element at index k
        t[n], t[k] = t[k], t[n]
        -- Decrement n to exclude the now-shuffled element
        n = n - 1
    end
    return t
end

local function create_bls_hitbox(user, facing, tile)
    if not tile or tile:is_edge() then return end
    local hitbox = Battle.Spell.new(user:get_team())
    hitbox:set_facing(facing)
    hitbox:set_hit_props(
        HitProps.new()
        :dmg(user.damage_blindrainshower)
        :impact()
        :flinch()
        :elem2(Element.Sword)
        :from(user:get_context())
    )
    if user.exe5ds_mode then -- In EXE5DS, it causes flashing.
        hitbox:set_hit_props(
            HitProps.new()
            :dmg(user.damage_blindrainshower)
            :impact()
            :flinch()
            :flash() -- <--
            :elem2(Element.Sword)
            :from(user:get_context())
        )
    end
    hitbox.update_func = function(self)
        tile:attack_entities(self)
        self:erase()
    end
    hitbox.attack_func = function(self, other)
        if not other:get_animation():has_state("HITSOUND_N") and #other:sprite():find_child_nodes_with_tags({"IS_BARRIER"}) <= 0 then
            if not other:get_animation():has_state("HITSOUND_C") and not other:get_animation():has_state("HITSOUND_O") then
    	        if Battle.Obstacle.from(other) == nil then
                    --if Battle.Player.from(user) ~= nil then
		            --	Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
		            --end
                else
		        	Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
		        end
            else
                if other:get_animation():has_state("HITSOUND_C") then
		            --if Battle.Player.from(user) ~= nil then
		            --	Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
		            --end
    	        end
    	        if other:get_animation():has_state("HITSOUND_O") then
		        	Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
		        end
            end
    	end
    end
    user:get_field():spawn(hitbox, tile)
    return hitbox
end

local function create_colonel_cape_2(user, facing)
    local cape = graphic_init("spell", 0, 0, COLONELCAPE_TEXTURE, CHARACTER_PALETTE, COLONELCAPE_ANIMPATH, -2, "1", Playback.Loop, user, facing)
    cape.update_func = function(self)
    end
    cape.battle_end_func = function(self, other)
        self:delete()
    end
    cape.delete_func = function(self, other)
        self:erase()
    end
    return cape
end

local function create_colonel_cape_1(user, facing, tile)
    local cape = graphic_init("spell", 0, 0, COLONELCAPE_TEXTURE, CHARACTER_PALETTE, COLONELCAPE_ANIMPATH, -2, "0", Playback.Loop, user, facing)
    cape:set_hit_props(
        HitProps.new()
        :dmg(0)
        :impact()
        :root(frames(120))
        :no_counter()
        :from(user:get_context())
    )
    cape.frames = 1
    cape.state = "START"
    cape.update_func = function(self)
        self:get_tile():attack_entities(self)
        if self.state == "START" then
            if self.frames == 10 then
                self.frames = 0
                self.state = "MOVE"
            end
        elseif self.state == "MOVE" then
            self:highlight_tile(Highlight.Solid)
            if not self:is_sliding() then
                local next_tile = self:get_tile(self:get_facing(),1)
                if next_tile then
                    self:slide(self:get_tile(self:get_facing(),1), frames(10), frames(0), ActionOrder.Voluntary)
                else
                    self:delete()
                end
            end
        end
        self.frames = self.frames + 1
    end
    cape.collision_func = function(self)
        self:erase()
    end
    cape.attack_func = function(self, other)
        user.colonelcape_tile = other:get_tile(self:get_facing_away(), 1)
        self:get_field():spawn(user.colonelcape2, other:get_tile())
        user.state = user.states.blind_rain_shower_2
        user.state.func(user)
        user.first_act = true
        self:set_hit_props(
            HitProps.new()
            :dmg(0)
            :impact()
            :root(frames(120))
            :no_counter()
            :from(user:get_context())
        )
    end
    cape.battle_end_func = function(self, other)
        self:delete()
    end
    cape.delete_func = function(self, other)
        user.state = user.states.blind_rain_shower_3
        user.state.func(user)
        user.first_act = true
        self:erase()
    end
    cape.can_move_to_func = function(tile)
        return true
    end
    user:get_field():spawn(cape, tile)
    return cape
end

local function create_sensha_hou_boom_spawner(user, facing, tile, tiles)
    if not tile or tile:is_edge() then return end
    local spawner = Battle.Spell.new(user:get_team())
    spawner.frames = 1
    spawner.update_func = function(self)
        for i=1,#tiles do
            if self.frames == 16+(5*(i-1)) then
                if tile and not tile:is_edge() then
                    local boom_fx = graphic_init("artifact", 0, (-16*2), BOOM_TEXTURE, BOOM_PALETTE, BOOM_ANIMPATH, -3, "0", Playback.Once, user, facing, true, true, true)
                    self:get_field():spawn(boom_fx, tiles[i])
                end
            end
            if self.frames == 16+(5*i) then
                self:erase()
            end
        end
        self.frames = self.frames + 1
    end
    user:get_field():spawn(spawner, tile)
    return spawner
end

local function create_sensha_hou_spread(user, facing, tile)
    if not tile or tile:is_edge() then return end
    local hitbox = Battle.Spell.new(user:get_team())
    hitbox:set_facing(facing)
    hitbox:set_hit_props(
        HitProps.new()
        :dmg(user.damage_colonelcannon)
        :impact()
        :flinch()
        :flash()
        :from(user:get_context())
    )
    hitbox.update_func = function(self)
        tile:attack_entities(self)
        self:erase()
    end
    hitbox.attack_func = function(self, other)
        if not other:get_animation():has_state("HITSOUND_N") and #other:sprite():find_child_nodes_with_tags({"IS_BARRIER"}) <= 0 then
            if not other:get_animation():has_state("HITSOUND_C") and not other:get_animation():has_state("HITSOUND_O") then
    	        if Battle.Obstacle.from(other) == nil then
                    --if Battle.Player.from(user) ~= nil then
		            --	Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
		            --end
                else
		        	Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
		        end
            else
                if other:get_animation():has_state("HITSOUND_C") then
		            --if Battle.Player.from(user) ~= nil then
		            --	Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
		            --end
    	        end
    	        if other:get_animation():has_state("HITSOUND_O") then
		        	Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
		        end
            end
    	end
    end
    user:get_field():spawn(hitbox, tile)
    return hitbox
end

local function create_sensha_hou_shot(user, facing, tile)
    if not tile or tile:is_edge() then return end
    local hitbox = Battle.Spell.new(user:get_team())
    hitbox:set_facing(facing)
    hitbox:set_hit_props(
        HitProps.new()
        :dmg(user.damage_colonelcannon)
        :impact()
        :flinch()
        :flash()
        :drg(Drag.new(facing, user:get_field():width()))
        :from(user:get_context())
    )
    hitbox.update_func = function(self)
        self:get_tile():attack_entities(self)
        if not self:is_sliding() then
            if self:get_tile():is_edge() then
		        Engine.play_audio(SENSHAHOU_AUDIO, AudioPriority.Low)
                self:shake_camera(20,1)
                local field = self:get_field()
                local tileWidth = tile:width()/2
                local hit_fx = graphic_init("artifact", tileWidth, 0, SENSHAHOU_SPREAD_TEXTURE, SENSHAHOU_SPREAD_PALETTE, SENSHAHOU_SPREAD_ANIMPATH, -3, "0", Playback.Once, user, facing, true, true)
                local new_tile = self:get_tile(self:get_facing_away(),1)
                field:spawn(hit_fx, new_tile)
                local tiles = {}
                for i=-1,1 do
                    local next_tile = field:tile_at(new_tile:x(), new_tile:y()+i)
                    create_sensha_hou_spread(user, facing, next_tile)
                    table.insert(tiles, next_tile)
                end
                shuffle(tiles)
                create_sensha_hou_boom_spawner(user, facing, tile, tiles)
                self:delete()
            else
                self:slide(self:get_tile(self:get_facing(),1), frames(1), frames(0), ActionOrder.Voluntary)
            end
        end
    end
    hitbox.collision_func = function(self, other)
		Engine.play_audio(SENSHAHOU_AUDIO, AudioPriority.Low)
        self:shake_camera(20,1)
        local hit_fx = graphic_init("artifact", 0, (-16*2), SENSHAHOU_BOOM_TEXTURE, SENSHAHOU_BOOM_PALETTE, SENSHAHOU_BOOM_ANIMPATH, -3, "0", Playback.Once, user, facing, true, true, true)
        self:get_field():spawn(hit_fx, other:get_tile())
        self:delete()
    end
    hitbox.attack_func = function(self, other)
        if not other:get_animation():has_state("HITSOUND_N") and #other:sprite():find_child_nodes_with_tags({"IS_BARRIER"}) <= 0 then
            if not other:get_animation():has_state("HITSOUND_C") and not other:get_animation():has_state("HITSOUND_O") then
    	        if Battle.Obstacle.from(other) == nil then
                    --if Battle.Player.from(user) ~= nil then
		            --	Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
		            --end
                else
		        	Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
		        end
            else
                if other:get_animation():has_state("HITSOUND_C") then
		            --if Battle.Player.from(user) ~= nil then
		            --	Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
		            --end
    	        end
    	        if other:get_animation():has_state("HITSOUND_O") then
		        	Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
		        end
            end
    	end
    end
    hitbox.battle_end_func = function(self, other)
        self:delete()
    end
    hitbox.delete_func = function(self, other)
        self:erase()
    end
    hitbox.can_move_to_func = function(tile)
        return true
    end
    user:get_field():spawn(hitbox, tile)
    return hitbox
end

local function create_screen_divide_hitbox(user, facing, tile)
    if not tile or tile:is_edge() then return end
    local hitbox = Battle.Spell.new(user:get_team())
    hitbox:set_facing(facing)
    hitbox:set_hit_props(
        HitProps.new()
        :dmg(user.damage_screendivide)
        :impact()
        :flinch()
        :flash()
        :no_counter()
        :elem2(Element.Sword)
        :from(user:get_context())
    )
    hitbox.update_func = function(self)
        tile:attack_entities(self)
        self:erase()
    end
    hitbox.attack_func = function(self, other)
        if Battle.Character.from(other) ~= nil then
            user.screendivide_attacked = true
        end
        if not other:get_animation():has_state("HITSOUND_N") and #other:sprite():find_child_nodes_with_tags({"IS_BARRIER"}) <= 0 then
            if not other:get_animation():has_state("HITSOUND_C") and not other:get_animation():has_state("HITSOUND_O") then
    	        if Battle.Obstacle.from(other) == nil then
                    --if Battle.Player.from(user) ~= nil then
		            --	Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
		            --end
                else
		        	Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
		        end
            else
                if other:get_animation():has_state("HITSOUND_C") then
		            --if Battle.Player.from(user) ~= nil then
		            --	Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
		            --end
    	        end
    	        if other:get_animation():has_state("HITSOUND_O") then
		        	Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
		        end
            end
    	end
    end
    user:get_field():spawn(hitbox, tile)
    return hitbox
end

local function create_screen_divide(user, type, tile)
    local slash = graphic_init("artifact", 0, 0, SCREENDIVIDE_TEXTURE, SCREENDIVIDE_PALETTE, SCREENDIVIDE_ANIMPATH, -3, type, Playback.Once, user, user:get_facing(), true, true)
    user:get_field():spawn(slash, tile)
    if type == "0" then
        create_screen_divide_hitbox(user, slash:get_facing(), tile:get_tile(Direction.join(user:get_facing_away(), Direction.Up), 1))
        create_screen_divide_hitbox(user, slash:get_facing(), tile)
        create_screen_divide_hitbox(user, slash:get_facing(), tile:get_tile(Direction.join(user:get_facing_away(), Direction.Down), 1))
    elseif type == "1" then
        create_screen_divide_hitbox(user, slash:get_facing(), tile:get_tile(Direction.join(user:get_facing_away(), Direction.Up), 1))
        create_screen_divide_hitbox(user, slash:get_facing(), tile)
        create_screen_divide_hitbox(user, slash:get_facing(), tile:get_tile(Direction.join(user:get_facing(), Direction.Down), 1))
    else
        create_screen_divide_hitbox(user, slash:get_facing(), tile:get_tile(Direction.join(user:get_facing_away(), Direction.Down),1 ))
        create_screen_divide_hitbox(user, slash:get_facing(), tile)
        create_screen_divide_hitbox(user, slash:get_facing(), tile:get_tile(Direction.join(user:get_facing(), Direction.Up), 1))
    end
end

-- Creates a hitbox for soldier's gun shot.
local function create_hitbox_gun(user, facing, tile)
    if not tile or tile:is_edge() then return end
    local hitbox = Battle.Spell.new(user:get_team())
    hitbox:set_facing(facing)
    hitbox:set_hit_props(
        HitProps.new()
        :dmg(user.damage_colonelarmy_gun)
        :impact()
        :flinch()
        :no_counter()
        :from(user:get_context())
    )
    hitbox.update_func = function(self)
        self:get_tile():attack_entities(self)
        if not self:is_sliding() then
            if not self:get_tile() or self:get_tile():is_edge() then
                self:erase()
                return
            end
            self:slide(self:get_tile(self:get_facing(),1), frames(1), frames(0), ActionOrder.Voluntary)
        end
    end
    hitbox.collision_func = function(self, other)
        self:erase()
    end
    hitbox.attack_func = function(self, other)
        if Battle.Character.from(other) ~= nil then
            --user.screendivide_attacked = true
        end
        local offset_y = math.random(-40,15)
        local offset_x = math.random(-7,6)
        local hit_fx = graphic_init("artifact", (offset_x*2), (offset_y*2), HIT_GUN_TEXTURE, HIT_GUN_PALETTE, HIT_GUN_ANIMPATH, -999, "0", Playback.Once, user, facing, true, true, true)
        user:get_field():spawn(hit_fx, other:get_tile())
        if not other:get_animation():has_state("HITSOUND_N") and #other:sprite():find_child_nodes_with_tags({"IS_BARRIER"}) <= 0 then
            if not other:get_animation():has_state("HITSOUND_C") and not other:get_animation():has_state("HITSOUND_O") then
    	        if Battle.Obstacle.from(other) == nil then
                    --if Battle.Player.from(user) ~= nil then
		            --	Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
		            --end
                else
		        	Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
		        end
            else
                if other:get_animation():has_state("HITSOUND_C") then
		            --if Battle.Player.from(user) ~= nil then
		            --	Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
		            --end
    	        end
    	        if other:get_animation():has_state("HITSOUND_O") then
		        	Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
		        end
            end
    	end
    end
    hitbox.can_move_to_func = function(tile)
        return true
    end
    user:get_field():spawn(hitbox, tile)
    return hitbox
end

-- Creates a hitbox for soldier's sword.
local function create_hitbox_sword(user, facing, tile)
    if not tile or tile:is_edge() then return end
    local hitbox = Battle.Spell.new(user:get_team())
    hitbox:set_facing(facing)
    hitbox:set_hit_props(
        HitProps.new()
        :dmg(user.damage_colonelarmy_sword)
        :impact()
        :flinch()
        :flash()
        :no_counter()
        :elem2(Element.Sword)
        :from(user:get_context())
    )
    hitbox.update_func = function(self)
        tile:attack_entities(self)
        self:erase()
    end
    hitbox.attack_func = function(self, other)
        if Battle.Character.from(other) ~= nil then
            --user.screendivide_attacked = true
        end
        if not other:get_animation():has_state("HITSOUND_N") and #other:sprite():find_child_nodes_with_tags({"IS_BARRIER"}) <= 0 then
            if not other:get_animation():has_state("HITSOUND_C") and not other:get_animation():has_state("HITSOUND_O") then
    	        if Battle.Obstacle.from(other) == nil then
                    --if Battle.Player.from(user) ~= nil then
		            --	Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
		            --end
                else
		        	Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
		        end
            else
                if other:get_animation():has_state("HITSOUND_C") then
		            --if Battle.Player.from(user) ~= nil then
		            --	Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
		            --end
    	        end
    	        if other:get_animation():has_state("HITSOUND_O") then
		        	Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
		        end
            end
    	end
    end
    user:get_field():spawn(hitbox, tile)
    return hitbox
end

local function create_colonel_army_fade(obj, state, tile)
    local fading = graphic_init("spell", obj:get_offset().x, obj:get_offset().y, COLONELARMY_TEXTURE, COLONELARMY_PALETTE, COLONELARMY_ANIMPATH, obj:sprite():get_layer(), state, Playback.Loop, obj, obj:get_facing())
    fading.frames = 0
    fading.on_spawn_func = function(self)
        self:hide()
    end
    fading.update_func = function(self)
        self.frames = self.frames + 1
        for i=1, 29, 4 do
            if self.frames == i then
                self:reveal()
            end
            if self.frames == i+2 then
                self:hide()
            end
        end
        if self.frames == 31 then
            self:erase()
        end
    end
    obj:get_field():spawn(fading, tile)
    return fading
end

-- Creates a soldier with sword/gun.
local function create_colonel_army(user, facing, type, tile)
    if type == "S" then
        facing = Direction.reverse(facing)
    end
    local soldier = graphic_init("obstacle", 0, 0, COLONELARMY_TEXTURE, COLONELARMY_PALETTE, COLONELARMY_ANIMPATH, 0, type.."_IDLE", Playback.Loop, user, facing)
    ObstacleInfo.set_cannot_be_targeted(soldier, true)
	ObstacleInfo.set_cannot_be_manipulated(soldier, true)
	ObstacleInfo.set_obstacle_damage(soldier, Element.None, 1)
    soldier:set_name("ColonelArmy"..type)
    soldier:set_team(user:get_team())
    soldier:set_health(1)
    soldier:share_tile(false)
    soldier.frames = 0
    soldier.state = type
    soldier.update_func = function(self)
        self.frames = self.frames + 1
        if type == "S" then
            if self.frames == 16-1 then
                self:get_animation():set_state("S_ATTACK")
                self:get_animation():refresh(self:sprite())
	    	    Engine.play_audio(SWORD_AUDIO, AudioPriority.Low)
            end
            if self.frames == 22-1 then
                local slash_fx = graphic_init("artifact", 0, 0, SLASH_TEXTURE, SLASH_PALETTE, SLASH_ANIMPATH, -3, "1", Playback.Once, user, facing, true, true)
                self:get_field():spawn(slash_fx, self:get_tile(self:get_facing(), 1))
                for i=1, 2 do
                    create_hitbox_sword(user, self:get_facing(), self:get_tile(self:get_facing(), i))
                end
            end
            if self.frames == 40-1 then
                self:delete()
            end
        else
            for i=16-1, 28-1, 6 do
                if self.frames == i then
                    self:get_animation():set_state("G_ATTACK")
                    self:get_animation():refresh(self:sprite())
                end
                if self.frames == i+1 then
	    	        --Engine.play_audio(GUN_AUDIO, AudioPriority.Low)
                end
                if self.frames == i+4 then
                    self:get_animation():set_state("G_IDLE")
                    self:get_animation():set_playback(Playback.Loop)
                    self:get_animation():refresh(self:sprite())
                end
            end
            for i=17-1, 37-1, 10 do
                if self.frames == i then
	    	        Engine.play_audio(GUN_AUDIO, AudioPriority.Low)
                    create_hitbox_gun(user, self:get_facing(), self:get_tile(self:get_facing(), 1))
                end
            end
            if self.frames == 37-1 then
                self:delete()
            end
        end    
    end
    soldier.delete_func = function(self)
        create_colonel_army_fade(self, type.."_IDLE", self:get_tile())
    end
    user:get_field():spawn(soldier, tile)
    return soldier
end

local function create_stone_cube(user, desired_tile)
    local facing = user:get_facing()
	local field = user:get_field()
	local team = user:get_team()
	local obs_cube = graphic_init("obstacle", 0, 0, CUBE_TEXTURE, CUBE_PALETTE, CUBE_ANIMPATH, -1, "STONE", Playback.Loop, user, facing, false, false, true)
    obs_cube.interactable = false
	obs_cube:set_team(Team.Other)
	obs_cube:set_name("StoneCube")
	ObstacleInfo.set_cannot_be_targeted(obs_cube, false)
	ObstacleInfo.set_cannot_be_manipulated(obs_cube, false)
	ObstacleInfo.add_to_limit_2(obs_cube, Team.Other, field)
	ObstacleInfo.set_obstacle_damage(obs_cube, Element.Break, user.damage_stonecube)
    local function create_piece(tile, state, end_frames, cube_o_x, cube_o_y)
		local palette = PIECES_PALETTE_STONE
		local piece = graphic_init("artifact", 0, 0, PIECES_TEXTURE, palette, PIECES_ANIMPATH, -3, state, Playback.Once, user, facing, false, false, true)
		piece.frames = 0
		piece.x_change = 0
		piece.y_change = 0
		piece.y_change1 = math.random(-9,-3)
		piece.y_change2 = math.floor(piece.y_change1/2)
		piece.y_change3 = math.floor(piece.y_change2/2)
		piece.update_func = function(self)
			self.frames = self.frames + 1
			if self.frames == 1 then
				self.x_change = math.random(-5,5)
				self.y_change = self.y_change1
			elseif self.frames == 4 then
				self.y_change = self.y_change2
			elseif self.frames == 7 then
				self.y_change = self.y_change3
			elseif self.frames == 10 then
				self.y_change = 0
			elseif self.frames == 13 then
				self.y_change = -self.y_change3
			elseif self.frames == 16 then
				self.y_change = -self.y_change2
			elseif self.frames == 19 then
				self.y_change = -self.y_change1
			elseif self.frames >= end_frames then
				self:delete()
			end
			self:set_offset(self:get_offset().x+(self.x_change*2),self:get_offset().y+(self.y_change*2))
		end
		piece.delete_func = function(self)
			local smoke_fx = graphic_init("artifact", self:get_offset().x+self:get_tile_offset().x, self:get_offset().y+self:get_tile_offset().y, SMOKE_TEXTURE, SMOKE_PALETTE, SMOKE_ANIMPATH, -3, "0", Playback.Once, user, facing, true, false, true)
			field:spawn(smoke_fx, self:get_tile())
		end
		field:spawn(piece, tile)
		return piece
	end
	local obs_hitbox = nil
	local function create_hitbox(spawn_tile)
		local hitbox = Battle.Spell.new(obs_cube:get_team())
		hitbox:set_facing(facing)
		hitbox:set_hit_props(
			HitProps.new()
			:dmg(ObstacleInfo.get_obstacle_damage_number(obs_cube))
			:impact()
			:flinch()
			:flash()
			:no_counter()
			:elem2(Element.Break)
			:from(user:get_context())
		)
		local hit_query = function(ent)
			return (Battle.Character.from(ent) ~= nil or Battle.Player.from(ent) ~= nil or Battle.Obstacle.from(ent) ~= nil) and ent:get_health() > 0 and not ent:is_team(hitbox:get_team()) and ent:get_id() ~= obs_cube:get_id()
		end
		hitbox.update_func = function(self)
			if obs_cube == nil or obs_cube:is_deleted() then
				self:delete()
			else
				if self:get_tile() ~= obs_cube:get_tile() then
					self:teleport(obs_cube:get_tile(), ActionOrder.Immediate)
				end
                if #self:get_tile():find_entities(hit_query) > 0 then
			    	self:get_tile():attack_entities(self)
			    end
			end
		end
		hitbox.attack_func = function(self, other)
            if Battle.Character.from(other) ~= nil then
                --user.screendivide_attacked = true
            end
			debug_print("attacked tile ("..other:get_tile():x()..";"..other:get_tile():y()..")")
			local offset_y = math.random(-7,5)
			local offset_x = math.random(-7,6)
			if facing == Direction.Left then offset_x = -offset_x end
			local hit_fx = graphic_init("artifact", self:get_tile_offset().x+self:get_offset().x+(offset_x*2), self:get_tile_offset().y+self:get_offset().y+(offset_y*2), EFFECT_TEXTURE, EFFECT_PALETTE, EFFECT_ANIMPATH, -999, "0", Playback.Once, user, facing, true, false, true)
			field:spawn(hit_fx, other:get_tile())
			if not other:get_animation():has_state("HITSOUND_N") and #other:sprite():find_child_nodes_with_tags({"IS_BARRIER"}) <= 0 then
                if not other:get_animation():has_state("HITSOUND_C") and not other:get_animation():has_state("HITSOUND_O") then
    	            if Battle.Obstacle.from(other) == nil then
                        --if Battle.Player.from(user) ~= nil then
		                --	Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
		                --end
                    else
		            	Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
		            end
                else
                    if other:get_animation():has_state("HITSOUND_C") then
		                --if Battle.Player.from(user) ~= nil then
		                --	Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
		                --end
    	            end
    	            if other:get_animation():has_state("HITSOUND_O") then
		            	Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
		            end
                end
    	    end
		end
		hitbox.collision_func = function(self, other)
			if obs_cube == nil or obs_cube:is_deleted() then
			else
				if other:get_id() ~= obs_cube:get_id() then
					obs_cube:set_health(0)
				end
			end
		end
		hitbox.battle_end_func = function(self, other)
			self:delete()
		end
		hitbox.can_move_to_func = function(tile)
			return true
		end
		field:spawn(hitbox, spawn_tile)
		return hitbox
	end
	obs_cube:set_shadow(SHADOW_TEXTURE_1)
	obs_cube:show_shadow(true)
	obs_cube:set_health(200)
	local countdown = 6000
	local continue_slide = false -- slide tracker
	local prev_tile = {}
	local cube_speed = 4
	local cube_defense_rule = Battle.DefenseRule.new(0, DefenseOrder.Always)
	cube_defense_rule.filter_statuses_func = function(hit_props)
		if (hit_props.flags & Hit.Impact == Hit.Impact) and (hit_props.flags & Hit.Drag == Hit.Drag) then
			hit_props.damage = 0
			continue_slide = true
		end
		return hit_props
	end
	cube_defense_rule.can_block_func = function(judge, attacker, defender)
		local hit_props = attacker:copy_hit_props()
		if obs_hitbox ~= nil and not obs_hitbox:is_deleted() and attacker:get_id() == obs_hitbox:get_id() then
			judge:block_damage()
			judge:block_impact()
		else
			if hit_props.damage == 0 then
				judge:block_damage()
				judge:block_impact()
			else
				if hit_props.damage < 0 then
					obs_cube:set_health(obs_cube:get_health())
				end
				if hit_props.flags & Hit.Breaking == Hit.Breaking or hit_props.element == Element.Break or hit_props.element2 == Element.Break then
					obs_cube:set_health(0)
				end
			end
		end
	end
	obs_cube:add_defense_rule(cube_defense_rule)
	obs_cube.can_move_to_func = function(tile)
		if tile then
			local field = obs_cube:get_field()
			local cube_team = obs_cube:get_team()
			local other_obstacles = function(o)
				return o:get_team() == cube_team and not o:get_animation():has_state("PASS_THROUGH") and o:get_name() ~= "CANTINTERACT" 
			end
			local obstacles_here = field:find_obstacles(other_obstacles)
			local donotmove = false
			-- look through the list of obstacles and read their tile position, check if we're trying to move to their tile.
			for ii=1,#obstacles_here do
				if tile == obstacles_here[ii]:get_tile() then
					donotmove = true
				end
			end
			if tile:is_edge() or donotmove or not tile:is_walkable() then
				return false
			end
		end
		return true
	end
	obs_cube.update_func = function(self)
		local tile = obs_cube:get_tile()
		if not tile then
			obs_cube.delete_func()
		end
		if tile:is_edge() then
			obs_cube.delete_func()
		end
		local direction = self:get_facing()
		if self:is_sliding() then
			table.insert(prev_tile,1, tile)
			prev_tile[cube_speed+1] = nil
			local target_tile = tile:get_tile(direction, 1)
			if self.can_move_to_func(target_tile) then
				continue_slide = true
			else
				continue_slide = false
			end
		else
			-- become aware of which direction you just moved in, turn to face that direction
			if prev_tile[cube_speed] then
				if prev_tile[cube_speed]:get_tile(direction, 1):x() ~= tile:x() then
					direction = self:get_facing_away()
					self:set_facing(direction)
				end
			end
		end
		if not self:is_sliding() and continue_slide then
			self:slide(self:get_tile(direction, 1), frames(cube_speed), frames(0), ActionOrder.Voluntary, function() end)
		end
		if countdown > 0 then
            countdown = countdown - 1
        else
            if self:get_elevation() == 0 then obs_cube:set_health(0) end
        end
	end
	obs_cube.battle_end_func = function(self, other)
		self:set_health(0)
	end
	obs_cube.delete_func = function(self)
		if self:get_health() <= 0 then
			Engine.play_audio(CRACK_AUDIO, AudioPriority.Low)
			local smoke_fx = graphic_init("artifact", self:get_offset().x+self:get_tile_offset().x, self:get_offset().y+(-16*2)+self:get_tile_offset().y, SMOKE_TEXTURE, SMOKE_PALETTE, SMOKE_ANIMPATH, -3, "1", Playback.Once, user, facing, true, false, true)
			field:spawn(smoke_fx, self:get_tile())
			create_piece(self:get_tile(), tostring(math.random(0,1)), math.random(21,27), self:get_offset().x+self:get_tile_offset().x, self:get_offset().y+self:get_tile_offset().y)
			create_piece(self:get_tile(), tostring(math.random(0,1)), math.random(21,27), self:get_offset().x+self:get_tile_offset().x, self:get_offset().y+self:get_tile_offset().y)
		end
	end
    local highlighter = graphic_init("artifact", 0, 0, CUBE_TEXTURE, CUBE_PALETTE, CUBE_ANIMPATH, -1, "STONE", Playback.Loop, user, facing, false, false, true)
    highlighter:set_name("CANTINTERACT")
    highlighter:set_team(Team.Other)
	highlighter:set_shadow(SHADOW_TEXTURE_1)
	highlighter:show_shadow(true)
    highlighter.frames = 1
    highlighter.elevation = 3*2+8*2*48
    local query = function(ent)
		if ent:get_id() == obs_cube:get_id() or ent:get_animation():has_state("PASS_THROUGH") or ent:get_name() == "CANTINTERACT" then return false end
		return ent:get_health() > 0
	end
    highlighter.update_func = function(self)
        self:get_tile():highlight(Highlight.Solid)
        self.elevation = self.elevation - (8*2)
        if self.elevation > 0 then
            self:set_elevation(self.elevation)
        else
	        field:spawn(obs_cube, desired_tile)
			obs_hitbox = create_hitbox(desired_tile)
            local tile = desired_tile
		    local chars = {}
		    local obs = {}
		    field:find_entities(function(e)
		      	local id = e:get_id()
		      	if Battle.Obstacle.from(e) then 
		      	  	table.insert(obs, id)
		      	elseif Battle.Character.from(e) then
		      	  	table.insert(chars, id)
		      	end
		    end)
		    local ignore_list = obs
		    -- https://paintylux.github.io/OpenNetBattleDocs/api/#tile-is_reserved
		    local not_reserved_by_ob = tile:is_reserved(obs)
		    --print(tile:is_walkable())
		    --print(tile:is_reserved(chars))
		    --print(tile:is_reserved(obs))
		    --print(#tile:find_entities(query))
            if not tile:is_hole() and #tile:find_obstacles(query) <= 0 and ((tile:is_reserved(chars) and tile:is_reserved(obs)) or (tile:is_reserved(chars) and not tile:is_reserved(obs)) or (not tile:is_reserved(chars) and not tile:is_reserved(obs))) then
                self:set_elevation(0)
                self:shake_camera(20, 0.2)
		        Engine.play_audio(STOMP_AUDIO, AudioPriority.Low)
            else
                obs_cube:set_health(0)
            end
            self:erase()
        end
        self.frames = self.frames + 1
    end
    field:spawn(highlighter, desired_tile)
end

function package_init(self)
    CHARACTER_TEXTURE = Engine.load_texture(_folderpath.."gfx/battle.grayscaled.png")
    CHARACTER_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/battle-NORMAL.png")

    self.exe5ds_mode = false -- Turns on/off EXE5DS mode. If ON, Blind Rain Shower always causes Flashing.

    self.next_tile = nil -- The character's next tile to move.
    self.prev_tile = nil -- The character's previous tile before moving.
    
    self.do_once_at_start = true -- Does some things once when the battle actually starts.
    self.move_count = 0 -- Counts how many times the pattern was reconstructed.
    self.colonelcape1 = nil -- Stored Colonel's cape.
    self.colonelcape2 = nil -- Stored Colonel's cape.
    self.colonelcape_tile = nil

    -- Alrysc:
    -- Chance /16. I'm going to run these when the pattern is complete and when the flinch finishes, respectively
        -- These skips will be very implementation-specific, so don't use them as future references
    self.chance_to_skip_idle_after_flinch = 2
    self.chance_to_halve_idle_after_flinch = 3

    self.base_idle_speed2 = 0 -- Stores the Character's actual idle delay. Can't be changed.

    self:set_name("Colonel") -- Sets name.
    self.damage = 40 -- Damage for the Character's collision hitbox.
    self.damage_screendivide = 20 -- Damage for Screen Divide's hitbox.
    self.damage_colonelcannon = 20 -- Damage for Colonel Cannon's hitbox.
    self.damage_blindrainshower = 0 -- Damage for Blind Rain Shower's hitbox.
    self.damage_stonecube = 0 -- Damage for Stone Cube's hitbox.
    self.damage_colonelarmy_gun = 5 -- Damage for Colonel Army's gun hitbox.
    self.damage_colonelarmy_sword = 40 -- Damage for Colonel Army's sword hitbox.
    self.screendivide_delay_base2 = 14 -- Sets Screen Divide's actual base delay (+9 frames).
    self.screendivide_times = 1 -- Determines how many times in a row Screen Divide can be used.
    self.stonecubes = 0 -- Determines how many Stone Cubes Colonel can drop on enemy tiles.
    self.base_idle_speed2 = 56-4 -- Sets the actual idle delay.
    self.ds_level = math.random(1,10) -- Sets DSLV 1~10.
	local rank = self:get_rank()
    if rank == Rank.V2 then -- If the rank is V2 (Dark ver.).
        CHARACTER_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/battle-DARK2.png") -- Uses alternative palette for Dark ver..
        self:set_health(1200)
        self.damage = 50
        self.damage_screendivide = 120
        self.damage_colonelcannon = 160
        self.damage_blindrainshower = 50
        self.damage_stonecube = 60
        self.damage_colonelarmy_gun = 30
        self.damage_colonelarmy_sword = 90
        self.screendivide_delay_base2 = 11
        self.screendivide_times = 2
        self.stonecubes = 1
        self.base_idle_speed2 = 46-4
    elseif rank == Rank.V3 then -- If the rank is V3.
        self:set_name("ColonelV")
        self:set_health(1800)
        self.damage = 100
        self.damage_screendivide = 140
        self.damage_colonelcannon = 180
        self.damage_blindrainshower = 60
        self.damage_stonecube = 90
        self.damage_colonelarmy_gun = 40
        self.damage_colonelarmy_sword = 120
        self.screendivide_delay_base2 = 8
        self.screendivide_times = 3
        self.stonecubes = 2
        self.base_idle_speed2 = 41-4
    elseif rank == Rank.SP then -- If the rank is SP.
        self:set_health(2000)
        self.damage = 200
        self.damage_screendivide = 200
        self.damage_colonelcannon = 240
        self.damage_blindrainshower = 75
        self.damage_stonecube = 150
        self.damage_colonelarmy_gun = 50
        self.damage_colonelarmy_sword = 150
        self.screendivide_delay_base2 = 5
        self.screendivide_times = 3
        self.stonecubes = 2
        self.base_idle_speed2 = 36-4
    elseif rank == Rank.NM then -- If the rank is NM.
        CHARACTER_PALETTE = Engine.load_texture(_folderpath.."gfx/palette/battle-DARK.png") -- Uses alternative palette for DS.
        self:set_health(600+(self.ds_level*100))
        self.damage = 200
        self.damage_screendivide = self.ds_level*20
        self.damage_colonelcannon = self.ds_level*25
        self.damage_blindrainshower = self.ds_level*7
        self.damage_stonecube = self.ds_level*10
        self.damage_colonelarmy_gun = self.ds_level*5
        self.damage_colonelarmy_sword = self.ds_level*15
        self.screendivide_delay_base2 = 8
        self.screendivide_times = 3
        if self.ds_level <= 6 then -- DSLV 1~6
            self.stonecubes = 1
        else                       -- DSLV 7~10
            self.stonecubes = 2
        end
        self.base_idle_speed2 = 41-4
    else -- If the rank is V1 or any other rank.
        self:set_health(400) -- Sets max health.
    end
    self.screendivide_delay_base = self.screendivide_delay_base2 -- Sets Screen Divide's base delay (+3 frames). Changes when if Colonel is Confused or Blind.
    self.screendivide_delay = self.screendivide_delay_base -- Sets Screen Divide's delay (+3 frames). Changes if it's not the first Screen Divide.
    self.screendivide_count = self.screendivide_times -- Counts how many times Screen Divide was used in a row.
    self.screendivide_attacked = false -- Determines if Screen Divide has attacked successfully. If true, he doesn't use the attack more than 1.

    self.base_idle_speed = self.base_idle_speed2 -- Stores the Character's default idle delay. Changes when the Character is Confused or Blind.
    self.idle_speed = 0 -- The Character's current idle delay.

    self:set_texture(CHARACTER_TEXTURE, true) -- Sets the Character's texture.
    self:store_base_palette(CHARACTER_PALETTE) -- Stores the Character's base palette.
    self:set_palette(self:get_base_palette()) -- Sets the Character's base palette as the current one.

    self:set_height(68) -- Sets Colonel's height.
    self:set_explosion_behavior(5, 1, true) -- Creates 5 explosions when the Character gets deleted.
    self:set_offset(0,0) -- Sets offset.
	self:set_facing(Direction.Left)
	self:set_element(Element.None) -- Colonel is a non-elemental Character.
	self:set_float_shoe(false) -- Colonel doesn't have Float Shoes.
	self:set_air_shoe(false) -- Colonel doesn't have Air Shoes.
    self:share_tile(false) -- Colonel doesn't share his current tile.

    -- The Character's animation handled by enemy_base_v1.
    local anim = self:get_animation()
    anim:load(CHARACTER_ANIMPATH)
    self.anim = include("enemy_base_v1/entry.lua")
    anim = self.anim
    anim:set_owner(self)
    anim:set_state("IDLE", { -- Sets the Spawn animation.
        {duration=2, state="IDLE_1"},
    })
    anim:set_playback(Playback.Loop) -- Loops the animation.
    init_boss(self)
end

--(Function by Alrysc)
-- This is to fix something that happens because I'm a cheater.
--[[
    The aggressor of an attack is held in the Context object. 
    ONB leaves this aggressor unset in the Entity's Context until a CardAction is used for the first time.
    So I'll immediately force a CardAction that will hopefully end immediately and not get in the way, but also will fix this.
    This probably goes horribly wrong if the enemy is spawned after the mob intro, but should be fine for now otherwise.
]]
function fix_context(self)
    local action = Battle.CardAction.new(self, "IDLE_1")
    action.execute_func = function()
        action:end_action()
    end
    self:card_action_event(action, ActionOrder.Immediate)
end

--(Function by Alrysc)
function init_boss(self)
    self.on_spawn_func = function(self)
        fix_context(self)
        --[[
        self.before_battle_start_animater = Battle.Artifact.new()
        self:get_field():spawn(self.before_battle_start_animater, 7, 4)
        self.before_battle_start_animater.update_func = function()
            self.anim:tick_animation()
        end]]
        if self:get_rank() == Rank.V2 then
            self:set_name("DarkColnl")
        elseif self:get_rank() == Rank.NM then
            self:set_name("ColonelDS")
        end
    end

    -- The Character's battle start function. Called once when the BATTLE START text appears.
    self.battle_start_func = function(self)
        --self.before_battle_start_animater:delete()
    end

    -- Alrysc: Setting names here is just convenience if I want to print the state I'm in later.
    self.states = {
        idle = {name = "idle", func = idle},
        move = {name = "move", func = move},
        move_to_enemy = {name = "move_to_enemy", func = move_to_enemy},
        move_before_brs = {name = "move_before_brs", func = move_before_brs},
        flinch = {name = "flinch", func = flinch},
        
        start_sub_pattern = {name = "start_sub_pattern"},
        finish_sub_pattern = {name = "finish_sub_pattern"},

        screen_divide = {name = "screen_divide", func = screen_divide},
        colonel_cannon = {name = "colonel_cannon", func = colonel_cannon},
        colonel_army = {name = "colonel_army", func = colonel_army},
        blind_rain_shower_1 = {name = "blind_rain_shower_1", func = blind_rain_shower_1},
        blind_rain_shower_2 = {name = "blind_rain_shower_2", func = blind_rain_shower_2},
        blind_rain_shower_3 = {name = "blind_rain_shower_3", func = blind_rain_shower_3},

        choose_attack = {name = "choose_attack", func = choose_attack}
    }
    
    local s = self.states

    reconstruct_pattern(self)
 
    self.pattern_index = 1
    self.in_sub_pattern = false

    self.first_act = true

    self.state_done = false

    self.state = self.pattern[1]

    self.first_flinch = true

    -- The Character's hit function. Called when the character's gets hit.
    self.hit_func = function(from_stun)
        debug_print("Hit func runs")
        self.counterable_component.timer = 0
        self:toggle_counter(false)
        self.flinching = false
        self.first_act = false
        self.state_done = false
        --self.screendivide_attacked = false
        self.moving_to_enemy_tile = false
        self.can_move_to_edge = false
        self.collision_available = true
        self:share_tile(false)
        self:set_offset(0,0)
        if self.first_flinch then 
            --self.state.cleanup
            self.last_state = self.state
            debug_print("Hit! Set last state to ", self.state.name)
            if self.state ~= self.states.idle and self.state ~= self.states.move then 
               --increment_pattern(self)
            end
            self.first_flinch = false
        end
        self.state = self.states.flinch
        -- This is unused for this boss.
        --[[
        if self.slide_component ~= nil then 
            debug_print("Hit while moving.")
            self.slide_component:eject()
            self.slide_component = nil
            self:set_offset(0,0)
            if self.slide_dest and self:get_tile() ~= self.slide_dest then 
                debug_print("Hit before reaching destination.")
                self:get_tile():remove_entity_by_id(self:get_id())
                self.slide_dest:add_entity(self)
                self.slide_dest = nil
            end
        end]]
        flinch(self, from_stun)
    end

    -- The Character's delete function. Called when the character's gets deleted.
    self.delete_func = function(self)
        self.update_func = function(self) -- The Character's delete function's update function. Called every frame the character updates.
            self:get_animation():set_state("FLINCH_1")  -- Sets the Stunned animation.
            self.state = self.states.flinch -- Sets the Flinch state.
            self.colonelarmy_generator:eject() -- Ejects the Colonel Army generator.
        end
    end

    -- Unused for this boss.
    self.moving_to_enemy_tile = false
    self.counter = 0
    self.collision_available = true
    self.counterable = 0
    self.can_move_to_edge = false
    self.do_once_1 = true

    -- The Counter Hit state component. Makes the Character counter-able if the Counter Hit counter is more than 0.
    local ref = self
    self.counterable_component = Battle.Component.new(self, Lifetimes.Battlestep)
    self.counterable_component.timer = 0
    self.counterable_component.update_func = function(self)
        if self.timer > 0 then
            debug_print("COUNTERABLE")
            self.timer = self.timer - 1
            ref:toggle_counter(true)
        else
            ref:toggle_counter(false)
        end
    end
    self:register_component(self.counterable_component)

    self:register_status_callback(Hit.Stun, function() self.hit_func(true) end)
    self:register_status_callback(Hit.Freeze, function() self.hit_func(true) end)
    self:register_status_callback(Hit.Flinch, self.hit_func)
    --self:register_status_callback(Hit.Drag, self.hit_func)

    -- Alrysc: Bring it back next build. For now, relying on the stun callback.
    self.on_countered = function(self)
        debug_print("Countered")
        --self.counterable_component.timer = 0
        --self:toggle_counter(false)
        self.hit_func(true)
    end

    local status_defense = Battle.DefenseRule.new(10, DefenseOrder.Always)
    status_defense.filter_statuses_func = function(hit_props)
        if self.state == self.states.blind_rain_shower_1 or self.state == self.states.blind_rain_shower_2 or self.state == self.states.blind_rain_shower_3 then
            hit_props.flags = hit_props.flags & (~Hit.Drag)
        end
        return hit_props
    end
    self:add_defense_rule(status_defense)

    -- The checking query for Heat Chasers.
    local ca_query = function(o)
        return o:get_name() == "ColonelArmyG" or o:get_name() == "ColonelArmyS"
    end
    self.can_move_to_func = function(tile)
        -- Can't be rooted during Blind Rain Shower.
        if self:is_rooted()
        and self.state ~= self.states.blind_rain_shower_1 and self.state ~= self.states.blind_rain_shower_2 and self.state ~= self.states.blind_rain_shower_3
        then return false end
        -- Can move to not walkable tiles only when allowed.
        if (tile:is_edge() or not tile:is_walkable()) then
            if self.can_move_to_edge then
                return true
            else
                return false
            end
        end
        -- Can't move to tiles reserved not by the Reserving Obstacle.
        if(tile:is_reserved({self:get_id()})) then
            return false
        end
        -- Can move to enemy tiles only when allowed to do so.
        if not self.moving_to_enemy_tile and (tile:get_team() ~= self:get_team()) then
            return false
        end
        -- Can move to the Character's current tile.
        if tile == self:get_tile() then
            return true
        end
        -- Can pass through Colonel Army soldier.
        if #tile:find_obstacles(ca_query) > 0 then
            return true
        end
        -- Can pass through Characters and Obstacles if can move on edge.
        if self.can_move_to_edge and (check_obstacles(tile, self) or check_characters_true(tile, self)) then
            return true
        end
        return not check_obstacles(tile, self) and not check_characters_true(tile, self)
    end

    self.do_once_confuse_blind = true
    self.do_once_obs = true
    -- The Character's update function. Called every frame the character updates.
    self.update_func = function(self)
        debug_print("     ", self.state.name, self:get_animation():get_state())
        -- Increases the Character's idle delay when Confused or Blinded.
        if self:is_confused() or self:is_blind() then
            if self.do_once_confuse_blind then
                self.do_once_confuse_blind = false
                self.screendivide_delay_base = self.screendivide_delay_base2+30 -- Increases the first Screen Divide's delay for Colonel.
                --self.base_idle_speed = self.base_idle_speed2+30 -- Unused for Colonel.
            end
        else
            if not self.do_once_confuse_blind then
                self.do_once_confuse_blind = true
                --self.base_idle_speed = self.base_idle_speed2
            end
        end
        self.state.func(self)
        self.anim:tick_animation()
        --Alrysc: 
        -- When we tick animation, we may run increment_pattern. 
        -- The new state isn't run until next frame, so our anim state lasts one more frame when it finishes
        -- Calling our state one time to set things up will avoid this. Mostly sure this doesn't have major unintended consequences,
        -- especially as most state.func only set state and callbacks for frame 1
        -- Problem is, now I may have a frame 1 callback but I don't run it until next frame
        while self.first_act do
            self.state.func(self)
            self.anim:tick_animation()
        end
        check_collision(self)
    end
end

--(Function by Alrysc, edited by K1rbYat1Na)
function create_collision_attack(user, tile)
    local spell = Battle.Spell.new(user:get_team())
    local hit_props = HitProps.new()
    :dmg(user.damage)
    :impact()
    :flinch()
    :flash()
    :from(user:get_context())
    :elem(user:get_element())
    spell:set_hit_props(hit_props)
    spell.update_func = function(self)
        tile:attack_entities(self)
        self:delete()
    end
    spell.attack_func = function(self, other)
        if not other:get_animation():has_state("HITSOUND_N") and #other:sprite():find_child_nodes_with_tags({"IS_BARRIER"}) <= 0 then
            if not other:get_animation():has_state("HITSOUND_C") and not other:get_animation():has_state("HITSOUND_O") then
    	        if Battle.Obstacle.from(other) == nil then
                    --if Battle.Player.from(user) ~= nil then
		            --	Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
		            --end
                else
		        	Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
		        end
            else
                if other:get_animation():has_state("HITSOUND_C") then
		            --if Battle.Player.from(user) ~= nil then
		            --	Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
		            --end
    	        end
    	        if other:get_animation():has_state("HITSOUND_O") then
		        	Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
		        end
            end
    	end
    end
    user:get_field():spawn(spell, tile)
end

--(Function by Alrysc)
-- TODO: When we get is_passthrough or something, check to see if target became flashing before 
    -- we are allowed to spawn another one. Don't want to instakill viruses
-- self.collision_available can do something related to that. Does nothing now
function check_collision(self)
    local t = self:get_tile()
    if self.collision_available and check_characters(t, self) then 
        create_collision_attack(self, t)
    end
end

--(Function by Alrysc, edited by K1rbYat1Na)
function idle(self)
    -- Does once.
    if self.do_once_at_start then
        self.do_once_at_start = false
        -- Turns any manipulatable Obstacle into Colonel Army.
        self.colonelarmy_generator = Battle.Component.new(self, Lifetimes.Battlestep)
        self.colonelarmy_generator.update_func = function(cg)
            local enemy_tiles = self:get_field():find_tiles(function(t) -- Finds every enemy tile.
                return not t:is_edge() and t:get_team() ~= self:get_team()
            end)
            if #enemy_tiles > 0 then
                for i=1, #enemy_tiles do
                    local manip_obs = enemy_tiles[i]:find_obstacles(function(o) -- Finds every manipulatable Obstacle in enemy tiles.
                        if o:get_name() == "CANTINTERACT" then
                            return false
                        end
                        return ObstacleInfo.can_be_manipulated(o)
                    end)
                    if #manip_obs <= 0 then
                        self.do_once_obs = true
                    else
                        if self.do_once_obs then
                            self.do_once_obs = false
                            local type = "N"
                            for j=1, self:get_field():width() do
                                local next_tile = manip_obs[1]:get_tile(self:get_facing(), j)
                                if next_tile and check_characters(next_tile, self) then
                                    type = "G"  -- The soldier will be a gunner.
                                end
                            end
                            if type == "N" then
                                for j=1, 2 do
                                    local next_tile = manip_obs[1]:get_tile(self:get_facing_away(), j)
                                    if next_tile and check_characters(next_tile, self) then
                                        type = "S" -- The soldier will be a swordsman.
                                    end
                                end
                            end
                            if type ~= "N" then
                                create_colonel_army(self, self:get_facing(), type, manip_obs[1]:get_tile())
                                for j=1, #manip_obs do
                                    manip_obs[j]:set_health(0)
                                end
                            end
                        end
                    end
                end
            end
        end
        self:register_component(self.colonelarmy_generator)
    end
    if self.first_act then
        self.first_act = false
        if self:is_rooted() then
            self.idle_speed = self.base_idle_speed
            increment_pattern(self)
            return
        end
        -- This is an old check for when I extended idle time by doing two idle states in a row, when characters have an animated idle
            -- Not needed if I instead use a timer
        if self.anim:get_state() ~= "IDLE" then 
            debug_print("Idle with ", self.idle_speed)
            self.anim:set_state("IDLE", {
                {duration=2, state="IDLE_1"},
            })    
        end
        self.anim:set_playback(Playback.Loop)
        self.counter = 0
    end
    self.counter = self.counter + 1
    if self.counter > self.idle_speed then
        -- Extra catch for after leaving attack. Attack will double idle speed once, so making sure to reset it after
        if self.idle_speed > self.base_idle_speed then 
            self.idle_speed = self.base_idle_speed
        end
        increment_pattern(self)
    end
    --self.looped = false
    --if self.state_done then 
        --debug_print("State done")
    --end
end

--(Function by Alrysc)
function hit()
    --???
end

--(Function by Alrysc)
function end_sub_pattern(self)
    while self.in_sub_pattern do
        increment_pattern(self)
    end
end

--(Function by Alrysc)
function flinch(self, from_stun)
    debug_print("Flinch played")
    if self.colonelcape1 ~= nil and not self.colonelcape1:is_deleted() then self.colonelcape1:erase() end
    if self.colonelcape2 ~= nil and not self.colonelcape2:is_deleted() then self.colonelcape2:erase() end
    if not self.original_tile then
        if self:get_tile() == self.next_tile then
            local orig_tile = self.next_tile
            self.next_tile:remove_entity_by_id(self:get_id())
            self.next_tile = orig_tile
            self.next_tile:add_entity(self)
            self.next_tile = nil
        elseif self:get_tile() == self.prev_tile then
            local orig_tile = self.prev_tile
            self.prev_tile:remove_entity_by_id(self:get_id())
            self.prev_tile = orig_tile
            self.prev_tile:add_entity(self)
            self.prev_tile = nil
        elseif self:get_tile() ~= self.next_tile then
            if self.next_tile ~= nil then
                self.next_tile:remove_entity_by_id(self:get_id())
                self.next_tile = nil
            end
        end
    else
        self:teleport(self.original_tile, ActionOrder.Immediate)
        self:get_tile():remove_entity_by_id(self:get_id())
        self.original_tile:add_entity(self)
        self.original_tile = nil
    end
    --print("I am flinching")
    if not self.flinching then 
        local frames = {}
        if not from_stun then
            frames[1] = {duration=4, state="FLINCH_1"}
            frames[2] = {duration=2, state="FLINCH_2"}
            frames[3] = {duration=2, state="FLINCH_3"}
            frames[4] = {duration=2, state="FLINCH_2"}
            frames[5] = {duration=2, state="FLINCH_1"}
            frames[6] = {duration=4, state="FLINCH_3"}
            frames[7] = {duration=3, state="FLINCH_4"}
            frames[8] = {duration=3, state="FLINCH_4"}
            frames[9] = {duration=2, state="IDLE_1"}
        else
            frames[1] = {duration=2, state="FLINCH_1"}
        end
        self.anim:set_state("FLINCH", frames)
        self.anim:on_complete(function()
            -- If we didn't just attack, we want to make sure the idle speed is correct. This is also set in the actual idle, but just for extra measure.
                -- Shouldn't be necessary
            if self.idle_speed > self.base_idle_speed --[[and self.pattern[self.pattern_index] ~= self.states.choose_attack]] then 
                self.idle_speed = self.base_idle_speed
            end
            local has_skipped = false
            if self.last_state == self.states.idle then 
                debug_print("Attempt skip, because last state was idle")
                has_skipped = maybe_skip_after_flinch(self)
            end
            debug_print("I am done flinching")
            debug_print("Anim done")
            self.flinching = false
            self.state_done = true
            self.first_flinch = true
            debug_print("Done")
            self.state_done = false
            if self.last_state ~= self.states.idle and self.last_state ~= self.states.move then 
            debug_print("Last state was not idle or move", self.last_state.name)
                increment_pattern(self)
            else
                --if not has_skipped then 
                -- If we were in idle or move, go back to it and try again
                    -- Unless we were in a sub pattern. Still end that.
                debug_print("Last state was idle or move")
                if self.in_sub_pattern then 
                    end_sub_pattern(self)
                else
                    self.state = self.last_state
                    self.first_act = true
                end
            end
        end)
    end
    self.flinching = true
end

--(Function by Alrysc)
--[[
    Chance to skip idle or halve idle time, to call after flinching 
    This works by calling increment_pattern an extra time if and only if the last state was Idle
        Remember, last state is the state we will return to after flinching
        Some extra work will need to be done in the self.anim:on_complete of flinch if this is to work with sub patterns. This boss doesn't use them, so it was omitted
    
    Currently, the skip is implemented as setting idle time to 0
    
    A future choice for this function: after calling this function, self.state *may* increment, obsoleting our last state pointer. Returns true if this does happen
        There is a possible additional side effect that the idle time will instead be changed, in which case, last state is preserved and false is returned
]]
function maybe_skip_after_flinch(self)
    local chance_halve = self.chance_to_halve_idle_after_flinch
    local chance_skip = self.chance_to_skip_idle_after_flinch
    local max = chance_halve + chance_skip + (16 - chance_halve - chance_skip)

    local r = math.random(1, max)
    if r <= chance_halve then 
        self.idle_speed = math.floor(self.idle_speed / 2)
        debug_print("We halved")
    elseif r <= (chance_skip + chance_halve) then 
        debug_print("We skipped")
        self.idle_speed = 0
        return true
    end
    return false
end

--(Function by Alrysc, edited by K1rbYat1Na)
function highlight_tiles(self, list, type, time)
    local spell = Battle.Spell.new(self:get_team())
    local ref = self
    spell.update_func = function(self)
        for i=1, #list do 
            local t = list[i]
            if t and not t:is_edge() then 
                t:highlight(type)
            end
        end
        time = time - 1
        if time == 0 then 
            self:delete()
        end
        if self.flinching then 
            if spell and not spell:is_deleted() then 
                spell:delete()
            end
        end
    end
    self:get_field():spawn(spell, self:get_tile())
    return spell
end

-- Moving.
function move(self)
    if self.first_act then
        self.first_act = false
        if self:is_rooted() then
            self.idle_speed = self.base_idle_speed
            increment_pattern(self)
        else
            self.anim:set_state("MOVE", {
                {duration=2, state="IDLE_1"},
                {duration=1, state="WARP_1"},
                {duration=1, state="WARP_2"},
                {duration=1, state="WARP_2"},
                {duration=1, state="WARP_1"},
                {duration=2, state="IDLE_1"},
            })
            self.prev_tile = self:get_tile()
            local tile = choose_move(self)
            self.next_tile = tile
            self.next_tile:reserve_entity_by_id(self:get_id())
            self.anim:on_frame(4, function()
                if self.can_move_to_func(self.next_tile) then 
                else
                    self.next_tile = self:get_tile()
                end
                self:teleport(self.next_tile, ActionOrder.Voluntary)
            end)
            self.anim:on_complete(function()
                -- Reset idle speed, since we did a real action
                self.idle_speed = self.base_idle_speed
                increment_pattern(self)
            end)
        end
    end
end

-- Using Screen Divide.
-- Can use several times in a row if it didn't attack a Character.
-- If there's a Character at Colonel's current Y, he has a chance to skip the last Screen Divide after using the penultimate one and instatly use Colonel Cannon.
function screen_divide(self)
    if self.first_act then
        self.first_act = false
        local enemy = self:get_field():find_nearest_characters(self, function(c)
            return not c:is_team(self:get_team()) and not c:is_passthrough()
        end)
        if self.screendivide_attacked and self.pattern[self.pattern_index-1] == self.states.screen_divide then -- Skips other tries to use Screen Divide if it has hit an enemy.
            self.idle_speed = 26
            increment_pattern(self)
        else
            self.anim:set_state("SCREENDIVIDE", {
                {duration=2, state="IDLE_1"},
                {duration=self.screendivide_delay, state="SABRE_1"},
                {duration=6, state="SABRE_1"},
                {duration=3, state="SABRE_1"},
                {duration=1, state="SABRE_2"},
                {duration=1, state="SABRE_2"},
                {duration=2, state="SABRE_3"},
                {duration=2, state="SABRE_4"},
                {duration=2, state="SABRE_5"},
                {duration=2, state="SABRE_6"},
                {duration=3, state="SABRE_7"},
                {duration=4, state="SABRE_7"},
            })
            local screendivide_table = {}
            local screendivide_type = nil
            local screendivide_table2 = {}
            if #enemy > 0 then
                if enemy[1]:get_tile():y() == 1 then
                    if ((self:get_facing() == Direction.Right and enemy[1]:get_tile():x() > 0 and enemy[1]:get_tile():x() < self:get_field():width()  )
                    or  (self:get_facing() == Direction.Left  and enemy[1]:get_tile():x() > 1 and enemy[1]:get_tile():x() < self:get_field():width()+1))
                    and self:get_tile() ~= enemy[1]:get_tile()
                    and self:get_tile() ~= enemy[1]:get_tile(Direction.join(self:get_facing(),Direction.Down),1)
                    and self:get_tile() ~= enemy[1]:get_tile(Direction.Down,2)
                    then
                        table.insert(screendivide_table, {
                            type="0",
                            tile1=enemy[1]:get_tile(),
                            tile2=enemy[1]:get_tile(Direction.join(self:get_facing(),Direction.Down),1),
                            tile3=enemy[1]:get_tile(Direction.Down,2)
                        })
                    end
                    if ((self:get_facing() == Direction.Right and enemy[1]:get_tile():x() > 0 and enemy[1]:get_tile():x() < self:get_field():width()-1)
                    or  (self:get_facing() == Direction.Left  and enemy[1]:get_tile():x() > 2 and enemy[1]:get_tile():x() < self:get_field():width()+1))
                    and self:get_tile() ~= enemy[1]:get_tile()
                    and self:get_tile() ~= enemy[1]:get_tile(Direction.join(self:get_facing(),Direction.Down),1)
                    and self:get_tile() ~= enemy[1]:get_tile(Direction.join(self:get_facing(),Direction.Down),2)
                    then
                        table.insert(screendivide_table, {
                            type="1",
                            tile1=enemy[1]:get_tile(),
                            tile2=enemy[1]:get_tile(Direction.join(self:get_facing(),Direction.Down),1),
                            tile3=enemy[1]:get_tile(Direction.join(self:get_facing(),Direction.Down),2)
                        })
                    end
                    if ((self:get_facing() == Direction.Right and enemy[1]:get_tile():x() > 2 and enemy[1]:get_tile():x() < self:get_field():width()+1)
                    or  (self:get_facing() == Direction.Left  and enemy[1]:get_tile():x() > 0 and enemy[1]:get_tile():x() < self:get_field():width()-1))
                    and self:get_tile() ~= enemy[1]:get_tile()
                    and self:get_tile() ~= enemy[1]:get_tile(Direction.join(self:get_facing_away(),Direction.Down),1)
                    and self:get_tile() ~= enemy[1]:get_tile(Direction.join(self:get_facing_away(),Direction.Down),2)
                    then
                        table.insert(screendivide_table, {
                            type="2",
                            tile1=enemy[1]:get_tile(),
                            tile2=enemy[1]:get_tile(Direction.join(self:get_facing_away(),Direction.Down),1),
                            tile3=enemy[1]:get_tile(Direction.join(self:get_facing_away(),Direction.Down),2)
                        })
                    end
                elseif enemy[1]:get_tile():y() == self:get_field():height() then
                    if ((self:get_facing() == Direction.Right and enemy[1]:get_tile():x() > 0 and enemy[1]:get_tile():x() < self:get_field():width()  )
                    or  (self:get_facing() == Direction.Left  and enemy[1]:get_tile():x() > 1 and enemy[1]:get_tile():x() < self:get_field():width()+1))
                    and self:get_tile() ~= enemy[1]:get_tile(Direction.Up,2)
                    and self:get_tile() ~= enemy[1]:get_tile(Direction.join(self:get_facing(),Direction.Up),1)
                    and self:get_tile() ~= enemy[1]:get_tile()
                    then
                        table.insert(screendivide_table, {
                            type="0",
                            tile1=enemy[1]:get_tile(Direction.Up,2),
                            tile2=enemy[1]:get_tile(Direction.join(self:get_facing(),Direction.Up),1),
                            tile3=enemy[1]:get_tile()
                        })
                    end
                    if ((self:get_facing() == Direction.Right and enemy[1]:get_tile():x() > 2 and enemy[1]:get_tile():x() < self:get_field():width()+1)
                    or  (self:get_facing() == Direction.Left  and enemy[1]:get_tile():x() > 0 and enemy[1]:get_tile():x() < self:get_field():width()-1))
                    and self:get_tile() ~= enemy[1]:get_tile()
                    and self:get_tile() ~= enemy[1]:get_tile(Direction.join(self:get_facing_away(),Direction.Up),1)
                    and self:get_tile() ~= enemy[1]:get_tile(Direction.join(self:get_facing_away(),Direction.Up),2)
                    then
                        table.insert(screendivide_table, {
                            type="1",
                            tile1=enemy[1]:get_tile(Direction.join(self:get_facing_away(),Direction.Up),2),
                            tile2=enemy[1]:get_tile(Direction.join(self:get_facing_away(),Direction.Up),1),
                            tile3=enemy[1]:get_tile()
                        })
                    end
                    if ((self:get_facing() == Direction.Right and enemy[1]:get_tile():x() > 0 and enemy[1]:get_tile():x() < self:get_field():width()-1)
                    or  (self:get_facing() == Direction.Left  and enemy[1]:get_tile():x() > 2 and enemy[1]:get_tile():x() < self:get_field():width()+1))
                    and self:get_tile() ~= enemy[1]:get_tile()
                    and self:get_tile() ~= enemy[1]:get_tile(Direction.join(self:get_facing(),Direction.Up),1)
                    and self:get_tile() ~= enemy[1]:get_tile(Direction.join(self:get_facing(),Direction.Up),2)
                    then
                        table.insert(screendivide_table, {
                            type="2",
                            tile1=enemy[1]:get_tile(Direction.join(self:get_facing(),Direction.Up),2),
                            tile2=enemy[1]:get_tile(Direction.join(self:get_facing(),Direction.Up),1),
                            tile3=enemy[1]:get_tile()
                        })
                    end
                else
                    if ((self:get_facing() == Direction.Right and enemy[1]:get_tile():x() > 1 and enemy[1]:get_tile():x() < self:get_field():width()+1)
                    or  (self:get_facing() == Direction.Left  and enemy[1]:get_tile():x() > 0 and enemy[1]:get_tile():x() < self:get_field():width()  ))
                    and self:get_tile() ~= enemy[1]:get_tile(Direction.join(self:get_facing_away(),Direction.Up),1)
                    and self:get_tile() ~= enemy[1]:get_tile()
                    and self:get_tile() ~= enemy[1]:get_tile(Direction.join(self:get_facing_away(),Direction.Down),1)
                    then
                        table.insert(screendivide_table, {
                            type="0",
                            tile1=enemy[1]:get_tile(Direction.join(self:get_facing_away(),Direction.Up),1),
                            tile2=enemy[1]:get_tile(),
                            tile3=enemy[1]:get_tile(Direction.join(self:get_facing_away(),Direction.Down),1)
                        })
                    end
                    if (enemy[1]:get_tile():x() > 1 and enemy[1]:get_tile():x() < self:get_field():width()) then
                        if     self:get_tile() ~= enemy[1]:get_tile()
                        and self:get_tile() ~= enemy[1]:get_tile(Direction.join(self:get_facing_away(),Direction.Up),1)
                        and self:get_tile() ~= enemy[1]:get_tile(Direction.join(self:get_facing(),Direction.Down),1)
                        then
                            table.insert(screendivide_table, {
                                type="1",
                                tile1=enemy[1]:get_tile(Direction.join(self:get_facing_away(),Direction.Up),1),
                                tile2=enemy[1]:get_tile(),
                                tile3=enemy[1]:get_tile(Direction.join(self:get_facing(),Direction.Down),1)
                            })
                        elseif self:get_tile() ~= enemy[1]:get_tile()
                        and self:get_tile() ~= enemy[1]:get_tile(Direction.join(self:get_facing(),Direction.Up),1)
                        and self:get_tile() ~= enemy[1]:get_tile(Direction.join(self:get_facing_away(),Direction.Down),1)
                        then
                            table.insert(screendivide_table, {
                                type="2",
                                tile1=enemy[1]:get_tile(Direction.join(self:get_facing(),Direction.Up),1),
                                tile2=enemy[1]:get_tile(),
                                tile3=enemy[1]:get_tile(Direction.join(self:get_facing_away(),Direction.Down),1)
                            })
                        end
                    end
                end
            end
            if #screendivide_table <= 0 then
                self.idle_speed = self.base_idle_speed
                for i=1, self.screendivide_count do
                    increment_pattern(self)
                end
                self.screendivide_count = 0
                return
            else
                local random_type = math.random(1,#screendivide_table)
                screendivide_type = screendivide_table[random_type].type
                table.insert(screendivide_table2,screendivide_table[random_type].tile1)
                table.insert(screendivide_table2,screendivide_table[random_type].tile2)
                table.insert(screendivide_table2,screendivide_table[random_type].tile3)
            end
            self.anim:on_frame(2, function()
                --print("highlight")
                if not self.screendivide_attacked then
                    highlight_tiles(self, screendivide_table2, Highlight.Flash, self.screendivide_delay+20)
                end
            end)
            self.anim:on_frame(3, function()
                self.counterable_component.timer = 16 -- Makes the Character counter-able for 16f.
            end)
            self.anim:on_frame(4, function()
		        Engine.play_audio(SCREENDIVIDE_AUDIO, AudioPriority.Low)
            end)
            self.anim:on_frame(6, function()
                create_screen_divide(self, screendivide_type, screendivide_table2[2])
            end)
            self.anim:on_complete(function()
                self.screendivide_delay = self.screendivide_delay_base2
                self.idle_speed = 26
                --[[
                if self.screendivide_attacked then
                    for i=1, self.screendivide_count do
                        increment_pattern(self)
                    end
                    self.screendivide_count = 0
                else
                end]]
                self.screendivide_count = self.screendivide_count - 1
                increment_pattern(self)
            end)
        end
    end
end

-- Using Colonel Army.
function colonel_army(self)
    if self.first_act then
        self.first_act = false
        self.anim:set_state("COLONELARMY", {
            {duration=2, state="IDLE_1"},
            {duration=3, state="FLINCH_4"},
            {duration=3, state="FLINCH_4"}, -- spawns Stone Cubes
            {duration=3, state="COLONELARMY_1"},
            {duration=19, state="COLONELARMY_2"},--32
        })
        local manip_obs = self:get_field():find_obstacles(function(o) -- Finds every manipulatable Obstacle in enemy tiles.
            return ObstacleInfo.can_be_manipulated(o) and o:get_tile():get_team() ~= self:get_team()
        end)
        if #manip_obs >= self.stonecubes then
            self.idle_speed = self.base_idle_speed
            increment_pattern(self)
            increment_pattern(self)
            return
        end
        local cubes_be = self.stonecubes - #manip_obs
        local tiles = {}
        local obs_query = function(ent)
            if ent:get_animation():has_state("PASS_THROUGH") or ent:get_name() == "CANTINTERACT" then return false end
		    return ent:get_health() > 0
        end
        local enemies = self:get_field():find_characters(function(c)
            return not c:is_team(self:get_team()) and c:get_health() > 0
        end)
        if #enemies > 0 and cubes_be > 0 then
            local rows = {}
            for i=1, self:get_field():height() do
                table.insert(rows, true)
            end
            for _, enemy in ipairs(enemies) do
                local y = enemy:get_tile():y()
                if rows[y] then 
                    rows[y] = nil
                end
            end
            for _, obs in ipairs(manip_obs) do
                local y = obs:get_tile():y()
                if rows[y] then 
                    rows[y] = nil
                end
            end
            local tile1 = {}
            for j=1, self:get_field():height() do
                local tile2 = {}
                for i=1, self:get_field():width() do
                    local new_tile = self:get_field():tile_at(i,j)
                    if rows[j] == true and not new_tile:is_hole() and new_tile:get_team() ~= self:get_team() then
                        table.insert(tile2, new_tile)
                    end
                end
                if #tile2 > 0 then table.insert(tiles, tile2[math.random(1,#tile2)]) end
            end
        end
        if #tiles == 0 or tiles == nil or cubes_be <= 0 then
            self.idle_speed = self.base_idle_speed
            increment_pattern(self)
            increment_pattern(self)
            return
        end
        self.anim:on_frame(3, function()
            shuffle(tiles)
            for i=1,cubes_be do
                if tiles[i] ~= nil then
                    create_stone_cube(self, tiles[i])
                end
            end
        end)
        self.anim:on_complete(function()
            self.idle_speed = 30
            increment_pattern(self)
        end)
    end
end

-- Jumping to enemy.
-- Skips if Confused/Blinded/Rooted, but doesn't interrupt Colonel Cannon.
function move_to_enemy(self)
    if self.first_act then
        self.first_act = false
        if self:is_confused() or self:is_blind() or self:is_rooted() then
            self.idle_speed = self.base_idle_speed
            increment_pattern(self)
        else
            self.anim:set_state("MOVE", {
                {duration=2, state="IDLE_1"},
                {duration=1, state="WARP_1"},
                {duration=1, state="WARP_2"},
                {duration=1, state="WARP_2"},
                {duration=1, state="WARP_1"},
                {duration=2, state="IDLE_1"},
            })
            self.prev_tile = self:get_tile()
            local tile = choose_move_to_enemy(self)
            if not tile then
                self.idle_speed = self.base_idle_speed
                increment_pattern(self)
                return
            end
            self.next_tile = tile
            self.next_tile:reserve_entity_by_id(self:get_id())
            self.anim:on_frame(4, function()
                if self.can_move_to_func(self.next_tile) then 
                else
                    self.next_tile = self:get_tile()
                end
                self:teleport(self.next_tile, ActionOrder.Voluntary)
            end)
            self.anim:on_complete(function()
                -- Reset idle speed, since we did a real action
                self.idle_speed = 32
                increment_pattern(self)
            end)
        end
    end
end

-- Using Colonel Cannon.
function colonel_cannon(self)
    if self.first_act then
        self.first_act = false
        self.anim:set_state("COLONELCANNON", {
            {duration=1, state="IDLE_1"},
            {duration=2, state="COLONELCANNON_1"},
            {duration=2, state="COLONELCANNON_2"},
            {duration=39, state="COLONELCANNON_3"},
            {duration=1, state="COLONELCANNON_4"},
            {duration=1, state="COLONELCANNON_5"},
            {duration=1, state="COLONELCANNON_6"},
            {duration=2, state="COLONELCANNON_7"},
            {duration=3, state="COLONELCANNON_8"},
            {duration=41, state="COLONELCANNON_9"},
            {duration=1, state="IDLE_1"},
        })
        self.anim:on_frame(1, function()
            self.counterable_component.timer = 15 -- Makes the Character counter-able for 15f.
        end)
        self.anim:on_frame(5, function()
		    Engine.play_audio(CANNON_AUDIO, AudioPriority.Low)
        end)
        self.anim:on_frame(6, function()
		    create_sensha_hou_shot(self, self:get_facing(), self:get_tile(self:get_facing(),1))
        end)
        self.anim:on_complete(function()
            self.idle_speed = 26
            increment_pattern(self)
        end)
    end
end

-- Chooses between Screen Divide and Colonel Cannon.
function choose_attack(self)
    if self.first_act then
        self.first_act = false
        local enemy = self:get_field():find_nearest_characters(self, function(c)
            return not c:is_team(self:get_team()) and not c:is_passthrough()
        end)
        if self.screendivide_attacked and self.pattern[self.pattern_index-1] == self.states.screen_divide then
            increment_pattern(self)
        else
            local enemies = self:get_field():find_characters(function(c)
                return not c:is_team(self:get_team()) and c:get_health() > 0
            end)
            local found = false
            if #enemies > 0 then
                for i=1,#enemies do
                    if (enemies[i]:get_tile():x() == 1 or enemies[i]:get_tile():x() == self:get_field():width()) and self.screendivide_times >= 3 and self.screendivide_count == 1 then
                        found = true
                        break
                    end
                end
            end
            if found then
                self.state = self.states.colonel_cannon
                self.state.func(self)
                self.first_act = true
            else
                self.state = self.states.screen_divide
                self.state.func(self)
                self.first_act = true
            end
        end
    end
end

-- Moving before Blind Rain Shower.
function move_before_brs(self)
    if self.first_act then
        self.first_act = false
        if self:is_rooted() then
            self.idle_speed = self.base_idle_speed
            increment_pattern(self)
        else
            self.anim:set_state("MOVE", {
                {duration=2, state="IDLE_1"},
                {duration=1, state="WARP_1"},
                {duration=1, state="WARP_2"},
                {duration=1, state="WARP_2"},
                {duration=1, state="WARP_1"},
                {duration=2, state="IDLE_1"},
            })
            self.prev_tile = self:get_tile()
            local tile = choose_move(self)
            self.next_tile = tile
            self.next_tile:reserve_entity_by_id(self:get_id())
            self.anim:on_frame(4, function()
                if self.can_move_to_func(self.next_tile) then 
                else
                    self.next_tile = self:get_tile()
                end
                self:teleport(self.next_tile, ActionOrder.Voluntary)
            end)
            self.anim:on_complete(function()
                -- Reset idle speed, since we did a real action
                self.idle_speed = 30
                increment_pattern(self)
            end)
        end
    end
end

-- Using Blind Rain Shower.
-- Rooting doesn't interrupt this move at all.
-- Part 1: throws his cape.
-- Part 2: attacks.
function blind_rain_shower_1(self)
    if self.first_act then
        self.first_act = false
        self.anim:set_state("BLINDRAINSHOWER1", {
            -- Waits
            {duration=30, state="IDLE_1"},
            {duration=1, state="IDLE_1"},
            -- Throws cape
            {duration=2, state="CAPETHROW_1"},
            {duration=2, state="CAPETHROW_2"},
            {duration=2, state="CAPETHROW_3"},
            {duration=9, state="CAPETHROW_4"},
            -- Moves away from the field
            {duration=2, state="IDLE_1"},
            {duration=1, state="WARP_1"},
        })
        self.anim:set_playback(Playback.Once)
        local enemy = nil
        self.anim:on_frame(2, function()
            self.counterable_component.timer = 10 -- Makes the Character counter-able for 10f.
        end)
        self.anim:on_frame(3, function()
		    Engine.play_audio(CAPETHROW_AUDIO, AudioPriority.Low)
        end)
        self.anim:on_frame(5, function()
            enemy = self:get_field():find_nearest_characters(self, function(c)
                return c:get_health() > 0 and not c:is_team(self:get_team())
            end)
            if enemy[1] ~= nil then
		        self.colonelcape1 = create_colonel_cape_1(self, self:get_facing(), enemy[1]:get_tile(self:get_facing_away(),1))
		        self.colonelcape2 = create_colonel_cape_2(self, self:get_facing())
            end
        end)
        self.anim:on_frame(7, function()
		    if not self.colonelcape1 or self.colonelcape1:is_deleted() then
                -- Reset idle speed, since we did a real action
                self.idle_speed = self.base_idle_speed
                increment_pattern(self)
                return
            end
        end)
        self.anim:on_complete(function()
            self.original_tile = self:get_tile()
            self.original_tile:reserve_entity_by_id(self:get_id())
            self:hide()
            self:toggle_hitbox(false)
            self:set_offset(0,-1000)
        end)
    end
    --[[
    if self.colonelcape and not self.colonelcape:is_deleted() then
        if self.colonelcape.captured then
            self.state = self.states.blind_rain_shower_2
            self.state.func(self)
            self.first_act = true
        end
    end]]
end

function blind_rain_shower_2(self)
    if self.first_act then
        self.first_act = false
        self.anim:set_state("BLINDRAINSHOWER2", {
            -- Jumps to enemy
            {duration=1, state="WARP_2"},
            {duration=1, state="WARP_1"},
            {duration=17, state="IDLE_1"},
            -- attack 1, 2
            {duration=4, state="BLINDRAINSHOWER_1"},
            {duration=6, state="BLINDRAINSHOWER_2"},
            {duration=4, state="BLINDRAINSHOWER_1"},
            {duration=6, state="BLINDRAINSHOWER_3"},
            {duration=4, state="BLINDRAINSHOWER_1"},
            {duration=16, state="BLINDRAINSHOWER_4"},
            -- attack 3
            {duration=8, state="SABRE_1"},
            {duration=2, state="SABRE_2"},
            {duration=2, state="SABRE_3"},
            {duration=2, state="SABRE_4"},
            {duration=2, state="SABRE_5"},
            {duration=2, state="SABRE_6"},
            {duration=22, state="SABRE_7"},
            -- Moves back to his field
            {duration=2, state="IDLE_1"},
            {duration=1, state="WARP_1"},
            {duration=1, state="WARP_2"},
            {duration=1, state="WARP_2"},
            {duration=1, state="WARP_1"},
            {duration=2, state="IDLE_1"},
            -- Waits
            {duration=30, state="IDLE_1"},
        })
        self:set_offset(0,0)
        self:toggle_hitbox(true)
        self:reveal()
        self.moving_to_enemy_tile = true
        self.original_tile:reserve_entity_by_id(self:get_id())
        local tile = self.colonelcape_tile
        self.next_tile = tile
        self.next_tile:reserve_entity_by_id(self:get_id())
        self.anim:on_frame(1, function()
            --[[
            if self.can_move_to_func(self.next_tile) then 
            else
                self.next_tile = self:get_tile()
            end]]
            self:teleport(self.next_tile, ActionOrder.Immediate)
        end)
        for i=4, 8, 2 do
            self.anim:on_frame(i, function()
		        Engine.play_audio(BLINRAINSHOWER_AUDIO, AudioPriority.Low)
            end)
            self.anim:on_frame(i+1, function()
                create_bls_hitbox(self, self:get_facing(), self:get_tile(self:get_facing(),1))
                self:shake_camera(10, 0.2)
            end)
        end
        self.anim:on_frame(10, function()
		    Engine.play_audio(DREAMSWORD_AUDIO, AudioPriority.Low)
        end)
        self.anim:on_frame(12, function()
            create_bls_hitbox(self, self:get_facing(), self:get_tile(self:get_facing(),1))
            self:shake_camera(20, 0.2)
        end)
        self.anim:on_frame(17, function()
            if self.colonelcape2 and not self.colonelcape2:is_deleted() then
                self.colonelcape2:erase()
            end
        end)
        self.anim:on_frame(20, function()
            --[[
            if self.can_move_to_func(self.next_tile) then 
            else
                self.next_tile = self:get_tile()
            end]]
            self:teleport(self.original_tile, ActionOrder.Immediate)
            self.original_tile = nil
        end)
        self.anim:on_complete(function()
            self.moving_to_enemy_tile = false
            -- Reset idle speed, since we did a real action
            self.idle_speed = self.base_idle_speed
            increment_pattern(self)
        end)
    end
end

-- If the cape flyes away
function blind_rain_shower_3(self)
    if self.first_act then
        self.first_act = false
        self.anim:set_state("BLINDRAINSHOWER3", {
            -- Delay
            {duration=10, state="WARP_2"},
            -- Moves back to his field
            {duration=1, state="WARP_2"},
            {duration=1, state="WARP_1"},
            {duration=2, state="IDLE_1"},
            -- Waits
            {duration=30, state="IDLE_1"},
        })
        self.original_tile:reserve_entity_by_id(self:get_id())
        self.anim:on_frame(2, function()
            self:set_offset(0,0)
            self:toggle_hitbox(true)
            self:reveal()
            --[[
            if self.can_move_to_func(self.next_tile) then 
            else
                self.next_tile = self:get_tile()
            end]]
            self:teleport(self.original_tile, ActionOrder.Immediate)
            self.original_tile = nil
        end)
        self.anim:on_complete(function()
            -- Reset idle speed, since we did a real action
            self.idle_speed = self.base_idle_speed
            increment_pattern(self)
        end)
    end
end

function choose_enemy(self)
    local field = self:get_field()
    local team = self:get_team()

    local target = field:find_characters(function(c)
        return c:get_team() ~= team
    end)

    if not target[1] then 
        debug_print("No targets")
        return nil
    end

    local t_x = target[1]:get_tile():x()
    local t_y = target[1]:get_tile():y()

    local tile = field:tile_at(t_x, t_y)

    return tile
end

function choose_move(self)
    local field = self:get_field()
    local team = self:get_team()

    local tiles = field:find_tiles(function(tile)
        return tile ~= self:get_tile() and not tile:is_edge() and tile:get_team() == team and self.can_move_to_func(tile)
    end)

    debug_print("Found ", #tiles, " possible tiles")

    if #tiles == 0 then
        return self:get_tile()
    end

    return tiles[math.random(1, #tiles)]
end

function choose_move_to_enemy(self)
    local field = self:get_field()
    local team = self:get_team()

    local tiles = nil
    local enemy = choose_enemy(self)
    if enemy then
        tiles = field:find_tiles(function(tile)
            return tile:y() == enemy:y() and not tile:is_edge() and tile:get_team() == team and self.can_move_to_func(tile)
        end)
    end

    debug_print("Found ", #tiles, " possible tiles")

    if #tiles == 0 then
        return nil
    end

    return tiles[math.random(1, #tiles)]
end

function reconstruct_pattern(self)
    local pattern = {}
    local states = self.states
    self.screendivide_attacked = false
    self.screendivide_delay = self.screendivide_delay_base -- Resets itself on every recontruction.
    self.screendivide_count = self.screendivide_times -- Resets itself on every recontruction.
    self.move_count = self.move_count + 1 -- Counts on every recontruction.
    local random_moment_cube = math.random(1,7)

    for i=1,4 do -- Moves randomly 4 times. 
        table.insert(pattern, states.move)
        table.insert(pattern, states.idle)
        if self.move_count>=3 and self.stonecubes > 0 and random_moment_cube == i then
            table.insert(pattern, states.colonel_army)
            table.insert(pattern, states.idle)
        end
    end
    for i=1,self.screendivide_times do
        if i==self.screendivide_times and self.screendivide_times>=3 then
            table.insert(pattern, states.choose_attack)
        else
            table.insert(pattern, states.screen_divide)
        end
    end
    table.insert(pattern, states.idle)
    if self.move_count>=3 and self.stonecubes > 0 and random_moment_cube == 5 then
        table.insert(pattern, states.colonel_army)
        table.insert(pattern, states.idle)
    end
    if self.move_count%3==0 then
        table.insert(pattern, states.move_to_enemy)
        table.insert(pattern, states.idle)
        table.insert(pattern, states.colonel_cannon)
    end
    if self.move_count>=3 and self.stonecubes > 0 and random_moment_cube == 6 then
        table.insert(pattern, states.colonel_army)
        table.insert(pattern, states.idle)
    end
    if self.move_count%6==0 and self.damage_blindrainshower > 0 and self:get_health() <= self:get_max_health()-(self:get_max_health()*0.50) then
        table.insert(pattern, states.move_before_brs)
        table.insert(pattern, states.idle)
        table.insert(pattern, states.blind_rain_shower_1)
    end

    self.pattern = pattern
end

function increment_pattern(self)
    debug_print("Pattern increment")
    self.first_act = true
    self.do_once_1 = true
    self.can_move_to_edge = false
    self.state_done = false
    self.pattern_index = self.pattern_index + 1
    if self.pattern_index > #self.pattern then 
        reconstruct_pattern(self)
        debug_print("Reconstructed pattern")
        self.pattern_index = 1
    end
    local next_state = self.pattern[self.pattern_index]
    self.state = next_state
    debug_print("Moving to state named ", next_state.name)
    if next_state == self.states.start_sub_pattern then 
        self.in_sub_pattern = true
        increment_pattern(self)
    end
    if next_state == self.states.finish_sub_pattern then 
        self.in_sub_pattern = false
        increment_pattern(self)

    end
    debug_print("Changing to "..self.pattern_index..", which is "..self.pattern[self.pattern_index].name)
end

-- Checks for non-zero-health Obstacles.
function check_obstacles(tile, self)
    local ob = tile:find_obstacles(function(o)
        if o:get_animation():has_state("PASS_THROUGH") or o:get_name() == "CANTINTERACT" then
            return false
        else
            return true
        end
        return o:get_health() > 0
    end)
    return #ob > 0 
end

-- Checks for unfriendly Characters.
function check_characters(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_id() ~= self:get_id() and c:get_team() ~= self:get_team()
    end)
    return #characters > 0
end

-- Checks for any Characters.
function check_characters_true(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_health() > 0
    end)
    return #characters > 0
end