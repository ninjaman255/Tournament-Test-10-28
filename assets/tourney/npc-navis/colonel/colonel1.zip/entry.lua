local package_id = "com.OFC.mob.EXE5-037-Colonel1"
local character_id = "com.OFC.char.EXE5-037-Colonel1"

function package_requires_scripts()
    Engine.define_character(character_id, _modpath.."Colonel")
end

function package_init(package)
    package:declare_package_id(package_id)
    package:set_name("Colonel (EXE5)")
    package:set_description("Test fight with\nColonel\nfrom Rockman EXE5")
    package:set_speed(1)
    package:set_attack(20)
    package:set_health(400)
    package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob)
    local texPath = _modpath.."exe5-mainsystemdennou.png"
    local animPath = _modpath.."exe5-mainsystemdennou.animation"
    mob:set_background(texPath, animPath, 0, 0.24)
    local ds_music = true
    if ds_music then
        mob:stream_music(_modpath.."exe5ds-boss.ogg", 5986, 43642)
    else
        mob:stream_music(_modpath.."exe5-boss.ogg", 3771, 41841)
    end
    mob:create_spawner(character_id, Rank.V1):spawn_at(5,2)
end  