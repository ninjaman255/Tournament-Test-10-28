local print_debug = false

local AUDIO_DAMAGE_PLAYER = Engine.load_audio(_folderpath.."sfx/EXE6_149.ogg", true)
local AUDIO_DAMAGE_ENEMY = Engine.load_audio(_folderpath.."sfx/EXE6_50.ogg", true)
local AUDIO_DAMAGE_OBS = Engine.load_audio(_folderpath.."sfx/EXE6_131.ogg", true)

local ELEMENTMAN_TEXTURE = nil
local ELEMENTMAN_ANIMPATH = _folderpath.."gfx/elementman.animation"

local CIRCLE_TEXTURE = nil
local CIRCLE_ANIMPATH = _folderpath.."gfx/circle.animation"

local TORNADO_TEXTURE = Engine.load_texture(_folderpath.."gfx/tornado.png")
local TORNADO_ANIMPATH = _folderpath.."gfx/tornado.animation"
local METEOR_TEXTURE = Engine.load_texture(_folderpath.."gfx/meteor.png")
local METEOR_ANIMPATH = _folderpath.."gfx/meteor.animation"
local BOOM_TEXTURE = Engine.load_texture(_folderpath.."gfx/boom.png")
local BOOM_ANIMPATH = _folderpath.."gfx/boom.animation"
local SPARKLE_TEXTURE = Engine.load_texture(_folderpath.."gfx/sparkle.png")
local SPARKLE_ANIMPATH = _folderpath.."gfx/sparkle.animation"
local THUNDER_TEXTURE = Engine.load_texture(_folderpath.."gfx/thunder.png")
local THUNDER_ANIMPATH = _folderpath.."gfx/thunder.animation"
local WOODYTOWER_TEXTURE = Engine.load_texture(_folderpath.."gfx/woodytower.png")
local WOODYTOWER_ANIMPATH = _folderpath.."gfx/woodytower.animation"

local SHINE_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_98.ogg", true)
local TORNADO_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_292.ogg", true)
local METEOR_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_221.ogg", true)
local ICE_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_162.ogg", true)
local THUNDER_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_31.ogg", true)
local WOODYTOWER_AUDIO = Engine.load_audio(_folderpath.."sfx/EXE6_209.ogg", true)

local EFFECT_TEXTURE = Engine.load_texture(_folderpath.."gfx/effect.png")
local EFFECT_ANIMPATH = _folderpath.."gfx/effect.animation"
local SHINE_TEXTURE = Engine.load_texture(_folderpath.."gfx/shine.png")
local SHINE_ANIMPATH = _folderpath.."gfx/shine.animation"

local function debug_print(text)
    if print_debug then
        print("[ElementMan] "..text)
    end
end

--[[

    Moveset:
    For the first time, ElementMan moves twice (or thrice for V1). Then he uses Downburst once (or twice, if his element is None) and an elemental attack (if his element is not None). Then he moves twice (or thrice for V1). Then he uses Downburst once. Then he moves twice (or thrice for V1). The he uses the element-changing move. If moves ends successfully, changes his element in order: None, Wood, Fire, Elec, Aqua, repeat.

    Downburst:
    ElementMan creates a tornado in one of two back corners of his field that travels a Boomerang-like path. Can't be spawned inside of a Character/an Obstacle. Bownburst's speed depends on ElementMan's version.

    Tallest Tree:
    ElementMan moves to the back line of his field and creates a Woody Tower that moves forward or up-forward/down-forward (if there's an enemy). When it grows completely, changes current tile into Grass. Can be blocked by Obstacles. Can be used if ElementMan can't move to the back line. Tallest Tree's speed depends on ElementMan's version.

    Meteorite:
    ElementMan drops several meteors. Each meteor targets the closest enemy. If HP < 50 %, he drops more meteors.

    Lightning Drive:
    ElementMan creates a thunderbolt that hits current tile and moves to follows enemies in a ThunderBall-like way. Can hit up to 6 tiles. 

    Diamond Dust:
    ElementMan moves to the tile in front of the closest enemy and creates 3 diamond dusts in a WideSword-like way. The attack always freezes hit Characters. If a hit Character has Status Guard, causes flashing instead.

]]

local function graphic_init(g_type, x, y, texture, animation, state, anim_playback, layer, user, facing, flip)
    flip = flip or false
    facing = facing or nil
    
    local graphic = nil
    if g_type == "artifact" then 
        graphic = Battle.Artifact.new()
    elseif g_type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    end

    if layer then
        graphic:sprite():set_layer(layer)
    end
    graphic:never_flip(flip)
    if texture then
        graphic:set_texture(texture, false)
    end
    if facing then
        graphic:set_facing(facing)
    end
    --[[
    if user:get_facing() == Direction.Left then 
        x = x * -1
    end]]
    graphic:set_offset(x, y)
    if animation then
        graphic:get_animation():load(animation)
    end
    if state then
        graphic:get_animation():set_state(state)
    end
    graphic:get_animation():refresh(graphic:sprite())
    if anim_playback then
        graphic:get_animation():set_playback(anim_playback)
    end

    return graphic
end

local function create_diamonddust(user)
    local facing = user:get_facing()
    local dir_table = 
    {
        [1] = Direction.join(facing, Direction.Up),
        [2] = facing,
        [3] = Direction.join(facing, Direction.Down)
    }
    for i=1, #dir_table do
        local ice_tile = user:get_tile(dir_table[i], 1)
        if ice_tile then
            local ice = graphic_init("spell", 0, 0, SPARKLE_TEXTURE, SPARKLE_ANIMPATH, "0", Playback.Once, -3, user, facing)
            ice:set_hit_props(
                HitProps.new(
                    user.damage_diamonddust,
                    --Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Freeze,
                    Hit.Impact | Hit.Flinch | Hit.Freeze,
                    Element.Aqua,
                    user:get_context(),
                    Drag.None
                )
            )
            ice.frames = 0
            ice:get_animation():on_complete(function()
                ice:erase()
            end)
            ice.on_spawn_func = function()
                debug_print("DiamondDust spawned on tile ("..ice_tile:x()..";"..ice_tile:y()..")")
                Engine.play_audio(ICE_AUDIO, AudioPriority.Low)
                if ice_tile:is_edge() or ice_tile:get_state() == TileState.Empty or ice_tile:get_state() == TileState.Hidden then
                else
                    ice_tile:set_state(TileState.Ice)
                end
            end
            ice.update_func = function(self)
                self.frames = self.frames + 1
                if self.frames >= 1 then
                    ice_tile:attack_entities(self)
                end
            end
            ice.attack_func = function(self, other)
                debug_print("DiamondDust attacked tile ("..self:get_tile():x()..";"..self:get_tile():y()..")")
                local offset_y = math.random(-10,1)
                local offset_x = math.random(-8,7)
                if self:get_facing() == Direction.Left then offset_x = -offset_x end
                local hit_fx = graphic_init("artifact", self:get_tile_offset().x+self:get_offset().x+(offset_x*2), self:get_tile_offset().y+self:get_offset().y+(offset_y*2), EFFECT_TEXTURE, EFFECT_ANIMPATH, "A", Playback.Once, -999, self, self:get_facing())
                hit_fx:get_animation():on_complete(function() hit_fx:erase() end)
                self:get_field():spawn(hit_fx, self:get_tile())
                if Battle.Obstacle.from(other) == nil then
                    --if Battle.Player.from(user) ~= nil then
                    --    Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
                    --end
                else
                    Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
                end
            end
            user:get_field():spawn(ice, ice_tile)
        end
    end
end

local function create_lightningdrive(user, tile)
    local thunder = graphic_init("spell", 0, 0, THUNDER_TEXTURE, THUNDER_ANIMPATH, "0", Playback.Once, -3, user, user:get_facing())
    thunder:set_hit_props(
        HitProps.new(
            user.damage_lightningdrive,
            Hit.Impact | Hit.Flinch | Hit.Flash,
            Element.Elec,
            user:get_context(),
            Drag.None
        )
    )
    thunder:get_animation():on_complete(function()
        thunder:erase()
    end)
    thunder.on_spawn_func = function()
        debug_print("LightningDrive spawned on tile ("..tile:x()..";"..tile:y()..")")
        Engine.play_audio(THUNDER_AUDIO, AudioPriority.Low)
    end
    thunder.update_func = function(self)
        tile:highlight(Highlight.Solid)
        tile:attack_entities(self)
    end
    thunder.attack_func = function(self, other)
        debug_print("LightningDrive attacked tile ("..self:get_tile():x()..";"..self:get_tile():y()..")")
        local offset_y = -8
        local offset_x = 8
        if math.random(0,1) == 1 then
            offset_y = -7
            offset_x = -7
        end
        if self:get_facing() == Direction.Left then offset_x = -offset_x end
        local hit_fx = graphic_init("artifact", self:get_tile_offset().x+self:get_offset().x+(offset_x*2), self:get_tile_offset().y+self:get_offset().y+(offset_y*2), EFFECT_TEXTURE, EFFECT_ANIMPATH, "E", Playback.Once, -999, self, self:get_facing())
        hit_fx:get_animation():on_complete(function() hit_fx:erase() end)
        self:get_field():spawn(hit_fx, self:get_tile())
        if Battle.Obstacle.from(other) == nil then
            --if Battle.Player.from(user) ~= nil then
            --    Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
            --end
        else
            Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
        end
    end
    user:get_field():spawn(thunder, tile)
    return thunder
end

local function create_lightningdrive_spawner2(user, tile)
    local spawner = graphic_init("spell", 0, 0, false, false, false, false, false, user, user:get_facing())
    spawner.frames = 0
    spawner.update_func = function(self)
        self.frames = self.frames + 1
        if self.frames == 11 then
            create_lightningdrive(user, tile)
        elseif self.frames >= 43 then
            self:erase()
        end
        tile:highlight(Highlight.Flash)
    end
    user:get_field():spawn(spawner, tile)
    return spawner
end

local function create_lightningdrive_spawner(user, tile)
	local saved_direction = user:get_facing()
    local spawner = graphic_init("spell", 0, 0, false, false, false, false, false, user, saved_direction)
    spawner.frames = 0
    spawner.tile = 5
	local direction = nil
	local target = nil
    spawner.update_func = function(self)
        self.frames = self.frames + 1
        if self.tile <= 0 then
            self:erase()
        else
            if self.frames == 41 then
                local c_tile = self:get_tile()
                if not target then
                    local closest_dist = math.huge
                    self:get_field():find_characters(function(character)
                        local character_team = character:get_team()
                        if (
                            character_team == user:get_team() or
                            character_team == Team.Other or
                            character:will_erase_eof()
                        ) then
                            return false
                        end
                        if not target then
                            target = character
                        else
                            -- If the distance to one enemy is shorter than the other, target the shortest enemy path
                            local dist = math.abs(c_tile:x() - character:get_tile():x()) + math.abs(c_tile:y() - character:get_tile():y())
                            if dist < closest_dist then
                                target = character
                                closest_dist = dist
                            end
                        end
                        return false
                    end)
                    -- We have found a target
                    -- Create a notifier so we can null the target when they are deleted
                    if target then
                        local callback = function()
                            target = nil
                        end
                        self:get_field():notify_on_delete(target:get_id(), self:get_id(), callback)
                    end
                end
                direction = saved_direction
                if target then
                    local target_tile = target:get_tile()
                    if target_tile then
                        if target_tile:x() < c_tile:x() then
                            direction = Direction.Left
                        elseif target_tile:x() > c_tile:x() then
                            direction = Direction.Right
                        elseif target_tile:y() < c_tile:y() then
                            direction = Direction.Up
                        elseif target_tile:y() > c_tile:y() then
                            direction = Direction.Down
                        end
                        -- Poll if target is flagged for deletion, remove our mark
                        if target:will_erase_eof() then
                            target = nil
                        end
                    end
                end
                local query = function(c)
                    return c and c:get_health() > 0 and not c:is_team(self:get_team())
                end
                if #self:get_tile():find_characters(query) <= 0 then
                    -- Always slide to the tile we're moving to
                    local next_tile = self:get_tile(direction, 1)
                    self:teleport(next_tile, ActionOrder.Immediate)
                end
            elseif self.frames >= 42 then
                self.frames = 0
                self.tile = self.tile - 1
                create_lightningdrive_spawner2(user, self:get_tile())
            end
        end
    end
    spawner.can_move_to_func = function(tile)
        return true
    end
    user:get_field():spawn(spawner, tile)
    create_lightningdrive_spawner2(user, tile)
    return spawner
end

local function create_meteorite_hitbox(user, tile)
    local hitbox = graphic_init("spell", 0, 0, false, false, false, false, false, user, user:get_facing())
    hitbox:set_hit_props(
        HitProps.new(
            user.damage_meteorite,
            Hit.Impact | Hit.Flinch | Hit.Flash,
            Element.Fire,
            user:get_context(),
            Drag.None
        )
    )
    hitbox.change_panel = false
    hitbox.update_func = function(self)
        tile:attack_entities(self)
        if self.change_panel then
            if tile:get_state() == TileState.Grass then
                tile:set_state(TileState.Normal)
            end
            self:erase()
        end
        self.change_panel = true
    end
    hitbox.collision_func = function(self)
        self.change_panel = true
        if tile:get_state() == TileState.Grass then
            self:set_hit_props(
                HitProps.new(
                    user.damage_meteorite*2,
                    Hit.Impact | Hit.Flinch | Hit.Flash,
                    Element.Fire,
                    user:get_context(),
                    Drag.None
                )
            )
        end
    end
    hitbox.attack_func = function(self, other)
        debug_print("Meteorite attacked tile ("..self:get_tile():x()..";"..self:get_tile():y()..")")
        local offset_y = math.random(-7,3)
        local offset_x = math.random(-9,1)
        if self:get_facing() == Direction.Left then offset_x = -offset_x end
        local hit_fx = graphic_init("artifact", self:get_tile_offset().x+self:get_offset().x+(offset_x*2), self:get_tile_offset().y+self:get_offset().y+(offset_y*2), EFFECT_TEXTURE, EFFECT_ANIMPATH, "F", Playback.Once, -999, self, self:get_facing())
        hit_fx:get_animation():on_complete(function() hit_fx:erase() end)
        self:get_field():spawn(hit_fx, self:get_tile())
        if Battle.Obstacle.from(other) == nil then
            --if Battle.Player.from(user) ~= nil then
            --    Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
            --end
        else
            Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
        end
    end
    user:get_field():spawn(hitbox, tile)
    return hitbox
end

local function create_meteorite(user, tile)
    local offset_x = -11*2
    if user:get_facing() == Direction.Left then offset_x = -offset_x end
    local meteor = graphic_init("spell", offset_x*21, (-11*2)*21, METEOR_TEXTURE, METEOR_ANIMPATH, "0", Playback.Once, -3, user, user:get_facing())
    meteor.state = "WAIT"
    meteor.frames = 0
    meteor.on_spawn_func = function(self)
        debug_print("Meteorite spawned on tile ("..tile:x()..";"..tile:y()..")")
        self:hide()
    end
    local query = function(e)
        return e and e:get_health() > 0 and not e:get_team(meteor:get_team())
    end
    meteor.update_func = function(self)
        self.frames = self.frames + 1
        self:highlight_tile(Highlight.Flash)
        if self.state == "WAIT" then
            if self.frames >= 14 then
                self.state = "FALL"
                self.frames = 0
                Engine.play_audio(METEOR_AUDIO, AudioPriority.Low)
                self:reveal()
            end
        elseif self.state == "FALL" then
            if self:get_offset().y >= 0 then
                if not tile:is_hole() or #tile:find_characters(query) > 0 or #tile:find_obstacles(query) > 0 then
                    local offset_y = -5
                    local offset_x = -5
                    if self:get_facing() == Direction.Left then offset_x = -offset_x end
                    local boom_effect = graphic_init("artifact", (offset_x*2), (offset_y*2), BOOM_TEXTURE, BOOM_ANIMPATH, "0", Playback.Once, -99, self, self:get_facing())
                    boom_effect:get_animation():on_complete(function() boom_effect:erase() end)
                    self:get_field():spawn(boom_effect, tile)
                end
                create_meteorite_hitbox(user, tile)
                self:erase()
            else
                self:set_offset(self:get_offset().x+(-offset_x), self:get_offset().y+(11*2))
            end
        end
    end
    user:get_field():spawn(meteor, tile)
end

local function find_target(spell)
    local field = spell:get_field()
    local team = spell:get_team()
    local target_list = field:find_characters(function(c)
        return c:get_team() ~= team
    end)
    local target_character = nil
    if #target_list > 0 then
        target_character = target_list[1]
    else
        target_character = nil
    end
    return target_character
end

local function getNextTile(facing, spell)
    local tile = spell:get_tile(facing, 1)
    local target_movement_tile = tile
    local target_character = find_target(spell)
    if target_character == nil then return tile end
    local target_character_tile = target_character:get_tile()
    if tile:y() < target_character_tile:y() then
        target_movement_tile = tile:get_tile(Direction.Down,1)
    end
    if tile:y() > target_character_tile:y() then
        target_movement_tile = tile:get_tile(Direction.Up,1)
    end
    return target_movement_tile
end

local function create_tallesttree(user, tile)
    local spawn_next
    spawn_next = function()
        local query = function(o)
            return o and o:get_health() > 0
        end
        if not tile or tile:is_edge() or tile:is_hole() or #tile:find_obstacles(query) > 0 then return end
        local woodytower = graphic_init("spell", 0, 0, WOODYTOWER_TEXTURE, WOODYTOWER_ANIMPATH, "0", Playback.Once, -3, user, user:get_facing(), true)
        woodytower:set_hit_props(
            HitProps.new(
                user.damage_tallesttree,
                Hit.Impact | Hit.Flinch | Hit.Flash,
                Element.Wood,
                user:get_context(),
                Drag.None
            )
        )
        woodytower.frames = 0
        woodytower.on_spawn_func = function()
            debug_print("WoodyTower spawned on tile ("..tile:x()..";"..tile:y()..")")
            Engine.play_audio(WOODYTOWER_AUDIO, AudioPriority.Low)
        end
        woodytower.update_func = function(self)
            self.frames = self.frames + 1
            if self.frames == math.floor(user.tallesttree_next_frame/2)-1 then
                tile = getNextTile(self:get_facing(), self)
            elseif self.frames == user.tallesttree_next_frame-1 then
                spawn_next()
            elseif self.frames == 14-1 then
                self:get_tile():set_state(TileState.Grass)
            elseif self.frames >= 24 then
                self:erase()
            end
            self:get_tile():attack_entities(self)
        end
        woodytower.attack_func = function(self, other)
            debug_print("WoodyTower attacked tile ("..self:get_tile():x()..";"..self:get_tile():y()..")")
            local offset_y = math.random(-6,5)
            local offset_x = math.random(-9,6)
            if self:get_facing() == Direction.Left then offset_x = -offset_x end
            local hit_fx = graphic_init("artifact", self:get_tile_offset().x+self:get_offset().x+(offset_x*2), self:get_tile_offset().y+self:get_offset().y+(offset_y*2), EFFECT_TEXTURE, EFFECT_ANIMPATH, "N", Playback.Once, -999, self, self:get_facing())
            hit_fx:get_animation():on_complete(function() hit_fx:erase() end)
            self:get_field():spawn(hit_fx, self:get_tile())
            if Battle.Obstacle.from(other) == nil then
                --if Battle.Player.from(user) ~= nil then
                    --Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
                --end
            else
                Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
            end
        end
        user:get_field():spawn(woodytower, tile)
    end
    spawn_next()
end

local function create_downburst(user, tile)
    local query = function(e)
        return e and e:get_health() > 0
    end
    if not tile or #tile:find_characters(query) > 0 or #tile:find_obstacles(query) > 0 then return end
    local downburst = graphic_init("spell", 0, 0, TORNADO_TEXTURE, TORNADO_ANIMPATH, "0", Playback.Loop, -3, user, user:get_facing())
    downburst:set_hit_props(
        HitProps.new(
            user.damage_downburst,
            Hit.Impact | Hit.Flinch | Hit.Flash,
            Element.Wind,
            user:get_context(),
            Drag.None
        )
    )
    downburst.frames = 0
    downburst.direction = downburst:get_facing()
    downburst.on_spawn_func = function(self)
        Engine.play_audio(TORNADO_AUDIO, AudioPriority.Low)
    end
    downburst.update_func = function(self)
        self.frames = self.frames + 1
        self:get_tile():attack_entities(self)
        if self.frames >= 14 then
            if not self:is_sliding() then
                local next_tile = self:get_tile(self.direction, 1)
                if next_tile == nil then
                    --print("NIL")
                    self:erase()
                else
                    --print("not NIL")
                    if next_tile:is_edge() then
                        --print("EDGE")
                        if self.direction == self:get_facing() then
                            if self:get_tile():y() <= 1 then
                                self.direction = Direction.Down
                            elseif self:get_tile():y() >= self:get_field():height() then
                                self.direction = Direction.Up
                            end
                        elseif self.direction == Direction.Up or self.direction == Direction.Down then
                            self.direction = self:get_facing_away()
                        end
                        next_tile = self:get_tile(self.direction, 1)
                    end
                    self:slide(next_tile, frames(user.downburst_speed_frames), frames(0), ActionOrder.Voluntary)
                end
            end
        end
    end
    downburst.collision_func = function(self)
        self:erase()
    end
    downburst.attack_func = function(self, other)
        debug_print("Downburst attacked tile ("..self:get_tile():x()..";"..self:get_tile():y()..")")
        local offset_y = math.random(-6,7)
        local offset_x = math.random(-7,6)
        if self:get_facing() == Direction.Left then offset_x = -offset_x end
        local hit_fx = graphic_init("artifact", self:get_tile_offset().x+self:get_offset().x+(offset_x*2), self:get_tile_offset().y+self:get_offset().y+(offset_y*2), EFFECT_TEXTURE, EFFECT_ANIMPATH, "N", Playback.Once, -999, self, self:get_facing())
        hit_fx:get_animation():on_complete(function() hit_fx:erase() end)
        self:get_field():spawn(hit_fx, self:get_tile())
        if Battle.Obstacle.from(other) == nil then
            --[[
			if Battle.Player.from(user) ~= nil then
				Engine.play_audio(AUDIO_DAMAGE_ENEMY, AudioPriority.Low)
			end
            ]]
		else
			Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
		end
    end
    downburst.can_move_to_func = function(tile)
        return true
    end
    user:get_field():spawn(downburst, tile)
    return downburst
end

function package_init(self)
    ELEMENTMAN_TEXTURE = Engine.load_texture(_folderpath.."gfx/elementman.grayscaled.png")
    CIRCLE_TEXTURE = Engine.load_texture(_folderpath.."gfx/circle.grayscaled.png")
    self:set_name("ElemntMn")
	local rank = self:get_rank()
    self.damage = 10
    self.damage_downburst = 60
    self.damage_meteorite = 60
    self.damage_diamonddust = 60
    self.damage_lightningdrive = 60
    self.damage_tallesttree = 30
    self.first_move = true
    self.r_atk = nil

    self.elem_table = {
        Element.None,
        Element.Wood,
        Element.Fire,
        Element.Elec,
        Element.Aqua
    }
    self.elem_table_index = 1

    self.next_tile = nil
    self.prev_tile = nil
    self.original_tile = nil

    self.base_idle_speed = 32
    self.moves_count = 2
    self.downburst_speed_frames = 10
    self.meteorite_count_hp1 = 4
    self.meteorite_count_hp2 = 6
    self.tallesttree_next_frame = 22

    -- Chance /16. I'm going to run these when the pattern is complete and when the flinch finishes, respectively
        -- These skips will be very implementation-specific, so don't use them as future references
    self.chance_to_move_zero_times = 2
    self.chance_to_move_six_times = 4 --has a change to move 6 times
    self.chance_to_skip_idle_after_flinch = 2
    self.chance_to_halve_idle_after_flinch = 3

    if rank == Rank.V1 then
        self:set_name("ElemntMan")
        self:set_health(900)
        self.moves_count = 3
    elseif rank == Rank.EX then
        self:set_health(1300)
        self.damage = 10
        self.damage_downburst = 100
        self.damage_meteorite = 90
        self.damage_diamonddust = 50
        self.damage_lightningdrive = 100
        self.damage_tallesttree = 50
        self.base_idle_speed = 26
        self.downburst_speed_frames = 9
        self.tallesttree_next_frame = 18
    elseif rank == Rank.SP then
        self:set_health(1700)
        self.damage = 10
        self.damage_downburst = 140
        self.damage_meteorite = 120
        self.damage_diamonddust = 70
        self.damage_lightningdrive = 140
        self.damage_tallesttree = 70
        self.base_idle_speed = 20
        self.downburst_speed_frames = 8
        self.meteorite_count_hp1 = 5
        self.meteorite_count_hp2 = 8
        self.tallesttree_next_frame = 14
    elseif rank == Rank.NM then
        self:set_health(2000)
        self.damage = 10
        self.damage_downburst = 240
        self.damage_meteorite = 200
        self.damage_diamonddust = 120
        self.damage_lightningdrive = 240
        self.damage_tallesttree = 120
        self.base_idle_speed = 14
        self.downburst_speed_frames = 7
        self.meteorite_count_hp1 = 6
        self.meteorite_count_hp2 = 10
        self.tallesttree_next_frame = 12
    end

    --self.idle_speed = self.base_idle_speed
    self.idle_speed = 0

    self:set_texture(ELEMENTMAN_TEXTURE, true)
    self:store_base_palette(Engine.load_texture(_folderpath.."gfx/palette/palette-1.png"))
    self:set_palette(self:get_base_palette())

    self:set_height(64)
    self:set_explosion_behavior(5, 1, true)
    self:set_offset(0,0)
	self:set_facing(Direction.Left)
	self:set_element(Element.None)
	self:set_float_shoe(false)
	self:set_air_shoe(false)
    self:share_tile(false)

    self.circle = self:create_node()
    self.circle:set_texture(CIRCLE_TEXTURE, true) --Just set their texture...
    self.circle:set_layer(1) --Set their layer, they're already a sprite...
    self.circle_anim = Engine.Animation.new(CIRCLE_ANIMPATH) --And they have no get_animation, so we create one...
    --self.circle_anim:copy_from(self:get_animation()) --Load or copy the animation and do the normal stuff...
    self.circle_anim:set_state("IDLE")
    self.circle_anim:refresh(self.circle)
    self.circle_anim:set_playback(Playback.Loop)
    self.circle_anim:set_playback_speed(0)
    self.circle:enable_parent_shader(true)
    --self.circle_anim:set_owner(self)

    local anim = self:get_animation()
    anim:load(ELEMENTMAN_ANIMPATH)
    self.anim = include("enemy_base_v1/entry.lua")
    anim = self.anim
    anim:set_owner(self)
    anim:set_state("IDLE", {
        {duration=1, state="IDLE_1"},
    })
    anim:set_playback(Playback.Loop)

    local ref = self
    self.animate_component = Battle.Component.new(self, Lifetimes.Battlestep)
    self.animate_component.update_func = function(self, dt)
        ref.circle_anim:update(dt, ref.circle)
    end
    self:register_component(self.animate_component)

    init_boss(self)
end

--(Function by Alrysc)
-- This is to fix something that happens because I'm a cheater
--[[
    The aggressor of an attack is held in the Context object. 
    ONB leaves this aggressor unset in the Entity's Context until a CardAction is used for the first time
    So I'll immediately force a CardAction that will hopefully end immediately and not get in the way, but also will fix this
    This probably goes horribly wrong if the enemy is spawned after the mob intro, but should be fine for now otherwise
]]
function fix_context(self)
    local action = Battle.CardAction.new(self, "IDLE_1")
    action.execute_func = function()
        action:end_action()
    end
    self:card_action_event(action, ActionOrder.Immediate)
end

--(Function by Alrysc)
function init_boss(self)
    self.on_spawn_func = function(self)
        if self:get_rank() == Rank.NM then
            --self:set_name("ElmntMnRV")
        end
        fix_context(self)
    end

    self.battle_start_func = function(self)
        --print("COLOR: r("..self:get_color().r..")")
        --print("COLOR: g("..self:get_color().g..")")
        --print("COLOR: b("..self:get_color().b..")")
        --print("COLOR: a("..self:get_color().a..")")
        self.circle_anim:set_playback_speed(1)
    end

    -- Setting names here is just convenience if I want to print the state I'm in later
    self.states = {
        idle = {name = "idle", func = idle},
        move = {name = "move", func = move},
        flinch = {name = "flinch", func = flinch},
        
        start_sub_pattern = {name = "start_sub_pattern"},
        finish_sub_pattern = {name = "finish_sub_pattern"},

        element_change = {name = "element_change", func = element_change},

        downburst = {name = "downburst", func = downburst},
        meteorite = {name = "meteorite", func = meteorite},
        diamonddust = {name = "diamonddust", func = diamonddust},
        lightningdrive = {name = "lightningdrive", func = lightningdrive},
        tallesttree = {name = "tallesttree", func = tallesttree},

        choose_attack = {name = "choose_attack", func = choose_attack}
    }
    
    local s = self.states

    reconstruct_pattern(self)
 
    self.pattern_index = 1
    self.in_sub_pattern = false

    self.first_act = true
    self.whitening = false

    self.state_done = false

    self.state = self.pattern[1]

    self.first_flinch = true

    self.hit_func = function(from_stun)
        --debug_print("Hit func runs")
        self.counterable_component.timer = 0
        self:toggle_counter(false)
        self.flinching = false
        self.first_act = false
        self.whitening = false
        self.state_done = false
        self.moving_to_enemy_tile = false
        if self.first_flinch then 
            --self.state.cleanup
            self.last_state = self.state
            --debug_print("Hit! Set last state to ", self.state.name)
            if self.state ~= self.states.idle and self.state ~= self.states.move then 
               --increment_pattern(self)
            end
            self.first_flinch = false
        end
        self.state = self.states.flinch
        -- This is unused for this boss
        if self.slide_component ~= nil then 
            --debug_print("Hit while moving.")
            self.slide_component:eject()
            self.slide_component = nil
            self:set_offset(0,0)
            if self.slide_dest and self:get_tile() ~= self.slide_dest then 
                --debug_print("Hit before reaching destination.")
                self:get_tile():remove_entity_by_id(self:get_id())
                self.slide_dest:add_entity(self)
                self.slide_dest = nil
            end
        end
        flinch(self, from_stun)
    end

    self.delete_func = function(self)
        self.update_func = function(self)
            self:get_animation():set_state("FLINCH_3")
            self.circle_anim:set_state("STUN")
            self.state = self.states.flinch
        end
    end

    -- Unused for this boss
    self.moving_to_enemy_tile = false
    self.counter = 0
    self.collision_available = true
    self.counterable = 0

    local ref = self
    self.counterable_component = Battle.Component.new(self, Lifetimes.Battlestep)
    self.counterable_component.timer = 0
    self.counterable_component.update_func = function(self)
        if self.timer > 0 then
            debug_print("COUNTERABLE")
            self.timer = self.timer - 1
            ref:toggle_counter(true)
        else
            ref:toggle_counter(false)
        end
    end
    self:register_component(self.counterable_component)

    self:register_status_callback(Hit.Stun, function() self.hit_func(true) end)
    self:register_status_callback(Hit.Freeze, function() self.hit_func(true) end)
    self:register_status_callback(Hit.Flinch, self.hit_func)
    self:register_status_callback(Hit.Root, function() self.rooted = 120 end)
    --self:register_status_callback(Hit.Drag, self.hit_func)

    -- Bring it back next build. For now, relying on the stun callback
    self.on_countered = function(self)
        debug_print("Countered")
        --self.counterable_component.timer = 0
        --self:toggle_counter(false)
        self.hit_func(true)
    end

    self.rooted = 0
    self.can_move_to_func = function(tile)
        if self.rooted > 0 then return false end
        if tile:is_edge() or not tile:is_walkable() then
            return false
        end
        if(tile:is_reserved({self:get_id()})) then
            return false
        end
        if tile == self:get_tile() then
            return true
        end
        if not self.moving_to_enemy_tile and (tile:get_team() ~= self:get_team()) then
            return false
        end
        return not check_obstacles(tile, self) and not check_characters_true(tile, self)
    end

    --self.do_once_blind_confuse = true

    self.update_func = function(self)
        --debug_print("     ", self.state.name, self:get_animation():get_state())
        if self.rooted > 0  then self.rooted = self.rooted - 1 end
        self.state.func(self)
        self.anim:tick_animation()
        -- When we tick animation, we may run increment_pattern. 
        -- The new state isn't run until next frame, so our anim state lasts one more frame when it finishes
        -- Calling our state one time to set things up will avoid this. Mostly sure this doesn't have major unintended consequences,
        -- especially as most state.func only set state and callbacks for frame 1
        -- Problem is, now I may have a frame 1 callback but I don't run it until next frame
        while self.first_act
        do
            self.state.func(self)
            self.anim:tick_animation()
        end
        check_collision(self)
    end
end

--(Function by Alrysc)
function create_collision_attack(self, tile)
    local spell = Battle.Spell.new(self:get_team())
    local hit_props = HitProps.new(
        self.damage,
        Hit.Impact | Hit.Flash | Hit.Flinch,
        self:get_element(), 
        self:get_context(), 
        Drag.None
    )
    spell:set_hit_props(hit_props)
    spell.update_func = function(self)
        tile:attack_entities(self)
        self:delete()
    end
    self:get_field():spawn(spell, tile)
end

--(Function by Alrysc)
-- TODO: When we get is_passthrough or something, check to see if target became flashing before 
-- we are allowed to spawn another one. Don't want to instakill viruses
-- self.collision_available can do something related to that. Does nothing now
function check_collision(self)
    local t = self:get_tile()
    if self.collision_available and check_characters(t, self) then 
        create_collision_attack(self, t)
    end
end

--(Function by Alrysc)
function idle(self)
    if self.first_act then
        self.first_act = false
        -- This is an old check for when I extended idle time by doing two idle states in a row, when characters have an animated idle
        -- Not needed if I instead use a timer
        if self.anim:get_state() ~= "IDLE" then 
            --debug_print("Idle with ", self.idle_speed)
            self.anim:set_state("IDLE", {
                {duration=4, state="IDLE_1"},
            })    
        end
        self.anim:set_playback(Playback.Loop)
        if self.circle_anim:get_state() ~= "IDLE" then 
            self.circle_anim:set_state("IDLE")
            self.circle_anim:refresh(self.circle)
            self.circle_anim:set_playback(Playback.Loop)
        end
        self.counter = 0
    end
    self.counter = self.counter + 1
    if self.counter == 1 then
        if self.rooted > 0 then
            self.idle_speed = self.base_idle_speed
            increment_pattern(self)
        end
    elseif self.counter > self.idle_speed then
        -- Extra catch for after leaving attack. Attack will double idle speed once, so making sure to reset it after
        if self.idle_speed > self.base_idle_speed then 
            self.idle_speed = self.base_idle_speed
        end
        increment_pattern(self)
    end
    --self.looped = false
    --if self.state_done then 
        --print("State done")
    --end
end

--(Function by Alrysc)
function hit()

end

--(Function by Alrysc)
function end_sub_pattern(self)
    while(self.in_sub_pattern)
    do
        increment_pattern(self)
    end
end

--(Function by Alrysc)
function flinch(self, from_stun)
    -- print("Flinch played")
    if self:get_tile() == self.next_tile then
        local orig_tile = self.next_tile
        self.next_tile:remove_entity_by_id(self:get_id())
        self.next_tile = orig_tile
        self.next_tile:add_entity(self)
        self.next_tile = nil
    elseif self:get_tile() == self.prev_tile then
        local orig_tile = self.prev_tile
        self.prev_tile:remove_entity_by_id(self:get_id())
        self.prev_tile = orig_tile
        self.prev_tile:add_entity(self)
        self.prev_tile = nil
    elseif self:get_tile() ~= self.next_tile then
        if self.next_tile ~= nil then
            self.next_tile:remove_entity_by_id(self:get_id())
            self.next_tile = nil
        end
    end
    if self.original_tile then
        self:teleport(self.original_tile, ActionOrder.Immediate)
        self:get_tile():remove_entity_by_id(self:get_id())
        self.original_tile:add_entity(self)
        self.original_tile = nil
    end
    if self.rooted > 0 then self.rooted = 0 end
    -- print("I am flinching")
    if not self.flinching then 
        local frames = {}
        if not from_stun then
            frames[1] = {duration=2, state="FLINCH_1"}
            frames[2] = {duration=3, state="FLINCH_2"}
            frames[3] = {duration=2, state="FLINCH_3"}
            frames[4] = {duration=2, state="FLINCH_2"}
            frames[5] = {duration=2, state="FLINCH_3"}
            frames[6] = {duration=4, state="FLINCH_4"}
            --self.circle_anim:set_state("FLINCH")
        else
            frames[1] = {duration=1, state="FLINCH_3"}
            --self.circle_anim:set_state("STUN")
        end
        --self.circle_anim:refresh(self.circle)
        self.anim:set_state("FLINCH", frames)
        if not from_stun then
            self.anim:on_frame(1, function()
                self.circle_anim:set_state("FLINCH_1")
                self.circle_anim:refresh(self.circle)
            end)
            for i=2, 4, 2 do
                self.anim:on_frame(i, function()
                    self.circle_anim:set_state("FLINCH_2")
                    self.circle_anim:refresh(self.circle)
                end)
            end
            for i=3, 5, 2 do
                self.anim:on_frame(i, function()
                    self.circle_anim:set_state("FLINCH_3")
                    self.circle_anim:refresh(self.circle)
                end)
            end
            self.anim:on_frame(6, function()
                self.circle_anim:set_state("FLINCH_4")
                self.circle_anim:refresh(self.circle)
            end)
        else
            self.circle_anim:set_state("FLINCH_3")
            self.circle_anim:refresh(self.circle)
        end
        self.anim:on_complete(function()
            -- If we didn't just attack, we want to make sure the idle speed is correct. This is also set in the actual idle, but just for extra measure.
            -- Shouldn't be necessary
            if self.idle_speed > self.base_idle_speed and self.pattern[self.pattern_index] ~= self.states.choose_attack then 
                self.idle_speed = self.base_idle_speed
            end

            local has_skipped = false
            if self.last_state == self.states.idle then 
                --debug_print("Attempt skip, because last state was idle")
                has_skipped = maybe_skip_after_flinch(self)
            end

            --debug_print("I am done flinching")
            --debug_print("Anim done")
            self.flinching = false
            self.state_done = true
            self.first_flinch = true

            --debug_print("Done")
            self.state_done = false
            if self.last_state ~= self.states.idle and self.last_state ~= self.states.move then 
                --debug_print("Last state was not idle or move", self.last_state.name)
                increment_pattern(self)
            else
                --if not has_skipped then 
                -- If we were in idle or move, go back to it and try again
                -- Unless we were in a sub pattern. Still end that.
                --debug_print("Last state was idle or move")
                if self.in_sub_pattern then 
                    end_sub_pattern(self)
                else
                    self.state = self.last_state
                    self.first_act = true
                end
            end
        end)
    end
    self.flinching = true
end

--(Function by Alrysc)
--[[
    Chance to skip idle or halve idle time, to call after flinching 
    This works by calling increment_pattern an extra time if and only if the last state was Idle
        Remember, last state is the state we will return to after flinching
        Some extra work will need to be done in the self.anim:on_complete of flinch if this is to work with sub patterns. This boss doesn't use them, so it was omitted
    
    Currently, the skip is implemented as setting idle time to 0
    
    A future choice for this function: after calling this function, self.state *may* increment, obsoleting our last state pointer. Returns true if this does happen
        There is a possible additional side effect that the idle time will instead be changed, in which case, last state is preserved and false is returned
]]
function maybe_skip_after_flinch(self)
    local chance_halve = self.chance_to_halve_idle_after_flinch
    local chance_skip = self.chance_to_skip_idle_after_flinch
    local max = chance_halve + chance_skip + (16 - chance_halve - chance_skip)

    local r = math.random(1, max)
    if r <= chance_halve then 
        self.idle_speed = math.floor(self.idle_speed / 2)
       -- print("We halved")
    elseif r <= (chance_skip + chance_halve) then 
       -- print("We skipped")
        self.idle_speed = 0
        return true
    end

    return false
end

--(Function by Alrysc)
function highlight_tiles(self, list, time, type)
    local spell = Battle.Spell.new(self:get_team())
    local ref = self
    spell.update_func = function(self)
        for i=1, #list do 
            local t = list[i]
            if t and not t:is_edge() then 
                t:highlight(type)
            end
        end
        time = time - 1
        if time == 0 then 
            self:delete()
        end
        if self.flinching then 
            if spell and not spell:is_deleted() then 
                spell:delete()
            end
        end
    end
    self:get_field():spawn(spell, self:get_tile())
    return spell
end

--(Function by Alrysc)
function move(self)
    if self.first_act then
        self.first_act = false
        if self.rooted > 0 then
            self.idle_speed = self.base_idle_speed
            increment_pattern(self)
        else
            self.anim:set_state("MOVE", {
                {duration=1, state="IDLE_1"},
                {duration=1, state="WARP_1"},
                {duration=1, state="WARP_2"},
                {duration=1, state="WARP_2"},
                {duration=1, state="WARP_1"},
                {duration=1, state="IDLE_1"},
            })
            self.circle_anim:set_state("MOVE")
            self.circle_anim:refresh(self.circle)
            self.prev_tile = self:get_tile()
            local tile = choose_move(self, self:get_field())
            if not tile then
                tile = self:get_tile()
            end
            self.next_tile = tile
            self.next_tile:reserve_entity_by_id(self:get_id())
            self.anim:on_frame(4, function()
                if self.can_move_to_func(self.next_tile) then 
                else
                    self.next_tile = self:get_tile()
                end
                self:teleport(self.next_tile, ActionOrder.Voluntary, nil)
            end)
            self.anim:on_complete(function()
                -- Reset idle speed, since we did a real action
                self.idle_speed = self.base_idle_speed
                increment_pattern(self)
            end)
        end
    end
end

function choose_attack(self)
    local atk_tbl = {}
    self.state = atk_tbl[self.r_atk]

    self.state.func(self)
    self.idle_speed = self.base_idle_speed * 2
end

function downburst(self)
    if self.first_act then
        self.first_act = false
        self.anim:set_state("DOWNBURST", {
            {duration=12, state="IDLE_1"},
            {duration=4, state="ATTACK_1"},
            {duration=15, state="ATTACK_2"},
            {duration=4, state="ATTACK_2"},
            {duration=3, state="ATTACK_3"},
            {duration=10, state="ATTACK_4"},
            {duration=2, state="IDLE_1"},
        })
        self.circle_anim:set_state("ATTACK0")
        self.circle_anim:refresh(self.circle)
        self.anim:on_frame(1, function()
            self.counterable_component.timer = 18+2 -- Makes ElementMan counterable for 18+2 frames.
        end)
        self.anim:on_frame(4, function()
            local tile_x = 1
            if self:get_facing() == Direction.Left then
                tile_x = self:get_field():width()
            end
            local tile_y = nil
            if self:get_tile():y() <= 1 then
                tile_y = self:get_field():height()
            elseif self:get_tile():y() >= self:get_field():height() then
                tile_y = 1
            else
                if math.random(0,1) == 0 then
                    tile_y = 1
                else
                    tile_y = self:get_field():height()
                end
            end
            local tile = self:get_field():tile_at(tile_x,tile_y)
            debug_print("TILE: ("..tile_x..";"..tile_y..")")
            create_downburst(self, tile)
        end)
        self.anim:on_complete(function()
            self.idle_speed = 0
            increment_pattern(self)
        end)
    end
end

function tallesttree(self)
    if self.first_act then
        self.first_act = false
        self.anim:set_state("TALLESTTREE", {
            {duration=1, state="IDLE_1"},
            {duration=1, state="WARP_1"},
            {duration=1, state="WARP_2"},
            {duration=1, state="WARP_2"},
            {duration=1, state="WARP_1"},
            {duration=1, state="IDLE_1"},
            {duration=12, state="IDLE_1"},
            {duration=4, state="ATTACK_1"},
            {duration=14, state="ATTACK_2"},
            {duration=5, state="ATTACK_2"},
            {duration=3, state="ATTACK_3"},
            {duration=66, state="ATTACK_4"},
            {duration=2, state="IDLE_1"},
        })
        self.circle_anim:set_state("MOVE")
        self.circle_anim:refresh(self.circle)
        self.prev_tile = self:get_tile()
        local tile = choose_move_back(self, self:get_field())
        if not tile then
            self.idle_speed = self.base_idle_speed
            increment_pattern(self)
        else
            self.next_tile = tile
            self.next_tile:reserve_entity_by_id(self:get_id())
        end
        self.anim:on_frame(4, function()
            if self.can_move_to_func(self.next_tile) then 
                self:teleport(self.next_tile, ActionOrder.Voluntary)
            else
                self.idle_speed = 0
                increment_pattern(self)
            end
        end)
        self.anim:on_frame(7, function()
            -- Reset idle speed, since we did a real action
            self.idle_speed = self.base_idle_speed
            self.circle_anim:set_state("ATTACK1")
            self.circle_anim:refresh(self.circle)
            self.counterable_component.timer = 18+2 -- Makes ElementMan counterable for 18+2 frames.
        end)
        self.anim:on_frame(10, function()
            create_tallesttree(self, self:get_tile(self:get_facing(), 1))
        end)
        self.anim:on_complete(function()
            self.idle_speed = 0
            increment_pattern(self)
        end)
    end
end

function meteorite(self)
    if self.first_act then
        self.first_act = false
        local frames = {}
        frames[1] = {duration=12, state="IDLE_1"}
        frames[2] = {duration=4, state="ATTACK_1"}
        for i=2+1, 2+19, 1 do
            frames[i] = {duration=1, state="ATTACK_2"}
        end
        for i=2+19+1, 2+19+3, 1 do
            frames[i] = {duration=1, state="ATTACK_3"}
        end
        if self:get_health() < self:get_max_health()/2 then
            for i=2+19+3+1, 2+19+3+(6+(12*(self.meteorite_count_hp2-1))), 1 do
                frames[i] = {duration=1, state="ATTACK_4"}
            end
            frames[2+19+3+(6+(12*(self.meteorite_count_hp2-1)))+1] = {duration=2, state="IDLE_1"}
        else
            for i=2+19+3+1, 2+19+3+6+(12*(self.meteorite_count_hp1-1)), 1 do
                frames[i] = {duration=1, state="ATTACK_4"}
            end
            frames[2+19+3+(6+(12*(self.meteorite_count_hp1-1)))+1] = {duration=2, state="IDLE_1"}
        end
        self.anim:set_state("METEORITE", frames)
        self.circle_anim:set_state("ATTACK2_1")
        self.circle_anim:refresh(self.circle)
        self.anim:on_frame(1, function()
            self.counterable_component.timer = 18+2 -- Makes ElementMan counterable for 18+2 frames.
        end)
        for j=6, 66, 12 do
            self.anim:on_frame(2+j, function()
                local enemy_tile = self:get_field():find_nearest_characters(self, function(c)
                    return c and c:get_health() > 0 and not c:is_team(self:get_team())
                end)
                create_meteorite(self, enemy_tile[1]:get_tile())
            end)
        end
        if self:get_health() < self:get_max_health()/2 then
            for j=78, 114, 12 do
                self.anim:on_frame(2+j, function()
                    local enemy_tile = self:get_field():find_nearest_characters(self, function(c)
                        return c and c:get_health() > 0 and not c:is_team(self:get_team())
                    end)
                    create_meteorite(self, enemy_tile[1]:get_tile())
                end)
            end
        end
        if self:get_health() < self:get_max_health()/2 then
            self.anim:on_frame(2+19+3+(6+(12*(self.meteorite_count_hp2-1)))+1, function()
                self.circle_anim:set_state("ATTACK2_2")
                self.circle_anim:refresh(self.circle)
            end)
        else
            self.anim:on_frame(2+19+3+(6+(12*(self.meteorite_count_hp1-1)))+1, function()
                self.circle_anim:set_state("ATTACK2_2")
                self.circle_anim:refresh(self.circle)
            end)
        end
        self.anim:on_complete(function()
            self.idle_speed = 0
            increment_pattern(self)
        end)
    end
end

function lightningdrive(self)
    if self.first_act then
        self.first_act = false
        self.anim:set_state("LIGHTNINGDRIVE", {
            {duration=12, state="IDLE_1"},
            {duration=4, state="ATTACK_1"},
            {duration=4, state="ATTACK_2"},
            {duration=15, state="ATTACK_2"},
            {duration=3, state="ATTACK_3"},
            {duration=38, state="ATTACK_4"},
            {duration=2, state="IDLE_1"},
        })
        self.circle_anim:set_state("ATTACK3")
        self.circle_anim:refresh(self.circle)
        self.anim:on_frame(1, function()
            self.counterable_component.timer = 18+2 -- Makes ElementMan counterable for 18+2 frames.
        end)
        self.anim:on_frame(4, function()
            for i=1, self:get_field():width() do
                local target_tile = self:get_tile(self:get_facing(), i)
                if target_tile and target_tile:get_team() ~= self:get_team() and target_tile:get_tile(self:get_facing_away(), 1):get_team() == self:get_team() then
                    create_lightningdrive_spawner(self, target_tile)
                    break
                end
            end
        end)
        self.anim:on_complete(function()
            self.idle_speed = 0
            increment_pattern(self)
        end)
    end
end

function diamonddust(self)
    if self.first_act then
        self.first_act = false
        self.anim:set_state("DIAMONDDUST", {
            {duration=1, state="IDLE_1"},
            {duration=1, state="WARP_1"},
            {duration=1, state="WARP_2"},
            {duration=1, state="WARP_2"},
            {duration=1, state="WARP_1"},
            {duration=1, state="IDLE_1"},

            {duration=12, state="IDLE_1"},
            {duration=4, state="ATTACK_1"},
            {duration=3, state="ATTACK_2"},
            {duration=12, state="ATTACK_2"},
            {duration=4, state="ATTACK_2"},
            {duration=3, state="ATTACK_3"},
            {duration=53, state="ATTACK_4"},

            {duration=1, state="WARP_2"},
            {duration=1, state="WARP_1"},
            {duration=12, state="IDLE_1"},
        })
        self.circle_anim:set_state("MOVE")
        self.circle_anim:refresh(self.circle)
        self.moving_to_enemy_tile = true
        self.prev_tile = self:get_tile()
        self.original_tile = self.prev_tile
        local tile = choose_move_to_enemy(self, self:get_field())
        if not tile then
            self.moving_to_enemy_tile = false
            self.idle_speed = self.base_idle_speed
            increment_pattern(self)
        else
            self.next_tile = tile
            self.next_tile:reserve_entity_by_id(self:get_id())
        end
        self.anim:on_frame(4, function()
            if self.can_move_to_func(self.next_tile) then
                self:teleport(self.next_tile, ActionOrder.Voluntary)
            else
                self.moving_to_enemy_tile = false
                self.idle_speed = 0
                increment_pattern(self)
            end
        end)
        self.anim:on_frame(5, function()
            self.original_tile:reserve_entity_by_id(self:get_id())
        end)
        self.anim:on_frame(7, function()
            -- Reset idle speed, since we did a real action
            self.idle_speed = self.base_idle_speed
            self.circle_anim:set_state("ATTACK4")
            self.circle_anim:refresh(self.circle)
        end)
        self.anim:on_frame(10, function()
            local list = 
            {
                [1] = self:get_tile(Direction.join(self:get_facing(), Direction.Up), 1),
                [2] = self:get_tile(self:get_facing(), 1),
                [3] = self:get_tile(Direction.join(self:get_facing(), Direction.Down), 1)
            }
            highlight_tiles(self, list, 12, Highlight.Flash)
        end)
        self.anim:on_frame(11, function()
            self.counterable_component.timer = 18+2 -- Makes ElementMan counterable for 18+2 frames.
            create_diamonddust(self)
        end)
        self.anim:on_frame(14, function()
            self.circle_anim:set_state("MOVE2")
            self.circle_anim:refresh(self.circle)
            self:teleport(self.original_tile, ActionOrder.Immediate)
            self.original_tile = nil
        end)
        self.anim:on_complete(function()
            self.moving_to_enemy_tile = false
            self.idle_speed = 0
            increment_pattern(self)
        end)
    end
end

function element_change(self)
    if self.first_act then
        self.first_act = false
        self.anim:set_state("ELEMCHNG", {
            {duration=12, state="IDLE_1"},
            {duration=4, state="ATTACK_1"},
            {duration=4, state="ATTACK_2"},
            {duration=22, state="ATTACK_2"},
            {duration=10, state="ATTACK_2"},
            --{duration=2, state="IDLE_1"},
        })
        self.circle_anim:set_state("ELEMCHNG")
        self.circle_anim:refresh(self.circle)
        self.anim:on_frame(1, function()
            --self.counterable_component.timer = 18+2 -- Makes ElementMan counterable for 18+2 frames.
        end)
        self.anim:on_frame(4, function()
			Engine.play_audio(SHINE_AUDIO, AudioPriority.Low)
            local shine_fx = graphic_init("artifact", 0, -16*2, SHINE_TEXTURE, SHINE_ANIMPATH, "0", Playback.Once, -99, self, self:get_facing())
            shine_fx:get_animation():on_complete(function() shine_fx:erase() end)
            self:get_field():spawn(shine_fx, self:get_tile())
        end)
        self.anim:on_frame(5, function()
            self.whitening = true
        end)
        self.anim:on_complete(function()
            self.whitening = false
            self.elem_table_index = self.elem_table_index + 1
            if self.elem_table_index > #self.elem_table then self.elem_table_index = 1 end
            if self.elem_table_index == 1 then
                self:set_palette(self:get_base_palette())
            else
                self:set_palette(Engine.load_texture(_folderpath.."gfx/palette/palette-"..self.elem_table_index..".png"))
            end
            self:set_element(self.elem_table[self.elem_table_index])
            self.idle_speed = 0
            increment_pattern(self)
        end)
    end
    if self.whitening then
        debug_print("WHITENING")
        self:sprite():set_color_mode(ColorMode.Additive)
        self:sprite():set_color(Color.new(255,255,255,255))
    end
end

--(Function by Alrysc)
function find_valid_move_location(self)
	local target_tile
	local field = self:get_field()

	local tiles = field:find_tiles(function(tile)
		return self.can_move_to_func(tile)
	end)
  
	--print (#tiles)
	if #tiles >= 1 then
		target_tile = tiles[math.random(#tiles)]
	else
		target_tile = self:get_tile()
	end
	
	local start_tile = self:get_tile()
	if #tiles > 1 then
		while target_tile == start_tile do
		-- pick another, don't try to jump on the same tile if it's not necessary
		target_tile = tiles[math.random(#tiles)]
		end
	end
  
    return target_tile
end

function choose_enemy(self, field)
    local team = self:get_team()

    local target = field:find_characters(function(c)
        return c:get_health() > 0 and c:get_team() ~= team
    end)

    if not target[1] then 
        --print("No targets")
        return nil
    end

    t_x = target[1]:get_tile():x()
    t_y = target[1]:get_tile():y()

    local facing = -1
    if self:get_facing() == Direction.Left then 
        facing = 1
    end

    local tile = field:tile_at(t_x+facing, t_y)

    return tile
end

function choose_move(self, field)
    local team = self:get_team()

    local tiles = field:find_tiles(function(tile)
        return tile ~= self:get_tile() and self.can_move_to_func(tile)
    end)

    --print("Found ", #tiles, " possible tiles")

    if #tiles == 0 then 
        return self:get_tile()
    end

    return tiles[math.random(1, #tiles)]
end

function choose_move_back(self, field)
    local facing = self:get_facing()
    local team = self:get_team()

    local start_x = 1
    if facing == Direction.Left then
        start_x = field:width()
    end

    local tiles = field:find_tiles(function(tile)
        return tile:x() == start_x and self.can_move_to_func(tile)
    end)

    --print("Found ", #tiles, " possible tiles")

    if #tiles == 0 then 
        return nil
    end

    return tiles[math.random(1, #tiles)]
end

function choose_move_to_enemy(self, field)
    local team = self:get_team()

    local enemy_tile = choose_enemy(self, field)
    if enemy_tile ~= nil and self.can_move_to_func(enemy_tile) then
        --print("Found possible tile")
        return enemy_tile
    else
        return nil
    end
end

function reconstruct_pattern(self)
    local pattern = {}
    local states = self.states

    if self.first_move then
        self.first_move = false
        for i=1, self.moves_count do
            table.insert(pattern, states.idle)
            table.insert(pattern, states.move)
        end
    end
    table.insert(pattern, states.idle)
    table.insert(pattern, states.downburst)
    if self:get_element() == Element.Wood then
        table.insert(pattern, states.tallesttree)
    elseif self:get_element() == Element.Fire then
        table.insert(pattern, states.meteorite)
    elseif self:get_element() == Element.Elec then
        table.insert(pattern, states.lightningdrive)
    elseif self:get_element() == Element.Aqua then
        table.insert(pattern, states.diamonddust)
    else
        table.insert(pattern, states.downburst)
    end
    for i=1, self.moves_count do
        table.insert(pattern, states.move)
        table.insert(pattern, states.idle)
    end
    table.insert(pattern, states.downburst)
    for i=1, self.moves_count do
        table.insert(pattern, states.move)
        table.insert(pattern, states.idle)
    end
    table.insert(pattern, states.element_change)

    self.pattern = pattern
end

function increment_pattern(self)
    debug_print("Pattern increment")
    self.first_act = true
    self.whitening = false
    self.state_done = false
    self.pattern_index = self.pattern_index + 1
    if self.pattern_index > #self.pattern then 
        reconstruct_pattern(self)
        debug_print("Reconstructed pattern")
        self.pattern_index = 1
    end
    local next_state = self.pattern[self.pattern_index]
    self.state = next_state
    debug_print("Moving to state named ", next_state.name)
    if next_state == self.states.start_sub_pattern then 
        self.in_sub_pattern = true
        increment_pattern(self)
    end
    if next_state == self.states.finish_sub_pattern then 
        self.in_sub_pattern = false
        increment_pattern(self)
    end
    debug_print("Changing to "..self.pattern_index..", which is "..self.pattern[self.pattern_index].name)
end

function check_obstacles(tile, self)
    local ob = tile:find_obstacles(function(o)
        return o:get_health() > 0 
    end)
    return #ob > 0 
end

function check_characters(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_id() ~= self:get_id() and c:get_team() ~= self:get_team()
    end)
    return #characters > 0
end

function check_characters_true(tile, self)
    local characters = tile:find_characters(function(c)
        return true
    end)
    return #characters > 0
end