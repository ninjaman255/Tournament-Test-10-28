local package_id = "com.OFC.mob.EXE45-036-StarMan1"
local character_id = "com.OFC.char.EXE45-036-StarMan1"

function package_requires_scripts()
    Engine.define_character(character_id, _modpath.."StarMan")
end

function package_init(package)
    package:declare_package_id(package_id)
    package:set_name("StarMan (EXE4.5)")
    package:set_description("Test fight with\nStarMan\nfrom Rockman EXE4.5")
    package:set_speed(1)
    package:set_attack(20)
    package:set_health(600)
    package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob)
    --[[
    local texPath = _modpath.."exe4-bg-townarea.png"
    local animPath = _modpath.."exe4-bg-townarea.animation"
    mob:set_background(texPath, animPath, 0.2, 0.19)
    mob:stream_music(_modpath.."exe4-bossbattle.ogg", 42253, 80548)
    ]]
    local texPath = _modpath.."exe45-bg-generic1-day.png"
    --local texPath = _modpath.."exe45-bg-generic1-night.png"
    local animPath = _modpath.."exe45-bg-generic1.animation"
    mob:set_background(texPath, animPath, 0.12, 0.06)
    mob:stream_music(_modpath.."exe45-tournament.ogg", 6738, 38901)
    mob:create_spawner(character_id, Rank.V1):spawn_at(5,2)
end  