local AUDIO_DAMAGE = Engine.load_audio(_folderpath.."EXE4_270.ogg")
local AUDIO_DAMAGE_OBS = Engine.load_audio(_folderpath.."EXE4_221.ogg")

local FIREMAN_TEXTURE = nil
local FIREMAN_ANIMPATH = _folderpath.."fireman.animation"
local FIREARM_TEXTURE = Engine.load_texture(_folderpath.."firearm.png")
local FIREARM_ANIMPATH = _folderpath.."firearm.animation"
local FIREARM_AUDIO = Engine.load_audio(_folderpath.."EXE4_303.ogg")
local FLAMETOWER_TEXTURE = Engine.load_texture(_folderpath.."flametower.png")
local FLAMETOWER_ANIMPATH = _folderpath.."flametower.animation"
local FLAMETOWER_AUDIO = Engine.load_audio(_folderpath.."EXE4_220.ogg")
local FIREBOMB_TEXTURE = Engine.load_texture(_folderpath.."firebomb.png")
local FIREBOMB_ANIMPATH = _folderpath.."firebomb.animation"
local EFFECT_TEXTURE = Engine.load_texture(_folderpath.."effect.png")
local EFFECT_ANIMPATH = _folderpath.."effect.animation"
local EXPLOSION_TEXTURE = Engine.load_texture(_folderpath.."explosion.png")
local EXPLOSION_ANIMPATH = _folderpath.."explosion.animation"
local EXPLOSION_AUDIO = Engine.load_audio(_folderpath.."EXE4_273.ogg")
local THROW_AUDIO = Engine.load_audio(_folderpath.."EXE4_150.ogg")
local SHADOW_TEXTURE = Engine.load_texture(_folderpath.."shadow.png")
local SHADOW_ANIMPATH = _folderpath.."shadow.animation"
local SMOKE_TEXTURE = Engine.load_texture(_folderpath.."smoke.png")
local SMOKE_ANIMPATH = _folderpath.."smoke.animation"

function package_init(self)
    FIREMAN_TEXTURE = Engine.load_texture(_modpath.."fireman.png")
    self:set_name("FireMan")
	local rank = self:get_rank()
    self.damage = 30
    self.damage_firearm = 30
    self.damage_flametower = 20
    self.damage_firebomb = 10
    self.flametower_target_frame = 22
    self.flinch_duration = 43
    self.move_count = 3

    self.next_tile = nil
    self.prev_tile = nil

    self.firearm_spawner = nil
    self.firearm1 = nil
    self.firearm2 = nil
    self.firearm3 = nil
    self.firearm4 = nil
    self.firearm5 = nil
    self.firearm6 = nil
    
    -- Will set to base_idle_speed normally, but go to *2 after an attack, and sometimes * 1 or * 0 after flinch
    self.base_idle_speed = 44

    -- Chance /16. I'm going to run these when the pattern is complete and when the flinch finishes, respectively
        -- These skips will be very implementation-specific, so don't use them as future references
    self.chance_to_move_twice = 2
    self.chance_to_move_four_times = 4 --has a change to move 4 times
    self.chance_to_skip_idle_after_flinch = 2
    self.chance_to_halve_idle_after_flinch = 3
    self.chance_to_move_to_enemy_row = 2

    if rank == Rank.V1 then
        self:set_health(400)
    elseif rank == Rank.V2 then
        self:set_name("FireManV")
        self:set_health(700)
        self.damage = 50
        self.damage_firearm = 50
        self.damage_flametower = 40
        self.damage_firebomb = 30
        self.flametower_target_frame = 20
        self.flinch_duration = 35
        self.base_idle_speed = 36
    elseif rank == Rank.V3 then
        self:set_name("FireManV")
        self:set_health(1000)
        self.damage = 90
        self.damage_firearm = 90
        self.damage_flametower = 80
        self.damage_firebomb = 50
        self.flametower_target_frame = 18
        self.flinch_duration = 27
        self.base_idle_speed = 28
    elseif rank == Rank.SP then
        self:set_health(1300)
        self.damage = 120
        self.damage_firearm = 120
        self.damage_flametower = 120
        self.damage_firebomb = 90
        self.flametower_target_frame = 16
        self.flinch_duration = 19
        self.base_idle_speed = 20
    elseif rank == Rank.NM then
        FIREMAN_TEXTURE = Engine.load_texture(_modpath.."firemands.png")
        self:set_health(1800)
        self.damage = 240
        self.damage_firearm = 240
        self.damage_flametower = 240
        self.damage_firebomb = 180
        self.flametower_target_frame = 14
        self.flinch_duration = 11
        self.base_idle_speed = 12
    end

    self.idle_speed = self.base_idle_speed 

    self:set_texture(FIREMAN_TEXTURE, true)

    self:set_height(62)
    self:set_explosion_behavior(3, 1, true)
    self:set_offset(0, 0)
	self:set_facing(Direction.Left)
	self:set_element(Element.Fire)
    self:share_tile(false)
	self:set_float_shoe(false)
	self:set_air_shoe(false)

    local anim = self:get_animation()
    anim:load(FIREMAN_ANIMPATH)

    self.anim = include("enemy_base_v1/entry.lua")
    anim = self.anim
    anim:set_owner(self)
    anim:set_state("IDLE", {
        {duration=4, state="IDLE_1"},
        {duration=4, state="IDLE_2"},
        {duration=4, state="IDLE_3"},
        {duration=4, state="IDLE_4"},
    })

    anim:set_playback(Playback.Loop)
    init_boss(self)

end

--(Function by Alrysc)
-- This is to fix something that happens because I'm a cheater
--[[
    The aggressor of an attack is held in the Context object. 
    ONB leaves this aggressor unset in the Entity's Context until a CardAction is used for the first time
    So I'll immediately force a CardAction that will hopefully end immediately and not get in the way, but also will fix this
    This probably goes horribly wrong if the enemy is spawned after the mob intro, but should be fine for now otherwise
]]
function fix_context(self)
    local action = Battle.CardAction.new(self, "IDLE_1")
    action.execute_func = function()
        action:end_action()
    end

    self:card_action_event(action, ActionOrder.Immediate)
end

--(Function by Alrysc)
function init_boss(self)
    self.on_spawn_func = function(self)
        fix_context(self)
        --[[
        self.before_battle_start_animater = Battle.Artifact.new()
        self:get_field():spawn(self.before_battle_start_animater, 7, 4)
        self.before_battle_start_animater.update_func = function()
            self.anim:tick_animation()
        end]]
    end

    self.battle_start_func = function(self)
        --self.before_battle_start_animater:delete()
    end

    -- Setting names here is just convenience if I want to print the state I'm in later
    self.states = {
        idle = {name = "idle", func = idle},
        move = {name = "move", func = move},
        move_to_enemy = {name = "move_to_enemy", func = move_to_enemy},
        flinch = {name = "flinch", func = flinch},
        
        start_sub_pattern = {name = "start_sub_pattern"},
        finish_sub_pattern = {name = "finish_sub_pattern"},

        firearm = {name = "firearm", func = firearm},
        flametower = {name = "flametower", func = flametower},
        firebomb = {name = "firebomb", func = firebomb},

        choose_attack = {name = "choose_attack", func = choose_attack}
    }
    
    local s = self.states

    reconstruct_pattern(self)
 
    self.pattern_index = 1
    self.in_sub_pattern = false

    self.first_act = true

    self.state_done = false

    self.state = self.pattern[1]

    self.first_flinch = true

    self.hit_func = function(from_stun)
      --  print("Hit func runs")
        self.flinching = false
        self.first_act = false
        self.state_done = false
        self.moving_to_enemy_tile = false
        if self.first_flinch then 
         --   self.state.cleanup
            self.last_state = self.state
       --     print("Hit! Set last state to ", self.state.name)
            if self.state ~= self.states.idle and self.state ~= self.states.move then 
               -- increment_pattern(self)
            end

            self.first_flinch = false
        end

        self.state = self.states.flinch

        -- This is unused for this boss
        if self.slide_component ~= nil then 
          --  print("Hit while moving.")
            self.slide_component:eject()
            self.slide_component = nil
            self:set_offset(0, 0)

            if self.slide_dest and self:get_current_tile() ~= self.slide_dest then 
            --    print("Hit before reaching destination.")
                self:get_current_tile():remove_entity_by_id(self:get_id())
                self.slide_dest:add_entity(self)
                self.slide_dest = nil
            end

        end

        flinch(self, from_stun)
    end

    self.delete_func = function(self)
        self.update_func = function(self)
            self:get_animation():set_state("STUN_1")
            self.state = self.states.flinch
        end
    end

    -- Unused for this boss
    self.moving_to_enemy_tile = false
    self.counter = 0
    self.collision_available = true

    self:register_status_callback(Hit.Stun, function() self.hit_func(true) end)
    self:register_status_callback(Hit.Flinch, self.hit_func)
    self:register_status_callback(Hit.Drag, self.hit_func)
    self:register_status_callback(Hit.Root, function() self.rooted = 120 end)

    -- Bring it back next build. For now, relying on the stun callback
    --[[
    self.on_countered = function(self)
        print("Countered")
        self:toggle_counter(false)
        self.hit_func(self)

    end
    --]]

    self.can_move_to_func = function(tile)
        if self.rooted > 0 then return false end
        if tile:is_edge() or not tile:is_walkable() then
            return false
        end
        if(tile:is_reserved({self:get_id()})) then
            return false
        end

        if not self.moving_to_enemy_tile and (tile:get_team() ~= self:get_team()) then
            return false
        end

        return not check_obstacles(tile, self) and not check_characters_true(tile, self)
    end

    self.rooted = 0
    self.update_func = function(self)
       -- print("     ", self.state.name, self:get_animation():get_state())
        if self.rooted > 0  then self.rooted = self.rooted - 1 end
        self.state.func(self)
        self.anim:tick_animation()

        -- When we tick animation, we may run increment_pattern. 
        -- The new state isn't run until next frame, so our anim state lasts one more frame when it finishes
        -- Calling our state one time to set things up will avoid this. Mostly sure this doesn't have major unintended consequences,
        -- especially as most state.func only set state and callbacks for frame 1
        -- Problem is, now I may have a frame 1 callback but I don't run it until next frame
        while self.first_act
        do
            self.state.func(self)
            self.anim:tick_animation()
        end
        check_collision(self)
    end
end

--(Function by Alrysc)
function create_collision_attack(self, tile)
    local spell = Battle.Spell.new(self:get_team())
   
    local hit_props = HitProps.new(
        self.damage,
        Hit.Impact | Hit.Flash | Hit.Flinch,
        self:get_element(), 
        self:get_context(), 
        Drag.None
    )

    spell:set_hit_props(hit_props)

    spell.update_func = function(self)
        tile:attack_entities(self)
        self:delete()
    end

    self:get_field():spawn(spell, tile)
end

--(Function by Alrysc)
-- TODO: When we get is_passthrough or something, check to see if target became flashing before 
    -- we are allowed to spawn another one. Don't want to instakill viruses
-- self.collision_available can do something related to that. Does nothing now
function check_collision(self)
    local t = self:get_current_tile()
    if self.collision_available and check_characters(t, self) then 
        create_collision_attack(self, t)
    end
end

--(Function by Alrysc)
function idle(self)
    if self.first_act then 
        -- This is an old check for when I extended idle time by doing two idle states in a row, when characters have an animated idle
            -- Not needed if I instead use a timer
        if self.anim:get_state() ~= "IDLE" then 
        --    print("Idle with ", self.idle_speed)
            self.anim:set_state("IDLE", {
                {duration=4, state="IDLE_1"},
                {duration=4, state="IDLE_2"},
                {duration=4, state="IDLE_3"},
                {duration=4, state="IDLE_4"},
            })    
        end

        self.anim:set_playback(Playback.Loop)
        self.counter = 0

        self.first_act = false
    end

    self.counter = self.counter + 1
    if self.counter >= self.idle_speed then
        -- Extra catch for after leaving attack. Attack will double idle speed once, so making sure to reset it after
        if self.idle_speed > self.base_idle_speed then 
            self.idle_speed = self.base_idle_speed
        end

        increment_pattern(self)
    end

    --self.looped = false
    --if self.state_done then 
       -- print("State done")
        
   -- end
end

--(Function by Alrysc)
function hit()
    

end

--(Function by Alrysc)
function end_sub_pattern(self)
    while(self.in_sub_pattern)
    do
        increment_pattern(self)
    end
end

--(Function by Alrysc)
function flinch(self, from_stun)
    -- print("Flinch played")
    if self.firearm_spawner then
        if not self.firearm_spawner:is_deleted() then
            self.firearm_spawner:erase()
            self.firearm_spawner = nil
        end
    end
    if self:get_current_tile() == self.next_tile then
        local orig_tile = self.next_tile
        self.next_tile:remove_entity_by_id(self:get_id())
        self.next_tile = orig_tile
        self.next_tile:add_entity(self)
        self.next_tile = nil
    elseif self:get_current_tile() == self.prev_tile then
        local orig_tile = self.prev_tile
        self.prev_tile:remove_entity_by_id(self:get_id())
        self.prev_tile = orig_tile
        self.prev_tile:add_entity(self)
        self.prev_tile = nil
    end
    if self.firearm1 then
        if not self.firearm1:is_deleted() then
            self.firearm1:erase()
            self.firearm1 = nil
        end
    end
    if self.firearm2 then
        if not self.firearm2:is_deleted() then
            self.firearm2:erase()
            self.firearm2 = nil
        end
    end
    if self.firearm3 then
        if not self.firearm3:is_deleted() then
            self.firearm3:erase()
            self.firearm3 = nil
        end
    end
    if self.firearm4 then
        if not self.firearm4:is_deleted() then
            self.firearm4:erase()
            self.firearm4 = nil
        end
    end
    if self.firearm5 then
        if not self.firearm5:is_deleted() then
            self.firearm5:erase()
            self.firearm5 = nil
        end
    end
    if self.firearm6 then
        if not self.firearm6:is_deleted() then
            self.firearm6:erase()
            self.firearm6 = nil
        end
    end
    -- print("I am flinching")
    if not self.flinching then 
        local frames = {}
        local flinch_time = self.flinch_duration
        if not from_stun then
            frames[1] = {duration=4, state="FLINCH_1"}
            frames[2] = {duration=2, state="FLINCH_2"}
            for i=1+2, flinch_time+1+2, 4 do
                frames[i] = {duration=2, state="FLINCH_3"}
            end
            for i=2+2, flinch_time+2+2, 4 do
                frames[i] = {duration=2, state="FLINCH_4"}
            end
            for i=3+2, flinch_time+3+2, 4 do
                frames[i] = {duration=2, state="FLINCH_5"}
            end
            for i=4+2, flinch_time+4+2, 4 do
                frames[i] = {duration=2, state="FLINCH_5"}
            end
            frames[6+flinch_time+1] = {duration=2, state="FLINCH_6"}
            frames[7+flinch_time+1] = {duration=4, state="FLINCH_7"}
            frames[8+flinch_time+1] = {duration=4, state="FLINCH_8"}
            frames[9+flinch_time+1] = {duration=2, state="FLINCH_9"}
        else
            frames[1] = {duration=0, state="STUN_1"}
        end

        self.anim:set_state("FLINCH", frames)

        self.anim:on_complete(function()
            -- If we didn't just attack, we want to make sure the idle speed is correct. This is also set in the actual idle, but just for extra measure.
                -- Shouldn't be necessary
            if self.idle_speed > self.base_idle_speed and self.pattern[self.pattern_index] ~= self.states.choose_attack then 
                self.idle_speed = self.base_idle_speed
            end

            local has_skipped = false
            if self.last_state == self.states.idle then 
            --      print("Attempt skip, because last state was idle")
                has_skipped = maybe_skip_after_flinch(self)
            end

            
--         print("I am done flinching")
        --   print("Anim done")
            self.flinching = false
            self.state_done = true
            self.first_flinch = true

        --    print("Done")
            self.state_done = false
            if self.last_state ~= self.states.idle and self.last_state ~= self.states.move then 
        --     print("Last state was not idle or move", self.last_state.name)
 
                increment_pattern(self)

            
            else--if not has_skipped then 
                -- If we were in idle or move, go back to it and try again
                    -- Unless we were in a sub pattern. Still end that.
            --   print("Last state was idle or move")

                if self.in_sub_pattern then 
                    end_sub_pattern(self)
                else
                    self.state = self.last_state
                    self.first_act = true
                end
            end

        end)

    end

    self.flinching = true
end

--(Function by Alrysc)
--[[
    Chance to skip idle or halve idle time, to call after flinching 
    This works by calling increment_pattern an extra time if and only if the last state was Idle
        Remember, last state is the state we will return to after flinching
        Some extra work will need to be done in the self.anim:on_complete of flinch if this is to work with sub patterns. This boss doesn't use them, so it was omitted
    
    Currently, the skip is implemented as setting idle time to 0
    
    A future choice for this function: after calling this function, self.state *may* increment, obsoleting our last state pointer. Returns true if this does happen
        There is a possible additional side effect that the idle time will instead be changed, in which case, last state is preserved and false is returned
]]
function maybe_skip_after_flinch(self)
    local chance_halve = self.chance_to_halve_idle_after_flinch
    local chance_skip = self.chance_to_skip_idle_after_flinch
    local max = chance_halve + chance_skip + (16 - chance_halve - chance_skip)

    local r = math.random(1, max)
    if r <= chance_halve then 
        self.idle_speed = math.floor(self.idle_speed / 2)
       -- print("We halved")
    elseif r <= (chance_skip + chance_halve) then 
       -- print("We skipped")
        self.idle_speed = 0
        return true
    end

    return false
end

--(Function by Alrysc)
function highlight_tiles(self, list, time)
    local spell = Battle.Spell.new(self:get_team())

    local ref = self
    spell.update_func = function(self)
        for i=1, #list do 
            local t = list[i]
            if t and not t:is_edge() then 
                t:highlight(Highlight.Solid)
            end
        end

        time = time - 1
        if time == 0 then 
            self:delete()
        end

        if self.flinching then 
            if spell and not spell:is_deleted() then 
                spell:delete()
            end
        end
    end

    self:get_field():spawn(spell, self:get_current_tile())

    return spell
end

--(Function by Alrysc)
function move(self)
    if self.first_act then 
        
        self.anim:set_state("MOVE", {
            {duration=1, state="WARP_1"},
            {duration=1, state="WARP_2"},
            {duration=1, state="WARP_3"},
            {duration=1, state="WARP_3"},
            {duration=1, state="WARP_2"},
            {duration=1, state="WARP_1"},
        })

        self.prev_tile = self:get_current_tile()
        local tile = choose_move(self, self:get_field())
        if not tile then
            tile = self:get_current_tile()
        end
        self.next_tile = tile
        self.next_tile:reserve_entity_by_id(self:get_id())
        self.anim:on_frame(4, function()
            if self.can_move_to_func(self.next_tile) then 
            else
                self.next_tile = self:get_current_tile()
            end

            self:teleport(self.next_tile, ActionOrder.Voluntary, nil)
        end)

        self.anim:on_complete(function()
            -- Reset idle speed, since we did a real action
            self.idle_speed = self.base_idle_speed
            increment_pattern(self)
        end)

        self.first_act = false
    end
end

function move_to_enemy(self)
    if self.first_act then 
        
        self.anim:set_state("MOVE_TO_ENEMY", {
            {duration=1, state="WARP_1"},
            {duration=1, state="WARP_2"},
            {duration=1, state="WARP_3"},
            {duration=1, state="WARP_3"},
            {duration=1, state="WARP_2"},
            {duration=1, state="WARP_1"},
        })

        self.prev_tile = self:get_current_tile()
        local tile = choose_move_to_enemy(self, self:get_field())
        if not tile then
            tile = choose_move(self, self:get_field())
        end
        if not tile then
            tile = self:get_current_tile()
        end
        self.next_tile = tile
        self.next_tile:reserve_entity_by_id(self:get_id())
        self.anim:on_frame(4, function()
            if self.can_move_to_func(self.next_tile) then 
            else
                self.next_tile = self:get_current_tile()
            end

            self:teleport(self.next_tile, ActionOrder.Voluntary, nil)
        end)

        self.anim:on_complete(function()
            -- Reset idle speed, since we did a real action
            self.idle_speed = self.base_idle_speed
            increment_pattern(self)
        end)

        self.first_act = false
    end
end

function choose_attack(self)
    local r = math.random(1, 3)
    local r2 = math.random(1, 2)
    local front_check = choose_enemy(self, self:get_field())
    if r == 1 then
        if self:get_current_tile():y() == front_check:y() then
            self.state = self.states.firearm
        else
            if r2 == 1 then
                self.state = self.states.flametower
            else
                self.state = self.states.firebomb
            end
        end
    elseif r == 2 then
        self.state = self.states.flametower
    elseif r == 3 then
        self.state = self.states.firebomb
    end

    self.state.func(self)
    self.idle_speed = self.base_idle_speed * 2
end

function firearm(self)
    if self.first_act then 
        self.anim:set_state("FIREARM", {
            {duration=12, state="FIREARM_1"},

            {duration=2, state="FIREARM_2"},
            {duration=2, state="FIREARM_3"},
            {duration=2, state="FIREARM_4"},
            {duration=2, state="FIREARM_5"},

            {duration=2, state="FIREARM_2"},
            {duration=2, state="FIREARM_3"},
            {duration=2, state="FIREARM_4"},
            {duration=2, state="FIREARM_5"},

            {duration=2, state="FIREARM_2"},
            {duration=2, state="FIREARM_3"},
            {duration=2, state="FIREARM_4"},
            {duration=2, state="FIREARM_5"},

            {duration=2, state="FIREARM_2"},
            {duration=2, state="FIREARM_3"},
            {duration=2, state="FIREARM_4"},
            {duration=2, state="FIREARM_5"},

            {duration=2, state="FIREARM_2"},
            {duration=2, state="FIREARM_3"},
            {duration=2, state="FIREARM_4"},
            {duration=2, state="FIREARM_5"},

            {duration=2, state="FIREARM_2"},
            {duration=2, state="FIREARM_3"},
            {duration=2, state="FIREARM_4"},
            {duration=2, state="FIREARM_5"},

            {duration=2, state="FIREARM_2"},
            {duration=2, state="FIREARM_3"},
            {duration=2, state="FIREARM_4"},
            {duration=2, state="FIREARM_5"},

            {duration=2, state="FIREARM_2"},
            {duration=2, state="FIREARM_3"},
            {duration=2, state="FIREARM_4"},
            {duration=2, state="FIREARM_5"},

            {duration=2, state="FIREARM_2"},
            {duration=2, state="FIREARM_3"},
            {duration=2, state="FIREARM_4"},
            {duration=2, state="FIREARM_5"},

            {duration=2, state="FIREARM_2"},
            {duration=2, state="FIREARM_3"},
            {duration=2, state="FIREARM_4"},
            {duration=2, state="FIREARM_5"},
        })    

        self.anim:on_frame(2, function()
            self.firearm_spawner = firearm_spawner(self, self:get_tile(self:get_facing(), 1))
        end)

        self.anim:on_complete(function()
            increment_pattern(self)
        end)

        self.first_act = false
    end
end

function flametower(self)
    if self.first_act then 
        self.anim:set_state("FLAMETOWER", {
            {duration=8, state="FLAMETOWER_1"},
            {duration=4, state="FLAMETOWER_2"},
            {duration=2, state="FLAMETOWER_3"},
            {duration=2, state="FLAMETOWER_4"},
            {duration=2, state="FLAMETOWER_5"},
            {duration=10, state="FLAMETOWER_6"},
        })    

        self.anim:on_frame(5, function()
            spawn_flametower(self, self:get_tile(self:get_facing(), 1))
        end)

        self.anim:on_complete(function()
            increment_pattern(self)
        end)

        self.first_act = false
    end
end

function firebomb(self)
    if self.first_act then 
        self.anim:set_state("FIREBOMB", {
            {duration=8, state="FIREBOMB_1"},
            {duration=4, state="FIREBOMB_2"},
            {duration=2, state="FIREBOMB_3"},
            {duration=2, state="FIREBOMB_4"},
            {duration=10, state="FIREBOMB_5"},
        })    

        self.anim:on_frame(3, function()
            Engine.play_audio(THROW_AUDIO, AudioPriority.Low)
        end)

        self.anim:on_frame(5, function()
            local frames_in_air = 40
            local toss_height = 90
            local target_tile = choose_enemy(self, self:get_field())
            if not target_tile then
                target_tile = self:get_tile(self:get_facing(), 3)
            end
            toss_spell(self, toss_height, frames_in_air, target_tile)
            toss_spell_shadow(self, toss_height, frames_in_air, target_tile)
            toss_spell_hitbox(self, toss_height, frames_in_air, target_tile)
        end)

        self.anim:on_complete(function()
            increment_pattern(self)
        end)

        self.first_act = false
    end
end

function toss_spell(tosser, toss_height, frames_in_air, target_tile)
    local starting_height = -110
    local start_tile = tosser:get_current_tile()
    local facing = tosser:get_facing()
    local field = tosser:get_field()
    local team = tosser:get_team()
    local spell = Battle.Spell.new(tosser:get_team())
    local spell_animation = spell:get_animation()
    spell_animation:load(FIREBOMB_ANIMPATH)
    spell_animation:set_state("0")
    spell_animation:set_playback(Playback.Loop)
    if tosser:get_height() > 1 then
        starting_height = -(tosser:get_height())
    end

    spell.jump_started = false
    spell.starting_y_offset = starting_height
    spell.starting_x_offset = 10
    if tosser:get_facing() == Direction.Left then
        spell.starting_x_offset = -10
    end
    spell.y_offset = spell.starting_y_offset
    spell.x_offset = spell.starting_x_offset
    local sprite = spell:sprite()
    sprite:set_texture(FIREBOMB_TEXTURE)
    spell:set_offset(spell.x_offset,spell.y_offset)

    spell.update_func = function(self)
        if not spell.jump_started then
            self:jump(target_tile, toss_height, frames(frames_in_air), frames(frames_in_air), ActionOrder.Voluntary)
            self.jump_started = true
        end
        if self.y_offset < 0 then
            self.y_offset = self.y_offset + math.abs(self.starting_y_offset/frames_in_air)
            self.x_offset = self.x_offset - math.abs(self.starting_x_offset/frames_in_air)
            self:set_offset(self.x_offset,self.y_offset)
        else
            on_landing(tosser, team, target_tile, facing, field)
            self:delete()
        end
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    field:spawn(spell, start_tile)
end

function toss_spell_shadow(tosser, toss_height, frames_in_air, target_tile)
    local starting_height = -110
    local start_tile = tosser:get_current_tile()
    local field = tosser:get_field()
    local spell = Battle.Spell.new(tosser:get_team())
    local spell_animation = spell:get_animation()
    spell_animation:load(SHADOW_ANIMPATH)
    spell_animation:set_state("0")
    if tosser:get_height() > 1 then
        starting_height = -(tosser:get_height())
    end

    spell.slide_started = false

    spell.jump_started = false
    spell.starting_y_offset = starting_height
    spell.starting_x_offset = 10
    if tosser:get_facing() == Direction.Left then
        spell.starting_x_offset = -10
    end
    spell.y_offset = spell.starting_y_offset
    spell.x_offset = spell.starting_x_offset
    local sprite = spell:sprite()
    sprite:set_texture(SHADOW_TEXTURE)
    spell:set_offset(spell.x_offset,0)

    spell.update_func = function(self)
        if not spell.jump_started then
            self:jump(target_tile, 0, frames(frames_in_air), frames(frames_in_air), ActionOrder.Voluntary)
            self.jump_started = true
        end
        if self.y_offset < 0 then
            self.y_offset = self.y_offset + math.abs(self.starting_y_offset/frames_in_air)
            self.x_offset = self.x_offset - math.abs(self.starting_x_offset/frames_in_air)
            self:set_offset(self.x_offset,0)
        else
            self:delete()
        end
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    field:spawn(spell, start_tile)
end

--Now can trigger Kakigenkin
function toss_spell_hitbox(tosser, toss_height, frames_in_air, target_tile)
    local starting_height = -110
    local start_tile = tosser:get_current_tile()
    local field = tosser:get_field()
    local spell = Battle.Spell.new(tosser:get_team())
    spell:set_hit_props(
        HitProps.new(
            tosser.damage_firebomb,
            Hit.Impact | Hit.Flinch | Hit.Flash,
            Element.Fire,
            tosser:get_id(),
            Drag.None
        )
    )
    spell.attacking = false
    local spell_animation = spell:get_animation()
    spell_animation:load(_folderpath.."attack.animation")
    spell_animation:set_state("1")
    spell_animation:set_playback_speed(0)
    spell_animation:on_frame(2, function()
        target_tile:set_state(TileState.Lava)
    end)
    spell_animation:on_complete(function()
		spell:erase()
	end)
    if tosser:get_height() > 1 then
        starting_height = -(tosser:get_height())
    end

    spell.slide_started = false

    spell.jump_started = false
    spell.starting_y_offset = starting_height
    spell.starting_x_offset = 10
    if tosser:get_facing() == Direction.Left then
        spell.starting_x_offset = -10
    end
    spell.y_offset = spell.starting_y_offset
    spell.x_offset = spell.starting_x_offset
    local sprite = spell:sprite()
    sprite:set_texture(SHADOW_TEXTURE)
    sprite:hide()
    spell:set_offset(spell.x_offset,spell.y_offset)

    spell.update_func = function(self)
        if self.attacking then
            self:get_current_tile():attack_entities(self)
            target_tile:highlight(Highlight.None)
        else
            target_tile:highlight(Highlight.Flash)
        end
        if not spell.jump_started then
            self:jump(target_tile, 0, frames(frames_in_air), frames(frames_in_air), ActionOrder.Voluntary)
            self.jump_started = true
        end
        if self.y_offset < 0 then
            self.y_offset = self.y_offset + math.abs(self.starting_y_offset/frames_in_air)
            self.x_offset = self.x_offset - math.abs(self.starting_x_offset/frames_in_air)
            self:set_offset(self.x_offset,self.y_offset)
        else
            spell_animation:set_playback_speed(1)
            self.attacking = true
            --self:delete()
        end
    end
    spell.attack_func = function(self, ent)
        if Battle.Obstacle.from(ent) == nil then
            --[[
            if Battle.Player.from(user) ~= nil then
                Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Low)
            end
            ]]
        else
            Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
        end
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    field:spawn(spell, start_tile)
end

function on_landing(user, team, target_tile, facing, field)
    if target_tile:is_walkable() then
        local explosion = create_effect(facing, EXPLOSION_TEXTURE, EXPLOSION_ANIMPATH, "0", 0.0, -((3.0)*2), true, -9, field, target_tile)
        local explosion_anim = explosion:get_animation()
        explosion_anim:on_frame(1, function()
            Engine.play_audio(EXPLOSION_AUDIO, AudioPriority.Low)
        end)
    else
        create_effect(facing, SMOKE_TEXTURE, SMOKE_ANIMPATH, "0", 0.0, -((3.0)*2), true, -9, field, target_tile)
    end
end

function find_target(self)
    local field = self:get_field()
    local team = self:get_team()
    local target_list = field:find_characters(function(other_character)
        return other_character:get_team() ~= team
    end)
    local target_character = nil
    if #target_list > 0 then
        target_character = target_list[1]
    else
        target_character = self:get_current_tile()
    end
    return target_character;
end

function getNextTile(direction, spell)
    local tile = spell:get_current_tile():get_tile(direction, 1)
    local target_movement_tile = tile
    local target_character = find_target(spell)
    local target_character_tile = target_character:get_current_tile()
    if tile:y() < target_character_tile:y() then
        target_movement_tile = tile:get_tile(Direction.Down,1)
    end
    if tile:y() > target_character_tile:y() then
        target_movement_tile = tile:get_tile(Direction.Up,1)
    end
    return target_movement_tile;
end

function spawn_flametower(user, tile)
    local spawn_next
    spawn_next = function()
        if not tile:is_walkable() then return end

        local team = user:get_team()
        local field = user:get_field()
        local facing = user:get_facing()

        local spell = Battle.Spell.new(team)
        spell:set_facing(facing)
        spell:never_flip(true)
        spell:set_hit_props(HitProps.new(
            user.damage_flametower, 
            Hit.Impact | Hit.Flinch | Hit.Flash, 
            Element.Fire, 
            user:get_id(), 
            Drag.None)
        )
        spell.attacking = false
        spell.spawn_next = true
        local sprite = spell:sprite()
        sprite:set_texture(FLAMETOWER_TEXTURE)
        sprite:set_layer(-3)
        local animation = spell:get_animation()
        animation:load(FLAMETOWER_ANIMPATH)
        animation:set_state("DEFAULT")
        animation:refresh(sprite)
        local queryTeam = function(ent)
			if not user:is_team(ent:get_team()) then
				return true
			end
		end
        local queryCO = function(ent)
	    	return Battle.Character.from(ent) ~= nil or Battle.Obstacle.from(ent) ~= nil
	    end
        local queryHP = function(ent)
            if ent:get_health() > 0 then
                return true
            end
        end
        local query_TeamHP = function(ent)
            if not user:is_team(ent:get_team()) and ent:get_health() > 0 then
                return true
            end
        end
        local next_tile = nil
        animation:on_frame(2, function()
            spell.attacking = true
        end)
        animation:on_frame(user.flametower_target_frame, function() --old: 16 - new 14, 16, 18, 20, 22
            next_tile = getNextTile(facing, spell)
        end)
        animation:on_frame(user.flametower_target_frame+6, function() --old: 22 - new 20, 22, 24, 26, 28
            tile = next_tile
            --[[if spell:get_current_tile():find_characters(query) <= 0 then
                spawn_next()
            end]]
            if spell.spawn_next then
                spawn_next()
            end
        end, true)
        animation:on_complete(function() 
            spell:erase()
        end)

        spell.on_spawn_func = function(self)
            Engine.play_audio(FLAMETOWER_AUDIO, AudioPriority.Low)
        end

        spell.update_func = function(self)
            local self_tile = self:get_current_tile()
            local ref = self
            if ref.attacking then
                self_tile:attack_entities(self)
                spell:highlight_tile(Highlight.Solid)
            end
            if ref.spawn_next then
                if #self_tile:find_characters(query_TeamHP) > 0 then
                    ref.spawn_next = false
                end
            end
            if self_tile ~= nil and
                not self_tile:is_edge() and
                #self_tile:find_characters(query_TeamHP) <= 0 and 
                #self_tile:find_obstacles(query_TeamHP) <= 0 and 
                self_tile:get_state() == TileState.Grass
                then
                self_tile:set_state(TileState.Normal)
            end
        end

        spell.attack_func = function(self, ent)
	    	--print("FlameTower attacked tile ("..ent:get_current_tile():x()..";"..ent:get_current_tile():y()..")")
            create_effect(facing, EFFECT_TEXTURE, EFFECT_ANIMPATH, "2", math.random(-30,30), math.random(-50,-30), true, -999999, field, ent:get_current_tile())
            if Battle.Obstacle.from(ent) == nil then
                --[[
                if Battle.Player.from(user) ~= nil then
                    Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Low)
                end
                ]]
            else
                Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
            end
        end
        
        spell.battle_end_func = function(self)
            self:erase()
        end

        spell.can_move_to_func = function(tile)
            return true
        end

        field:spawn(spell, tile)

        --print("FlameTower spawned at tile: ("..tile:x()..";"..tile:y()..")")
    end

    spawn_next()
end

function firearm_spawner(user, tile)
    local team = user:get_team()
    local field = user:get_field()
    local facing = user:get_facing()

    local spawner = Battle.Artifact.new()
    local anim = spawner:get_animation()
    anim:load(_folderpath.."attack.animation")
	anim:set_state("2")
    --[[
    for i = 1, 6, 1 do
        anim:on_frame(i, function()
            create_firearm(user, team, facing, field, spawner:get_tile(facing, i-1))
        end)
    end
    ]]
    anim:on_frame(1, function()
        user.firearm1 = create_firearm(user, team, facing, field, spawner:get_tile(facing, 0))
    end)
    anim:on_frame(2, function()
        user.firearm2 = create_firearm(user, team, facing, field, spawner:get_tile(facing, 1))
    end)
    anim:on_frame(3, function()
        user.firearm3 = create_firearm(user, team, facing, field, spawner:get_tile(facing, 2))
    end)
    anim:on_frame(4, function()
        user.firearm4 = create_firearm(user, team, facing, field, spawner:get_tile(facing, 3))
    end)
    anim:on_frame(5, function()
        user.firearm5 = create_firearm(user, team, facing, field, spawner:get_tile(facing, 4))
    end)
    anim:on_frame(6, function()
        user.firearm6 = create_firearm(user, team, facing, field, spawner:get_tile(facing, 5))
    end)
    for i = 1, 21, 4 do
        anim:on_frame(i, function()
            Engine.play_audio(FIREARM_AUDIO, AudioPriority.Highest)
        end)
    end
    anim:on_complete(function() spawner:delete() end)
    spawner.battle_end_func = function(self)
        self:delete()
    end
    spawner.delete_func = function(self)
        self:erase()
    end
    field:spawn(spawner, tile)
end

function create_firearm(user, team, facing, field, tile)
    local firearm
    firearm = function()
        if tile == nil or tile:is_edge() then return end

        local spell = Battle.Spell.new(team)
        spell:set_hit_props(
            HitProps.new(
                user.damage_firearm,
                Hit.Impact | Hit.Flinch | Hit.Flash,
                Element.Fire,
                user:get_id(),
                Drag.None
            )
        )
        spell:set_offset(0, 2.0*2)
        spell:set_facing(facing)
        spell:highlight_tile(Highlight.Solid)
        local sprite = spell:sprite()
        sprite:set_texture(FIREARM_TEXTURE, true)
	    sprite:set_layer(-3)
        local anim = spell:get_animation()
	    anim:load(FIREARM_ANIMPATH)
	    anim:set_state("0")
        anim:on_complete(function() spell:delete() end)

        local query_TeamHP = function(ent)
            if not user:is_team(ent:get_team()) and ent:get_health() > 0 then
                return true
            end
        end

        spell.update_func = function(self)
            local self_tile = self:get_current_tile()
            self_tile:attack_entities(self)
            if self_tile ~= nil and
                not self_tile:is_edge() and
                #self_tile:find_characters(query_TeamHP) <= 0 and 
                #self_tile:find_obstacles(query_TeamHP) <= 0 and 
                self_tile:get_state() == TileState.Grass
                then
                self_tile:set_state(TileState.Normal)
            end
        end

	    spell.collision_func = function(self, other)
	    end

	    spell.can_move_to_func = function(self, other)
	    	return true
	    end

	    spell.battle_end_func = function(self)
	    	self:delete()
	    end

        spell.delete_func = function(self)
	    	self:erase()
	    end

        spell.attack_func = function(self, ent)
	    	--print("FireArm attacked tile ("..ent:get_current_tile():x()..";"..ent:get_current_tile():y()..")")
            create_effect(facing, EFFECT_TEXTURE, EFFECT_ANIMPATH, "2", math.random(-30,30), math.random(-50,-30), true, -999999, field, ent:get_current_tile())
            if Battle.Obstacle.from(ent) == nil then
                --[[
                if Battle.Player.from(user) ~= nil then
                    Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Low)
                end
                ]]
            else
                Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
            end
        end

        field:spawn(spell, tile)

        --print("FireArm spawned at tile: ("..tile:x()..";"..tile:y()..")")
    end
	
    firearm()
end

--(Function by Alrysc)
function find_valid_move_location(self)
	local target_tile
	local field = self:get_field()

	local tiles = field:find_tiles(function(tile)
		return self.can_move_to_func(tile)
	end)
  
	--print (#tiles)
	if #tiles >= 1 then
		target_tile = tiles[math.random(#tiles)]
	else
		target_tile = self:get_tile()
	end
	
	local start_tile = self:get_tile()
	if #tiles > 1 then
		while target_tile == start_tile do
		-- pick another, don't try to jump on the same tile if it's not necessary
		target_tile = tiles[math.random(#tiles)]
		end
	end
  
    return target_tile
end

function front_enemy_check(self)
    local facing = self:get_facing()
    local field = self:get_field()
    local team = self:get_team()

    local function query(c)
        return c:get_team() ~= team
    end

    for i = 1, 5, 1 do
        local target_tile = self:get_tile(facing, i)
        if target_tile ~= nil and #target_tile:find_characters(query) > 0 then
            --print("front TRUE")
            return true
        else
            --print("front FALSE")
            return false
        end
    end
end

function choose_enemy(self, field)
    local team = self:get_team()

    local target = field:find_characters(function(c)
        return c:get_team() ~= team
    end)

    if not target[1] then 
       -- print("No targets")
        return nil
    end

    t_x = target[1]:get_current_tile():x()
    t_y = target[1]:get_current_tile():y()

    local facing = -1
    if target[1]:get_facing() == Direction.Right then 
        facing = 1
    end

    local tile = field:tile_at(t_x, t_y)

    return tile
end

function choose_move(self, field)
    local team = self:get_team()

    local tiles = field:find_tiles(function(tile)
        return tile ~= self:get_current_tile() and self.can_move_to_func(tile)
    end)

    --print("Found ", #tiles, " possible tiles")

    if #tiles == 0 then 
        return self:get_current_tile()
    end

    return tiles[math.random(1, #tiles)]
end

function choose_move_to_enemy(self, field)
    local team = self:get_team()

    local enemy_tile = choose_enemy(self, field)
    local enemy_y = enemy_tile:y()

    local tiles = field:find_tiles(function(tile)
        return tile ~= self:get_current_tile() and self.can_move_to_func(tile) and tile:y() == enemy_y
    end)

    --print("Found ", #tiles, " possible tiles")

    if #tiles == 0 then 
        return self:get_current_tile()
    end

    return tiles[math.random(1, #tiles)]
end

function reconstruct_pattern(self)
    local pattern = {}
    local states = self.states
    local moves = self.move_count
    local r = math.random(1, 16)
    local r2 = math.random(1, 8)
    --print(r)
    if r <= self.chance_to_move_twice then
        moves = 2
        --print("Two moves this time")
    elseif r > self.chance_to_move_twice and r <= self.chance_to_move_four_times then
        moves = 4
        --print("Four moves this time")
    end

    for i=1, moves do
        if i ~= moves then
            table.insert(pattern, states.idle)
            table.insert(pattern, states.move)
        else
            if r2 <= self.chance_to_move_to_enemy_row then
                table.insert(pattern, states.idle)
                table.insert(pattern, states.move_to_enemy)
            else
                table.insert(pattern, states.idle)
                table.insert(pattern, states.move)
            end
        end
    end

    table.insert(pattern, states.idle)
    table.insert(pattern, states.choose_attack)

    self.pattern = pattern
end

function increment_pattern(self)
   -- print("Pattern increment")

    self.first_act = true
    self.state_done = false
    self.pattern_index = self.pattern_index + 1
    if self.pattern_index > #self.pattern then 
        reconstruct_pattern(self)
 --       print("Reconstructed pattern")
        self.pattern_index = 1
    end

    local next_state = self.pattern[self.pattern_index]
    self.state = next_state
  --  print("Moving to state named ", next_state.name)

    if next_state == self.states.start_sub_pattern then 
        self.in_sub_pattern = true
        increment_pattern(self)
    end

    if next_state == self.states.finish_sub_pattern then 
        self.in_sub_pattern = false
        increment_pattern(self)

    end

   -- print("Changing to "..self.pattern_index..", which is "..self.pattern[self.pattern_index].name)

end

function check_obstacles(tile, self)
    local ob = tile:find_obstacles(function(o)
        return o:get_health() > 0 
    end)

    return #ob > 0 
end

function check_characters(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_id() ~= self:get_id() and c:get_team() ~= self:get_team()
    end)

    return #characters > 0

end

function check_characters_true(tile, self)
    local characters = tile:find_characters(function(c)
        return true
    end)

    return #characters > 0
end

function create_effect(effect_facing, effect_texture, effect_animpath, effect_state, offset_x, offset_y, flip, offset_layer, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(effect_facing)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    hitfx:never_flip(flip)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(offset_layer)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end