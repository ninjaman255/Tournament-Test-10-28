local HATMAN_TEXTURE = nil
local HATMAN_ANIMATION = nil
local SHADOW_TEXTURE = Engine.load_texture(_folderpath.."shadow.png")


local MOVE_TEXTURE = Engine.load_texture(_folderpath.."move.png")
local MOVE_ANIMATION =  _folderpath.."move.animation"
local HIT_EFFECT_TEXTURE = Engine.load_texture(_folderpath.."hit_effects.png")
local HIT_EFFECT_ANIMATION = _folderpath.."hit_effects.animation"

local EFFECTS_TEXTURE = Engine.load_texture(_folderpath.."effects.png")
local EFFECTS_ANIMATION = _folderpath.."effects.animation"

local SLASHES_TEXTURE = Engine.load_texture(_folderpath.."slashes.png")
local SLASHES_ANIMATION = _folderpath.."slashes.animation"

local BOOM_TEXTURE = Engine.load_texture(_folderpath.."boom.png")
local BOOM_ANIMPATH = _folderpath.."boom.animation"

local HIT_SFX = Engine.load_audio(_folderpath.."hit.ogg")
local SWORD_SFX = Engine.load_audio(_folderpath.."sword.ogg")
local THROW_SFX = Engine.load_audio(_folderpath.."EXE4_6.ogg")
local BIRD_FLY_SFX = Engine.load_audio(_folderpath.."EXE4_59-blackwing.ogg")
local BIRD_DIVE_SFX = Engine.load_audio(_folderpath.."bird_dive.ogg")
local APPEAR_SFX = Engine.load_audio(_folderpath.."appear.ogg")
local BOOM_SFX = Engine.load_audio(_folderpath.."EXE4_273.ogg")


--[[
    Behavior overview:
    (Frame numbers counted from videos, so have a margin of error. Also, the game runs at like 30 FPS, so I'll double these values for ONB to be a similar speed)

    Wait 48f before moving
    Move 3 times before attacking
        Sometimes see 2 moves, sometimes see instant move with no wait
            I have to take some liberties here. May decide on a move count that will normally be 3, but may be 2 (increase odds at low HP)
                May decide to move instantly after being flinched, or decrease idle time by some amount (saw 19f after flinch at some point)
    After attacking, 78f instead
        But if the attack was the hat one, wait 116f
    Flinch lasts ~78, animates as shaking back and forth (offset 0, offset X, offset 2X, offset 0, repeat, step every 2f)
    
    Has 3 attacks, sorta:

    Rose hand
        Spawn hand holding a rose in front of the target. Throws the rose at a speed of 4f per tile
            !!! Spends 4f on a tile, so move speed, if sliding, should probably be double that.

    Sword hand
        Spawn hand holding a sword in front of te target. Attacks with a WideSword

    Hat
        Places a hat on the tile in front of him.
        Hat has 80 HP.
        Every 230f, shoots a bird

        Unless he uses the hat attack again while there are two hats out.
        This forces the hats to shoot birds in sequence for a bit.
]]
-- TODO: Kirby would want me to delete things when HatMan is deleted. The hats already do, but check out the hands and stuff
function package_init(self)
    HATMAN_TEXTURE = Engine.load_texture(_modpath.."hatman.png")
    HATMAN_ANIMATION = _folderpath.."hatman.animation"
    self:set_name("HatMan")
	local rank = self:get_rank()
    

   
    
    self.max_health = 800
    self.hat_health = 80

    self.damage_rose = 40
    self.damage_sword = 40
    self.damage_bird = 60

    -- Will set to base_idle_speed normally, but go to *2 after an attack, and sometimes * 1 or * 0 after flinch
    self.base_idle_speed = 48
    self.idle_speed_after_attack = 78
    self.idle_speed_after_hat = 116

    self.base_hat_delay = 230

    self.hats = {}


    self.flinch_duration = 78/2 
    self.move_count = 3
    
    
    self.shot_speed = 4

    -- Chance /16. I'm going to run these when the pattern is complete and when the flinch finishes, respectively
        -- These skips will be very implementation-specific, so don't use them as future references
    self.chance_to_move_twice = 2
    self.chance_to_skip_idle_after_flinch = 2
    self.chance_to_halve_idle_after_flinch = 3 


	if rank == Rank.V2 then
        self:set_name("HatManV")
		self.max_health = 1000
        self.hat_health = 100

        self.damage_rose = 70
        self.damage_sword = 70
        self.damage_bird = 80
        

        self.base_idle_speed = 40
        self.idle_speed_after_attack = 64
        self.idle_speed_after_hat = 100
        
    elseif rank == Rank.V3 then 
        self:set_name("HatManV")
        self.max_health = 1200
        self.hat_health = 120

        self.base_idle_speed = 34
        self.idle_speed_after_attack = 48
        self.idle_speed_after_hat = 84

        self.damage_rose = 80
        self.damage_sword = 80
        self.damage_bird = 100

    elseif rank == Rank.SP then 
        self.max_health = 1500
        self.hat_health = 130

        self.damage_rose = 129
        self.damage_sword = 120
        self.damage_bird = 100

        self.base_idle_speed = 26
        self.idle_speed_after_attack = 34
        self.idle_speed_after_hat = 72
    end

    self.idle_speed = self.base_idle_speed 
    self.damage = self.damage_rose
	self:set_element(Element.None)
    self:set_texture(HATMAN_TEXTURE, true)
    self:set_height(60)
    self:share_tile(false)
    self:set_health(self.max_health)
    self:set_explosion_behavior(8, 8, true)


    local anim = self:get_animation()
    anim:load(HATMAN_ANIMATION)

    self.anim = include("enemy_base_v1/entry.lua")
    anim = self.anim
    anim:set_owner(self)
    anim:set_state("IDLE", {
        {duration=8, state="IDLE_1"},
        {duration=8, state="IDLE_2"},
        {duration=8, state="IDLE_3"},
        {duration=8, state="IDLE_2"},

    })

    anim:set_playback(Playback.Loop)

    init_boss(self)

end

-- This is to fix something that happens because I'm a cheater
--[[
    The aggressor of an attack is held in the Context object. 
    ONB leaves this aggressor unset in the Entity's Context until a CardAction is used for the first time
    So I'll immediately force a CardAction that will hopefully end immediately and not get in the way, but also will fix this
    This probably goes horribly wrong if the enemy is spawned after the mob intro, but should be fine for now otherwise
]]
function fix_context(self)
    local action = Battle.CardAction.new(self, "IDLE_1")
    action.execute_func = function()
        action:end_action()
    end

    self:card_action_event(action, ActionOrder.Immediate)
end

function init_boss(self)
    self.on_spawn_func = function(self)
        fix_context(self)
        
        self.before_battle_start_animater = Battle.Artifact.new()
        self:get_field():spawn(self.before_battle_start_animater, 7, 4)
        self.before_battle_start_animater.update_func = function()
            self.anim:tick_animation()
        end
    end

    self.battle_start_func = function(self)
        self.before_battle_start_animater:delete()
    end

    -- Setting names here is just convenience if I want to print the state I'm in later
    self.states = {
        idle = {name = "idle", func = idle},
        move = {name = "move", func = move},
        flinch = {name = "flinch", func = flinch},
        
        start_sub_pattern = {name = "start_sub_pattern"},
        finish_sub_pattern = {name = "finish_sub_pattern"},

        rose = {name = "rose", func = rose},
        sword = {name = "sword", func = sword},
        hat = {name = "hat", func = hat},

        choose_attack = {name = "choose_attack", func = choose_attack}
    }
    


    local s = self.states

    reconstruct_pattern(self)
    
 
    self.pattern_index = 1
    self.in_sub_pattern = false

    self.first_act = true

    self.state_done = false

    self.state = self.pattern[1]

    self.first_flinch = true


    self.hit_func = function(from_stun)
      --  print("Hit func runs")
        self.flinching = false
        self.first_act = false
        self.state_done = false
        self.moving_to_enemy_tile = false
        if self.first_flinch then 
         --   self.state.cleanup
            self.last_state = self.state
       --     print("Hit! Set last state to ", self.state.name)
            if self.state ~= self.states.idle and self.state ~= self.states.move then 
               -- increment_pattern(self)
            end

            self.first_flinch = false
        end

        self.state = self.states.flinch

        -- This is unused for this boss
        if self.slide_component ~= nil then 
          --  print("Hit while moving.")
            self.slide_component:eject()
            self.slide_component = nil
            self:set_offset(0, 0)

            if self.slide_dest and self:get_current_tile() ~= self.slide_dest then 
            --    print("Hit before reaching destination.")
                self:get_current_tile():remove_entity_by_id(self:get_id())
                self.slide_dest:add_entity(self)
                self.slide_dest = nil
            end

        end

        flinch(self, from_stun)
    end

    self.delete_func = function(self)
        self.update_func = function(self)
            self:get_animation():set_state("FLINCH_1")
            self.state = self.states.flinch
        end

    end

    -- Unused for this boss
    self.moving_to_enemy_tile = false
    self.counter = 0
    self.collision_available = true


    self:register_status_callback(Hit.Stun, function() self.hit_func(true) end)
    self:register_status_callback(Hit.Flinch, self.hit_func)
    self:register_status_callback(Hit.Drag, self.hit_func)
    self:register_status_callback(Hit.Root, function() self.rooted = 120 end)

    -- Bring it back next build. For now, relying on the stun callback
    --[[
    self.on_countered = function(self)
        print("Countered")
        self:toggle_counter(false)
        self.hit_func(self)

    end
    --]]

    self.can_move_to_func = function(tile)
        if self.rooted > 0 then return false end
        if tile:is_edge() or not tile:is_walkable() then
            return false
        end
        if(tile:is_reserved({})) then
            return false
        end

        if not self.moving_to_enemy_tile and (tile:get_team() ~= self:get_team()) then
            return false
        end

        return not check_obstacles(tile, self) --and not check_characters(tile, self)
    end

    self.rooted = 0
    self.update_func = function(self)
       -- print("     ", self.state.name, self:get_animation():get_state())
        if self.rooted > 0  then self.rooted = self.rooted - 1 end
        self.state.func(self)
        self.anim:tick_animation()

        -- When we tick animation, we may run increment_pattern. 
        -- The new state isn't run until next frame, so our anim state lasts one more frame when it finishes
        -- Calling our state one time to set things up will avoid this. Mostly sure this doesn't have major unintended consequences,
        -- especially as most state.func only set state and callbacks for frame 1
        -- Problem is, now I may have a frame 1 callback but I don't run it until next frame
        while self.first_act
        do
            self.state.func(self)
            self.anim:tick_animation()
        end
        check_collision(self)
    end
end

function create_collision_attack(self, tile)
    local spell = Battle.Spell.new(self:get_team())
   
    local hit_props = HitProps.new(
        self.damage_rose,
        Hit.Impact | Hit.Flash | Hit.Flinch,
        self:get_element(), 
        self:get_context(), 
        Drag.None
    )

    spell:set_hit_props(hit_props)

    spell.update_func = function(self)
        tile:attack_entities(self)
        self:delete()
    end

    self:get_field():spawn(spell, tile)
end


-- TODO: When we get is_passthrough or something, check to see if target became flashing before 
    -- we are allowed to spawn another one. Don't want to instakill viruses
-- self.collision_available can do something related to that. Does nothing now
function check_collision(self)
    local t = self:get_current_tile()
    if self.collision_available and check_characters(t, self) then 
        create_collision_attack(self, t)
    end

end

function idle(self)
    if self.first_act then 
        -- This is an old check for when I extended idle time by doing two idle states in a row, when characters have an animated idle
            -- Not needed if I instead use a timer
        if self.anim:get_state() ~= "IDLE" then 
        --    print("Idle with ", self.idle_speed)
            self.anim:set_state("IDLE", {
                {duration=8, state="IDLE_1"},
                {duration=8, state="IDLE_2"},
                {duration=8, state="IDLE_3"},
                {duration=8, state="IDLE_2"},

            })
        end

        self.anim:set_playback(Playback.Loop)
        self.counter = 0
        
        self.first_act = false
    end

    self.counter = self.counter + 1
    if self.counter >= self.idle_speed then 
        -- Extra catch for after leaving attack. Attack will double idle speed once, so making sure to reset it after
        if self.idle_speed > self.base_idle_speed then 
            self.idle_speed = self.base_idle_speed
        end

        increment_pattern(self)
    end

end

function hit()
    

end

function end_sub_pattern(self)
    while(self.in_sub_pattern)
    do
        increment_pattern(self)
    end
end

function flinch(self, from_stun)
   -- print("Flinch played")

   -- print("I am flinching")
    if not self.flinching then 
        local frames = {}
        local flinch_time = self.flinch_duration
        if not from_stun then 
            for i=1, flinch_time, 3
            do
                frames[i] = {duration=2, state="FLINCH_1"}
            end
            for i=2, flinch_time, 3
            do
                frames[i] = {duration=2, state="FLINCH_2"}
            end

            for i=3, flinch_time, 3
            do
                frames[i] = {duration=2, state="FLINCH_3"}
            end
        else
            frames[1] = {duration=0, state="FLINCH_1"}
        end

        self.anim:set_state("FLINCH", frames)

        self.anim:on_complete(function()
            -- If we didn't just attack, we want to make sure the idle speed is correct. This is also set in the actual idle, but just for extra measure.
                -- Shouldn't be necessary
            if self.idle_speed > self.base_idle_speed and self.pattern[self.pattern_index] ~= self.states.choose_attack then 
                self.idle_speed = self.base_idle_speed
            end

            local has_skipped = false
            if self.last_state ~= self.states.flinch then 
          --      print("Attempt skip, because last state was idle")
                has_skipped = maybe_skip_after_flinch(self)
            end

            
--         print("I am done flinching")
        --   print("Anim done")
            self.flinching = false
            self.state_done = true
            self.first_flinch = true

        --    print("Done")
            self.state_done = false
            if self.last_state ~= self.states.idle and self.last_state ~= self.states.move then 
        --     print("Last state was not idle or move", self.last_state.name)
 
                increment_pattern(self)

            
            else--if not has_skipped then 
                -- If we were in idle or move, go back to it and try again
                    -- Unless we were in a sub pattern. Still end that.
            --   print("Last state was idle or move")

                if self.in_sub_pattern then 
                    end_sub_pattern(self)
                else
                    self.state = self.last_state
                    self.first_act = true
                end
            end

        end)

    end

    self.flinching = true
end

--[[
    Chance to skip idle or halve idle time, to call after flinching 
    This works by calling increment_pattern an extra time if and only if the last state was Idle
        Remember, last state is the state we will return to after flinching
        Some extra work will need to be done in the self.anim:on_complete of flinch if this is to work with sub patterns. This boss doesn't use them, so it was omitted
    
    Currently, the skip is implemented as setting idle time to 0
    
    A future choice for this function: after calling this function, self.state *may* increment, obsoleting our last state pointer. Returns true if this does happen
        There is a possible additional side effect that the idle time will instead be changed, in which case, last state is preserved and false is returned
]]

function maybe_skip_after_flinch(self)
    local chance_halve = self.chance_to_halve_idle_after_flinch
    local chance_skip = self.chance_to_skip_idle_after_flinch
    local max = chance_halve + chance_skip + (16 - chance_halve - chance_skip)

    local r = math.random(1, max)
    if r <= chance_halve then 
        self.idle_speed = math.floor(self.idle_speed / 2)
    elseif r <= (chance_skip + chance_halve) then 
        self.idle_speed = 0
        return true
    end

    return false
end

function highlight_tiles(self, list, time, highlight)
    highlight = highlight or Highlight.Solid
    local spell = Battle.Spell.new(self:get_team())


    local ref = self
    spell.update_func = function(self)
        for i=1, #list
        do 
            local t = list[i]
            if t and not t:is_edge() then 
                t:highlight(highlight)
            end

        end


        time = time - 1
        if time == 0 then 
            self:delete()
        end

        if self.flinching then 
            if spell and not spell:is_deleted() then 
                spell:delete()
    
            end
        end
    end


    self:get_field():spawn(spell, self:get_current_tile())

    return spell
end



function move(self)
    if self.first_act then 
        
        self.anim:set_state("MOVE", {
            {duration=1, state="IDLE_1"},
        })

        local tile = choose_move(self, self:get_field())
        self.anim:on_frame(1, function()
            if self.can_move_to_func(tile) then 
            else
                tile = self:get_current_tile()
            end

            self:teleport(tile, ActionOrder.Voluntary, function()
                if tile ~= self:get_current_tile() then 
                    create_move_effect(self)
                end
            end)
        end)

        self.anim:on_complete(function()
            -- Reset idle speed, since we did a real action
            self.idle_speed = self.base_idle_speed
            increment_pattern(self)
        
        end)

        self.first_act = false
    end
end

function create_move_effect(self)
    -- Yes, a Spell
    local spell = graphic_init("spell", 0, -38, MOVE_TEXTURE, MOVE_ANIMATION, -1, "2", self, self:get_facing(), true)

    self:get_field():spawn(spell, self:get_current_tile())
end

function choose_attack(self)
    local r = math.random(1, 3)
    if r == 1 then 
        self.state = self.states.rose
        self.idle_speed = self.idle_speed_after_attack
    elseif r == 2 then 
        self.state = self.states.sword
        self.idle_speed = self.idle_speed_after_attack
    else
        self.state = self.states.hat
        self.idle_speed = self.idle_speed_after_hat
    end

    self.state.func(self)
end

function rose(self)
    if self.first_act then 
        self.anim:set_state("ROSE", {
            {duration=8, state="POSE_1"},
            {duration=8, state="POSE_2"}, -- Shift forward
            {duration=76, state="POSE_2"} -- Spawn hand
        })    

        self.anim:on_frame(3, function()
            local targets = self:get_field():find_nearest_characters(self, function(c)
                return c:get_team() ~= self:get_team() and c:get_health() > 0
            end)

            if targets[1] then 
                local target = targets[1]
                local tile = target:get_tile(target:get_facing(), 1)
                if tile and not tile:is_edge() then 
                    rose_attack(self, tile)
                end
            end
        end)

        self.anim:on_complete(function()
            increment_pattern(self)
        
        end)

        self.first_act = false
    end
end

function sword(self)
    if self.first_act then 
        self.anim:set_state("SWORD", {
            {duration=8, state="POSE_1"},
            {duration=8, state="POSE_2"}, -- Shift forward
            {duration=76, state="POSE_2"} -- Spawn hand
        })    

        self.anim:on_frame(3, function()
            local targets = self:get_field():find_nearest_characters(self, function(c)
                return c:get_team() ~= self:get_team() and c:get_health() > 0
            end)

            if targets[1] then 
                local target = targets[1]
                local tile = target:get_tile(target:get_facing(), 1)
                if tile and not tile:is_edge() then 
                    sword_attack(self, tile)
                end
            end
        end)

        self.anim:on_complete(function()
            increment_pattern(self)
        
        end)

        self.first_act = false
    end
end

function rose_attack(self, tile)
    local spell = graphic_init("spell", 0, 0, HATMAN_TEXTURE, HATMAN_ANIMATION, -1, "ROSE_THROW", self, self:get_facing(), true)
    local anim = spell:get_animation()
    spell:set_shadow(SHADOW_TEXTURE)
    spell:show_shadow(true)
    spell:set_elevation(50)
    local x = 0

    local hit_props = HitProps.new(
        self.damage_rose,
        Hit.Impact | Hit.Flinch | Hit.Flash,
        Element.None, 
        self:get_context(), 
        Drag.None
    )

    spell:set_hit_props(hit_props)

    if spell:get_facing() == Direction.Left then 
        x = x * -1
    end

    -- Move back a pixel
    anim:on_frame(6, function()
        local x = -2
        if spell:get_facing() == Direction.Left then 
            x = x * -1
        end

        spell:set_offset(x, 0)
    end)

    -- Another back
    anim:on_frame(7, function()
        local x = -4
        if spell:get_facing() == Direction.Left then 
            x = x * -1
        end

        spell:set_offset(x, 0)
    end)

   
    anim:on_frame(8, function()
        Engine.play_audio(THROW_SFX, AudioPriority.Low)
        create_rose(self, hit_props, spell:get_tile(spell:get_facing(), 1))
    end)

     -- One forward from neutral
    anim:on_frame(9, function()
        local x = 2
        if spell:get_facing() == Direction.Left then 
            x = x * -1
        end

        spell:set_offset(x, 0)
    end)

    -- Back to neutral
    anim:on_frame(10, function()
        spell:set_offset(0, 0)
    end)

    local owner = self
    spell.update_func = function(self)
        if owner:is_deleted() then 
            self:delete()
            return
        end

        self:get_current_tile():attack_entities(self)
    end

    spell.attack_func = function(self, other)
        local o = get_random_offset()
        local hit_effect = graphic_init("artifact", o.x, o.y, HIT_EFFECT_TEXTURE, HIT_EFFECT_ANIMATION, -3, "1", self, self:get_facing(), true)
        self:get_field():spawn(hit_effect, other:get_current_tile())

        --Engine.play_audio(HIT_SFX, AudioPriority.Low)
    end

    self:get_field():spawn(spell, tile)
end

function create_rose(user, props, tile)
    local spell = graphic_init("spell", 0, 0, EFFECTS_TEXTURE, EFFECTS_ANIMATION, -1, "ROSE", user, user:get_facing())
    local anim = spell:get_animation()

    spell:set_elevation(50)

    spell:set_hit_props(props)


    spell.update_func = function(self)
        local t = self:get_current_tile()
        t:attack_entities(self)
       
        t:highlight(Highlight.Solid)
       
        if self:is_sliding() == false then
            if t:is_edge() then 
                self:delete()
            end
            local dest = self:get_tile(self:get_facing(), 1)
            self:slide(dest, frames(4), frames(0), ActionOrder.Voluntary, nil)
        end
    end

    spell.attack_func = function(self, other)
        local o = get_random_offset()
        local hit_effect = graphic_init("artifact", o.x, o.y, HIT_EFFECT_TEXTURE, HIT_EFFECT_ANIMATION, -3, "1", self, self:get_facing(), true)
        self:get_field():spawn(hit_effect, other:get_current_tile())

        --Engine.play_audio(HIT_SFX, AudioPriority.Low)
    end

    spell.collision_func = function(self)
        if not self:is_deleted() then 
            self:delete()
            self:hide()
        end
    end

    spell.can_move_to_func = function(tile)
        return true
    end

    user:get_field():spawn(spell, tile)

end


function sword_attack(self, tile)
    local spell = graphic_init("spell", 0, 0, HATMAN_TEXTURE, HATMAN_ANIMATION, -1, "SWORD_SWING", self, self:get_facing(), true)
    local anim = spell:get_animation()
    spell:set_shadow(SHADOW_TEXTURE)
    spell:show_shadow(true)
    spell:set_elevation(50)
    local x = 0

    local hit_props = HitProps.new(
        self.damage_sword,
        Hit.Impact | Hit.Flinch | Hit.Flash,
        Element.None, 
        self:get_context(), 
        Drag.None
    )

    spell:set_hit_props(hit_props)

    if spell:get_facing() == Direction.Left then 
        x = x * -1
    end

    -- Move back a pixel
    anim:on_frame(6, function()
        local x = -2
        if spell:get_facing() == Direction.Left then 
            x = x * -1
        end

        spell:set_offset(x, 0)
    end)

    -- Another back
    anim:on_frame(7, function()
        local x = -4
        if spell:get_facing() == Direction.Left then 
            x = x * -1
        end

        spell:set_offset(x, 0)
    end)

    anim:on_frame(8, function()
        Engine.play_audio(SWORD_SFX, AudioPriority.Low)
        create_sword_attack(self, hit_props, spell:get_tile(spell:get_facing(), 1))
    end)

    -- One forward from neutral
    anim:on_frame(9, function()
        local x = 2
        if spell:get_facing() == Direction.Left then 
            x = x * -1
        end

        spell:set_offset(x, 0)
    end)

    -- Back to neutral
    anim:on_frame(10, function()
        spell:set_offset(0, 0)
    end)

    local owner = self
    spell.update_func = function(self)
        if owner:is_deleted() then 
            self:delete()
            return
        end

        self:get_current_tile():attack_entities(self)
    end

    spell.attack_func = function(self, other)
        local o = get_random_offset()
        local hit_effect = graphic_init("artifact", o.x, o.y, HIT_EFFECT_TEXTURE, HIT_EFFECT_ANIMATION, -3, "1", self, self:get_facing(), true)
        self:get_field():spawn(hit_effect, other:get_current_tile())

        --Engine.play_audio(HIT_SFX, AudioPriority.Low)
    end

    self:get_field():spawn(spell, tile)
end

function create_sword_attack(self, props, pivot)
    if not pivot then return end

    local facing = self:get_facing()
    local field = self:get_field()

    local function create_hitbox(tile)
        if tile:is_edge() then return end

        local spell = Battle.Spell.new(self:get_team())

        spell:set_hit_props(props)
        spell:set_facing(facing)
        

        spell.on_spawn_func = function(self)
            self:get_tile():attack_entities(self)
            self:delete()
        end
    
        spell.attack_func = function(self, other)
            local o = get_random_offset()
            local hit_effect = graphic_init("artifact", o.x, o.y, HIT_EFFECT_TEXTURE, HIT_EFFECT_ANIMATION, -3, "1", self, self:get_facing(), true)
            self:get_field():spawn(hit_effect, other:get_current_tile())
    
            --Engine.play_audio(HIT_SFX, AudioPriority.Low)

        end
    
       

        field:spawn(spell, tile)
    end


    local slash = graphic_init("spell", 0, 0, SLASHES_TEXTURE, SLASHES_ANIMATION, -1, "0", self, facing, true)
    slash:set_elevation(24)

    create_hitbox(pivot)
    create_hitbox(pivot:get_tile(Direction.Up, 1))
    create_hitbox(pivot:get_tile(Direction.Down, 1))

    field:spawn(slash, pivot)

end

function hat(self)
    if self.first_act then 
        self.anim:set_state("HAT", {
            {duration=28, state="NO_HAND_1"},
            {duration=20, state="NO_HAND_1"},

        })

        local hand = create_circle_hand(self, self:get_tile(self:get_facing(), 1))

        self.anim:on_frame(2, function()
            if #self.hats < 2 then 
                local props = HitProps.new(
                    self.damage_bird,
                    Hit.Impact | Hit.Flinch | Hit.Flash,
                    Element.None, 
                    self:get_context(), 
                    Drag.None
                )
                local hat = create_hat(self, self:get_tile(self:get_facing(), 1), props)
                Engine.play_audio(APPEAR_SFX, AudioPriority.Low)
                if hat then 
                    table.insert(self.hats, hat)
                end
            else
                create_hat_controller(self)
            end

        end)

        self.anim:on_complete(function()
            increment_pattern(self)
            hand:hide()
            hand:delete()
        end)

        self.anim:on_interrupt(function()
            if hand and not hand:is_deleted() then 
                hand:hide()
                hand:delete()
            end
        end)

        self.first_act = false
    end
end

function create_hat_controller(self)
    local hat_list = self.hats
    local max_start_delay = 50
    local start_delay = max_start_delay
    local max_delay = 36
    local delay = 0
    local started_attacking = false
    local index = 1
    local base_hat_delay = self.base_hat_delay

    local birds_remaining_each = 2

    local spell = Battle.Spell.new(self:get_team())

    local first_attacking = true
    spell.update_func = function(self)
        --[[
        print("Hat delays are currently: ")
        for _, hat in ipairs(hat_list)
        do
            print(hat.attack_delay, hat.attacking)
        end
        print("")
        ]]
        start_delay = start_delay - 1
        if not started_attacking and start_delay <= 0 then 
      --      print("Start delay is done, waiting for both hats to not be attacking")
            started_attacking = true
            for _, hat in ipairs(hat_list)
            do
                started_attacking = started_attacking and not hat.attacking
            end

        end

        if started_attacking then
            if first_attacking then  
              --  print("Hats are free, locking them up")
                for _, hat in ipairs(hat_list)
                do
                    hat.attack_delay = base_hat_delay
                end
                first_attacking = false
            end

            if index > 2 then 
                --print("Both shot, reset")
                index = 1
                birds_remaining_each = birds_remaining_each - 1
                if birds_remaining_each == 0 then 
                  --  print("Done, deleting")
                    self:delete()
                    return
                end
            end

            delay = delay - 1

            if delay <= 0 then 
             --   print("Hat "..index.. " is attacking now")
                local hat = hat_list[index]
                if hat then 
                    hat.attack_delay = 0
                end

                index = index + 1
                delay = max_delay
            end

        end
    end
    
    self:get_field():spawn(spell, self:get_field():tile_at(0, 0))
end

function create_circle_hand(self, tile)
    if not tile then return end
    local hand = graphic_init("spell", -28, -64, HATMAN_TEXTURE, HATMAN_ANIMATION, -1, "HAND_CIRCLES", self, self:get_facing())

    local field = self:get_field()

    field:notify_on_delete(self:get_id(), hand:get_id(), function()
        hand:hide()
        hand:delete()
    end)

    field:spawn(hand, tile)

    return hand
end

function create_hat(self, tile, props)
    if not tile or tile:is_edge() then return end

    local field = self:get_field()
    local hat = graphic_init("obstacle", 0, 0, EFFECTS_TEXTURE, EFFECTS_ANIMATION, -1, "HAT", self, self:get_facing())
    local hat_glow = graphic_init("spell", 0, 0, EFFECTS_TEXTURE, EFFECTS_ANIMATION, -2, "HAT_GLOW", self, self:get_facing())
    
    hat_glow:get_animation():on_complete(function()
        hat_glow:delete()
        hat_glow = nil

        local t = hat:get_current_tile()
        -- Don't spawn finish spawn if tile is taken or hole
        if not t:is_walkable() or check_characters(t, hat) or check_obstacles(t, hat) then 
            hat:delete()
        end
    end)

    hat:set_health(self.hat_health)
    hat.owner_deleted = false
    hat.owner = self
    hat.attack_delay = self.base_hat_delay
    hat.attacking = false

    local function attack(user)
        -- Yes, this will set here, not once it's done attacking
        user.attack_delay = user.owner.base_hat_delay

        local anim = user:get_animation()
        anim:set_state("HAT_OPEN")
        highlight_tiles(user, {user:get_current_tile()}, 36, Highlight.Flash)

        anim:on_frame(2, function()
            Engine.play_audio(BIRD_FLY_SFX, AudioPriority.Low)
            launch_bird(user, user:get_current_tile(), props)
        end)
        anim:on_complete(function()
            user.attacking = false
            anim:set_state("HAT")
            anim:refresh(user:sprite())
        end)

        anim:refresh(user:sprite())
    end

    hat.update_func = function(self)
        self.attack_delay = self.attack_delay - 1

        if not self.attacking then 
            if self.attack_delay <= 0 then 
                self.attacking = true
                attack(self)
            end
        end
    end

    hat.delete_func = function(self)
        Engine.play_audio(BOOM_SFX, AudioPriority.Low)
        
       
        -- I don't know if notify_on_delete will run before observed Entity is marked deleted
            -- Second check may be redundant
        if self.owner:is_deleted() or self.owner_deleted then 
            return
        end

        if self:get_health() <= 0 then
            local boom_effect = graphic_init("artifact", 0, -10, BOOM_TEXTURE, BOOM_ANIMPATH, -3, "2", self, self:get_facing(), true)
            self:get_field():spawn(boom_effect, self:get_current_tile())
        end
        
        -- Remove this hat from the table, which moves the other hats up so I can still refer to [1] for the older hat
        local hat_list = self.owner.hats
        for i=1, #hat_list
        do
            if hat_list[i]:get_id() == self:get_id() then 
                table.remove(self.owner.hats, i)
                break
            end
        end
        
    end

    field:notify_on_delete(self:get_id(), hat:get_id(), function()
        hat.owner_deleted = true
        hat:delete()
    end)

    field:spawn(hat, tile)
    field:spawn(hat_glow, tile)

    return hat
end

function launch_bird(self, tile, props)
    local spell = graphic_init("spell", 6, -80, HATMAN_TEXTURE, HATMAN_ANIMATION, -1, "BIRD_FLIGHT", self, self:get_facing())
    spell:get_animation():set_playback(Playback.Loop)
    local field = self:get_field()

    local x_flip = 1
    if spell:get_facing() == Direction.Right then 
        x_flip = x_flip * -1
    end
    local vectors = {
        {x = -22 * x_flip, y = -8},
        {x = -46 * x_flip, y = -18},
        {x = -22 * x_flip, y = -22},
        {x = -26 * x_flip, y = -32},
        {x = -22 * x_flip, y = -60},

    }

    local move_duration = 4
    local move_progress = 1
    local index = 1
    local start_offset = spell:get_offset()
    spell.update_func = function(self)
        if index <= #vectors then
            local d_v = get_progress_vector(vectors[index], move_duration, move_progress)
            self:set_offset(start_offset.x + d_v.x + d_v.x % 2, start_offset.y + d_v.y + d_v.y % 2)
            
            move_progress = move_progress + 1
            if move_progress > move_duration then 
                index = index + 1
                move_progress = 1
                start_offset = self:get_offset()
            end
            
        else
            local target = field:find_nearest_characters(self, function(c) 
                return self:get_team() ~= c:get_team() and c:get_health() > 0
            end)
            target = target[1]
            if target ~= nil then 
                drop_bird(self, target:get_current_tile(), props)
            end

            self:delete()
            self:hide()
        end
    end

    field:spawn(spell, tile)
end

function drop_bird(user, tile, props)
    local distance = 42*2*3
    local spell = graphic_init("spell", distance*-1, distance*-1, HATMAN_TEXTURE, HATMAN_ANIMATION, -1, "BIRD_DIVE", user, user:get_facing())
    spell:set_hit_props(props)
    spell:hide()

    local move_duration = 12
    local move_progress = 1
    local dest = {x = distance, y = distance}
    if spell:get_facing() == Direction.Left then 
        dest.x = dest.x * -1
    end

    local offset = spell:get_offset()

    local warning_time = 36
    local dive_first = true
    spell.update_func = function(self)
        if warning_time > 0 then 
            self:get_current_tile():highlight(Highlight.Flash)
        end

        if warning_time < 4 then
            if dive_first then
                Engine.play_audio(BIRD_DIVE_SFX, AudioPriority.Low) 
                self:reveal()
                dive_first = false
            end
            local d_v = get_progress_vector(dest, move_duration, move_progress)
            self:set_offset(offset.x + d_v.x + d_v.x % 2, offset.y + d_v.y + d_v.y % 2) 

            move_progress = move_progress + 1
            if move_progress > move_duration then 
                self:get_current_tile():attack_entities(self)
                self:delete()
            end
        end

        warning_time = warning_time - 1
    end

    spell.attack_func = function(self, other)
        local o = get_random_offset()
        local hit_effect = graphic_init("artifact", o.x, o.y, HIT_EFFECT_TEXTURE, HIT_EFFECT_ANIMATION, -3, "1", self, self:get_facing(), true)
        self:get_field():spawn(hit_effect, other:get_current_tile())

        --Engine.play_audio(HIT_SFX, AudioPriority.Low)
    end

    user:get_field():spawn(spell, tile)
end

function get_progress_vector(vector, time, frame)
    if frame == time then return vector end
    local progress_x = math.floor(vector.x / time * frame)
    local progress_y = math.floor(vector.y / time * frame)

    return {x = progress_x, y = progress_y}
end

function get_progress_vector_between(start_vector, end_vector, time, frame)
    if frame == time then return end_vector end
    if frame == 0 then return start_vector end
    local progress_x = math.floor(start_vector.x + ((end_vector.x - start_vector.x) / time) * frame)
    local progress_y = math.floor(start_vector.y + ((end_vector.y - start_vector.y) / time) * frame)

    return {x = progress_x, y = progress_y}
end


function choose_move(self, field)
    local team = self:get_team()

    local tiles = field:find_tiles(function(tile)
        return tile ~= self:get_current_tile() and self.can_move_to_func(tile)
    
    end)


    --print("Found ", #tiles, " possible tiles")

    if #tiles == 0 then 
        return self:get_current_tile()
    end

    return tiles[math.random(1, #tiles)]
end


function choose_enemy(self, field)
    local team = self:get_team()

    local target = field:find_characters(function(c)
        return c:get_team() ~= team
    end)

    if not target[1] then 
       -- print("No targets")
        return nil
    end

    t_x = target[1]:get_current_tile():x()
    t_y = target[1]:get_current_tile():y()

    local facing = -1
    if target[1]:get_facing() == Direction.Right then 
        facing = 1
    end

    local tile = field:tile_at(t_x+facing, t_y)

    return tile
end


function reconstruct_pattern(self)
    local pattern = {}
    local states = self.states
    local moves = self.move_count
    local r = math.random(1, 16)
   -- print(r)
    if r <= self.chance_to_move_twice then 
        moves = 2
      --  print("Two moves this time")
    end

    for i=1, moves
    do
        table.insert(pattern, states.idle)
        table.insert(pattern, states.move)
    end

    table.insert(pattern, states.idle)
    table.insert(pattern, states.choose_attack)


    self.pattern = pattern
end

function increment_pattern(self)
   -- print("Pattern increment")

    self.first_act = true
    self.state_done = false
    self.pattern_index = self.pattern_index + 1
    if self.pattern_index > #self.pattern then 
        reconstruct_pattern(self)
 --       print("Reconstructed pattern")
        self.pattern_index = 1
    end

    local next_state = self.pattern[self.pattern_index]
    self.state = next_state
  --  print("Moving to state named ", next_state.name)

    if next_state == self.states.start_sub_pattern then 
        self.in_sub_pattern = true
        increment_pattern(self)
    end

    if next_state == self.states.finish_sub_pattern then 
        self.in_sub_pattern = false
        increment_pattern(self)

    end

   -- print("Changing to "..self.pattern_index..", which is "..self.pattern[self.pattern_index].name)

end

function check_obstacles(tile, self)
    local ob = tile:find_obstacles(function(o)
        return o:get_id() ~= self:get_id() and o:get_health() > 0 
    end)

    return #ob > 0 
end


function check_characters(tile, self)
    local characters = tile:find_characters(function(c)
        return c:get_id() ~= self:get_id() and c:get_team() ~= self:get_team()
    end)

    return #characters > 0

end

function get_random_offset()
    local x = math.random(0, 40)
    local y = math.random(20, 40)
    
    x = x - 20
    y = y * -1

    return {x = x, y = y}
end

function graphic_init(type, x, y, texture, animation, layer, state, user, facing, delete_on_complete, flip)
    flip = flip or false
    delete_on_complete = delete_on_complete or false
    facing = facing or nil
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()

    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())

    end

    graphic:sprite():set_layer(layer)
    graphic:never_flip(flip)
    graphic:set_texture(texture, true)
    if facing then 
        graphic:set_facing(facing)
    end
    
    if user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    anim:load(animation)

    anim:set_state(state)
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end