local package_id = "com.alrysc.enemy.HatMan"
local character_id = "com.alrysc.enemy.HatManEnemy"

function package_requires_scripts()
    Engine.define_character(character_id, _modpath.."enemy")
end

function package_init(package) 
    package:declare_package_id(package_id)
    package:set_name("HatMan")
    package:set_description("Hope you have a good hand.")
    package:set_speed(1)
    package:set_attack(40)
    package:set_health(800)
    package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob) 
    local texPath = _modpath.."bg.png"
    local animPath = _modpath.."bg.animation"
    mob:set_background(texPath, animPath, 0.16667, 0.16667)
    mob:stream_music(_modpath.."phantom_boss.ogg", 0, 38409)
   -- 612820,2037590 
    mob:create_spawner(character_id, Rank.V1):spawn_at(5, 2)
end